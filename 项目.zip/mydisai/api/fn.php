<?php
// 添加用户
function add_user($name, $password1, $yan)
{

    require "db.php";

    // 查询是否存在改名
    $stmt1 = $mysqli->prepare("SELECT * FROM user WHERE name=?");
    // "sss" 表示三个参数都是字符串  
    $stmt1->bind_param("s", $name);
    $stmt1->execute();
    // 获取结合集
    $res1 = $stmt1->get_result();
    if ($res1->num_rows == 0) {
        // 插入语句
        $stmt = $mysqli->prepare("INSERT INTO user( name, password,yan) VALUES (?,?,?)");
        // "sss" 表示三个参数都是字符串  
        $stmt->bind_param("sss", $name, $password1, $yan);
        $stmt->execute();
        return true;
    } else {
        return false;
    }

}

// 获取所有用户列表
function get_user_list()
{
    require "db.php";
    $list = array();
    
    $sql = "SELECT id, name, password, yan FROM user ORDER BY id DESC";
    $result = $mysqli->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $list[] = $row;
        }
    }
    
    return $list;
}

// 获取单个用户信息
function get_user_by_id($id)
{
    require "db.php";
    
    $stmt = $mysqli->prepare("SELECT id, name, password, yan FROM user WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

// 更新用户信息
function update_user($id, $name, $password1, $yan)
{
    require "db.php";
    
    $stmt = $mysqli->prepare("UPDATE user SET name = ?, password = ?, yan = ? WHERE id = ?");
    $stmt->bind_param("sssi", $name, $password1, $yan, $id);
    
    if ($stmt->execute()) {
        return true;
    }
    
    return false;
}

// 删除用户
function delete_user($id)
{
    require "db.php";
    
    $stmt = $mysqli->prepare("DELETE FROM user WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        return true;
    }
    
    return false;
}





// 密码修改

function password_update($password_x, $yan_x, $name)
{
    require ('db.php'); // 确保db.php包含有效的数据库连接信息  

    // 准备SQL语句  
    $stmt = $mysqli->prepare("UPDATE admin SET password=?,yan=? WHERE name=?");

    // 绑定参数  
    $stmt->bind_param("sss", $password_x, $yan_x, $name);

    // 执行语句  
    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}



// 登入验证
function login($name)
{

    require "db.php";
    $list = array();
    // 查询是否存在改名
    $stmt1 = $mysqli->prepare("SELECT * FROM admin WHERE name=?");
    // "sss" 表示三个参数都是字符串  
    $stmt1->bind_param("s", $name);
    $stmt1->execute();
    // 获取结合集
    $res1 = $stmt1->get_result();
    if ($res1->num_rows > 0) {
        $list = $res1->fetch_assoc();
        return $list;
    } else {
        return false;
    }

}



function session()
{
    // 检查session是否已经启动
    if (session_status() === PHP_SESSION_NONE) {
        session_start(); // 开始会话
    }
    
    if (!isset($_SESSION['username'])) {
        header('Location: ../login.php');
        exit;
    }
}

// 获取消耗明细列表
function get_consumption_list()
{
    require "db.php";
    $list = array();
    
    // 查询主表数据并关联业务明细表进行汇总
    $sql = "SELECT 
                bc.id,
                bc.year,
                bc.month,
                bc.budget AS month_budget,
                bc.task_quantity AS month_leads_task,
                bc.target_volume AS month_order_task,
                bc.remarks,
                COALESCE(SUM(bd.daily_consumption), 0) AS actual_consumption,
                COALESCE(SUM(bd.natural_leads + bd.ad_leads), 0) AS actual_leads,
                COALESCE(SUM(bd.order_quantity), 0) AS actual_orders
            FROM base_config bc
            LEFT JOIN business_detail bd ON bc.year = bd.year AND bc.month = bd.month
            GROUP BY bc.id, bc.year, bc.month, bc.budget, bc.task_quantity, bc.target_volume, bc.remarks
            ORDER BY bc.year DESC, bc.month DESC";
    
    $result = $mysqli->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $list[] = $row;
        }
    }
    
    return $list;
}

// 获取已存在的年月组合
function get_existing_year_months()
{
    require "db.php";
    $list = array();
    
    $sql = "SELECT CONCAT(year, '-', month) AS year_month FROM base_config";
    $result = $mysqli->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $list[] = $row['year_month'];
        }
    }
    
    return $list;
}

// 检查年月是否已存在
function check_year_month_exists($year, $month)
{
    require "db.php";
    
    $stmt = $mysqli->prepare("SELECT COUNT(*) as count FROM base_config WHERE year = ? AND month = ?");
    $stmt->bind_param("ii", $year, $month);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row['count'] > 0;
}

// 添加基础配置和核销节点（使用事务）
function add_base_config_with_nodes($year, $month, $budget, $task_quantity, $target_volume, $remarks, $nodes)
{
    require "db.php";
    
    // 开启事务
    $mysqli->begin_transaction();
    
    try {
        // 插入基础配置
        $stmt = $mysqli->prepare("INSERT INTO base_config (year, month, budget, task_quantity, target_volume, remarks) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iidiis", $year, $month, $budget, $task_quantity, $target_volume, $remarks);
        
        if (!$stmt->execute()) {
            throw new Exception("插入基础配置失败");
        }
        
        // 获取刚插入的base_config_id
        $base_config_id = $mysqli->insert_id;
        
        // 插入核销节点
        if (!empty($nodes) && is_array($nodes)) {
            $stmt_node = $mysqli->prepare("INSERT INTO write_off_node (write_off_date, amount, start_date, end_date, base_config_id) VALUES (?, ?, ?, ?, ?)");
            
            foreach ($nodes as $node) {
                if (isset($node['write_off_date']) && isset($node['amount']) && 
                    isset($node['start_date']) && isset($node['end_date'])) {
                    
                    $write_off_date = $node['write_off_date'];
                    $amount = floatval($node['amount']);
                    $start_date = $node['start_date'];
                    $end_date = $node['end_date'];
                    
                    $stmt_node->bind_param("sdiii", $write_off_date, $amount, $start_date, $end_date, $base_config_id);
                    
                    if (!$stmt_node->execute()) {
                        throw new Exception("插入核销节点失败");
                    }
                }
            }
        }
        
        // 获取当月的天数
        $days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        
        // 为当月的每一天插入 business_detail 记录
        $stmt_detail = $mysqli->prepare("INSERT INTO business_detail (year, month, day_of_month, natural_leads, ad_leads, daily_consumption, order_quantity) VALUES (?, ?, ?, 0, 0, 0, 0)");
        
        for ($day = 1; $day <= $days_in_month; $day++) {
            $stmt_detail->bind_param("iii", $year, $month, $day);
            
            if (!$stmt_detail->execute()) {
                throw new Exception("插入业务明细失败");
            }
        }
        
        // 提交事务
        $mysqli->commit();
        
        return array('success' => true, 'message' => '添加成功');
        
    } catch (Exception $e) {
        // 回滚事务
        $mysqli->rollback();
        return array('success' => false, 'message' => $e->getMessage());
    }
}

// 获取消耗详情
function get_consumption_detail($id)
{
    require "db.php";
    
    // 获取基础配置
    $stmt = $mysqli->prepare("SELECT * FROM base_config WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        return null;
    }
    
    $config = $result->fetch_assoc();
    
    // 获取业务明细汇总数据
    $stmt_detail = $mysqli->prepare("
        SELECT 
            COALESCE(SUM(daily_consumption), 0) AS total_consumption,
            COALESCE(SUM(natural_leads), 0) AS total_natural_leads,
            COALESCE(SUM(ad_leads), 0) AS total_ad_leads,
            COALESCE(SUM(order_quantity), 0) AS total_orders
        FROM business_detail 
        WHERE year = ? AND month = ?
    ");
    $stmt_detail->bind_param("ii", $config['year'], $config['month']);
    $stmt_detail->execute();
    $detail_result = $stmt_detail->get_result();
    $detail = $detail_result->fetch_assoc();
    
    // 获取每日业务明细（按日期排序）
    $stmt_daily = $mysqli->prepare("SELECT * FROM business_detail WHERE year = ? AND month = ? ORDER BY day_of_month");
    $stmt_daily->bind_param("ii", $config['year'], $config['month']);
    $stmt_daily->execute();
    $daily_result = $stmt_daily->get_result();
    $daily_details = array();
    while ($row = $daily_result->fetch_assoc()) {
        $daily_details[] = $row;
    }
    
    // 计算各项指标
    $data = array(
        // 基础数据
        'id' => $config['id'],
        'year' => $config['year'],
        'month' => $config['month'],
        'budget' => floatval($config['budget']),
        'task_quantity' => intval($config['task_quantity']),
        'target_volume' => intval($config['target_volume']),
        'remarks' => $config['remarks'],
        
        // 实际数据
        'total_consumption' => floatval($detail['total_consumption']),
        'total_natural_leads' => intval($detail['total_natural_leads']),
        'total_ad_leads' => intval($detail['total_ad_leads']),
        'total_orders' => intval($detail['total_orders']),
        
        // 计算数据
        'total_leads' => intval($detail['total_natural_leads']) + intval($detail['total_ad_leads']),
        'remaining_budget' => floatval($config['budget']) - floatval($detail['total_consumption']),
        'budget_usage_rate' => floatval($config['budget']) > 0 ? (floatval($detail['total_consumption']) / floatval($config['budget']) * 100) : 0,
        'leads_diff' => intval($config['task_quantity']) - (intval($detail['total_natural_leads']) + intval($detail['total_ad_leads'])),
        'leads_completion_rate' => intval($config['task_quantity']) > 0 ? ((intval($detail['total_natural_leads']) + intval($detail['total_ad_leads'])) / intval($config['task_quantity']) * 100) : 0,
        'order_completion_rate' => intval($config['target_volume']) > 0 ? (intval($detail['total_orders']) / intval($config['target_volume']) * 100) : 0,
        'cost_per_lead' => (intval($detail['total_natural_leads']) + intval($detail['total_ad_leads'])) > 0 ? (floatval($detail['total_consumption']) / (intval($detail['total_natural_leads']) + intval($detail['total_ad_leads']))) : 0,
        'cost_per_order' => intval($detail['total_orders']) > 0 ? (floatval($detail['total_consumption']) / intval($detail['total_orders'])) : 0,
        'ad_leads_cost' => intval($detail['total_ad_leads']) > 0 ? (floatval($detail['total_consumption']) / intval($detail['total_ad_leads'])) : 0,
        
        // 每日明细
        'daily_details' => $daily_details
    );
    
    return $data;
}

// 获取编辑数据（包括基础配置、核销节点、业务明细）
function get_edit_data($id)
{
    require "db.php";
    
    // 获取基础配置
    $stmt = $mysqli->prepare("SELECT * FROM base_config WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        return null;
    }
    
    $config = $result->fetch_assoc();
    
    // 获取核销节点
    $stmt_node = $mysqli->prepare("SELECT * FROM write_off_node WHERE base_config_id = ? ORDER BY write_off_date");
    $stmt_node->bind_param("i", $id);
    $stmt_node->execute();
    $node_result = $stmt_node->get_result();
    $nodes = array();
    while ($row = $node_result->fetch_assoc()) {
        $nodes[] = $row;
    }
    
    // 获取业务明细（按日期排序）
    $stmt_detail = $mysqli->prepare("SELECT * FROM business_detail WHERE year = ? AND month = ? ORDER BY day_of_month");
    $stmt_detail->bind_param("ii", $config['year'], $config['month']);
    $stmt_detail->execute();
    $detail_result = $stmt_detail->get_result();
    $details = array();
    while ($row = $detail_result->fetch_assoc()) {
        $details[] = $row;
    }
    
    return array(
        'config' => $config,
        'nodes' => $nodes,
        'details' => $details
    );
}

// 更新配置（包括基础配置、核销节点、业务明细）
function update_config_with_nodes_and_details($id, $budget, $task_quantity, $target_volume, $remarks, $nodes, $details)
{
    require "db.php";
    
    // 开启事务
    $mysqli->begin_transaction();
    
    try {
        // 更新基础配置
        $stmt = $mysqli->prepare("UPDATE base_config SET budget = ?, task_quantity = ?, target_volume = ?, remarks = ? WHERE id = ?");
        $stmt->bind_param("diisi", $budget, $task_quantity, $target_volume, $remarks, $id);
        
        if (!$stmt->execute()) {
            throw new Exception("更新基础配置失败");
        }
        
        // 删除旧的核销节点
        $stmt_delete = $mysqli->prepare("DELETE FROM write_off_node WHERE base_config_id = ?");
        $stmt_delete->bind_param("i", $id);
        $stmt_delete->execute();
        
        // 插入新的核销节点
        if (!empty($nodes) && is_array($nodes)) {
            $stmt_node = $mysqli->prepare("INSERT INTO write_off_node (write_off_date, amount, start_date, end_date, base_config_id) VALUES (?, ?, ?, ?, ?)");
            
            foreach ($nodes as $node) {
                if (isset($node['write_off_date']) && isset($node['amount']) && 
                    isset($node['start_date']) && isset($node['end_date'])) {
                    
                    $write_off_date = $node['write_off_date'];
                    $amount = floatval($node['amount']);
                    $start_date = intval($node['start_date']);
                    $end_date = intval($node['end_date']);
                    
                    $stmt_node->bind_param("sdiii", $write_off_date, $amount, $start_date, $end_date, $id);
                    
                    if (!$stmt_node->execute()) {
                        throw new Exception("插入核销节点失败");
                    }
                }
            }
        }
        
        // 更新业务明细
        if (!empty($details) && is_array($details)) {
            $stmt_detail = $mysqli->prepare("UPDATE business_detail SET natural_leads = ?, ad_leads = ?, daily_consumption = ?, order_quantity = ? WHERE id = ?");
            
            foreach ($details as $detail) {
                if (isset($detail['id'])) {
                    $natural_leads = intval($detail['natural_leads']);
                    $ad_leads = intval($detail['ad_leads']);
                    $daily_consumption = floatval($detail['daily_consumption']);
                    $order_quantity = intval($detail['order_quantity']);
                    $detail_id = intval($detail['id']);
                    
                    $stmt_detail->bind_param("iidii", $natural_leads, $ad_leads, $daily_consumption, $order_quantity, $detail_id);
                    
                    if (!$stmt_detail->execute()) {
                        throw new Exception("更新业务明细失败");
                    }
                }
            }
        }
        
        // 提交事务
        $mysqli->commit();
        
        return array('success' => true, 'message' => '更新成功');
        
    } catch (Exception $e) {
        // 回滚事务
        $mysqli->rollback();
        return array('success' => false, 'message' => $e->getMessage());
    }
}