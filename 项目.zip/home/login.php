<?php
// 在HTML输出之前处理会话和清理数据
session_start();

// 保存表单数据到变量（用于填充表单）
$username = isset($_SESSION['username_l']) ? htmlspecialchars($_SESSION['username_l']) : '';
$password = isset($_SESSION['password_l']) ? htmlspecialchars($_SESSION['password_l']) : '';
$verifyCode = isset($_SESSION['verifyCode_l']) ? htmlspecialchars($_SESSION['verifyCode_l']) : '';

// 清除登录数据（在保存到变量后清除）
unset($_SESSION['username_l']);
unset($_SESSION['verifyCode_l']);
unset($_SESSION['password_l']);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>[中国星]新媒体线索、消耗追踪-账号登录</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* 全局样式重置 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif;
        }
        
        body {
            background-color: #f8fafc;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            width: 100%;
            max-width: 420px;
            overflow: hidden;
            padding: 40px 35px;
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 32px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
            color: #2563eb;
            font-size: 22px;
            font-weight: 700;
        }
        
        .logo i {
            margin-right: 10px;
            font-size: 26px;
        }
        
        .login-header h1 {
            font-size: 24px;
            color: #1e293b;
            margin-bottom: 8px;
        }
        
        .login-header p {
            color: #64748b;
            font-size: 14px;
        }
        
        /* 表单样式 */
        .form-group {
            margin-bottom: 22px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #475569;
            font-weight: 500;
            font-size: 14px;
        }
        
        .input-container {
            position: relative;
            display: flex;
            align-items: center;
        }
        
        .input-container i {
            position: absolute;
            left: 15px;
            color: #94a3b8;
            font-size: 16px;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 14px 14px 45px;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.2s;
            background-color: #f8fafc;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
            background-color: white;
        }
        
        /* 验证码区域 */
        .captcha-wrapper {
            display: flex;
            gap: 10px;
        }
        
        .captcha-wrapper .input-container {
            flex: 1;
        }
        
        .captcha-img {
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            cursor: pointer;
            height: 48px;
            width: 120px;
            object-fit: cover;
        }
        
        /* 记住我选项 */
        .remember-option {
            display: flex;
            align-items: center;
            margin-bottom: 24px;
        }
        
        .remember-option input {
            margin-right: 8px;
            accent-color: #2563eb;
        }
        
        .remember-option label {
            color: #475569;
            font-size: 14px;
            margin-bottom: 0;
            cursor: pointer;
        }
        
        /* 登录按钮 */
        .login-btn {
            width: 100%;
            padding: 14px;
            background-color: #2563eb;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background-color 0.2s;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
        }
        
        .login-btn:hover {
            background-color: #1d4ed8;
        }
        
        .login-btn:disabled {
            background-color: #93c5fd;
            cursor: not-allowed;
        }
        
        .loading-icon {
            display: none;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* 页脚 */
        .login-footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #f1f5f9;
            color: #64748b;
            font-size: 13px;
        }
        
        .login-footer a {
            color: #2563eb;
            text-decoration: none;
        }
        
        .login-footer a:hover {
            text-decoration: underline;
        }
        
        /* 响应式调整 */
        @media (max-width: 480px) {
            .login-container {
                padding: 30px 25px;
            }
            
            .captcha-wrapper {
                flex-direction: column;
            }
            
            .captcha-img {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo">
                <i class="fas fa-chart-line"></i>
                中国星数据
            </div>
            <h1>账号登录</h1>
            <p>新媒体线索、消耗追踪系统</p>
        </div>
        
        <form id="loginForm" action="./temp/login_code.php" method="post">
            <div class="form-group">
                <label for="username">账号</label>
                <div class="input-container">
                    <i class="fas fa-user"></i>
                    <input type="text" 
                           id="username" 
                           placeholder="请输入用户名" 
                           class="form-control" 
                           name="username" 
                           value="<?php echo $username; ?>" 
                           required
                           autocomplete="username">
                </div>
            </div>
            
            <div class="form-group">
                <label for="password">密码</label>
                <div class="input-container">
                    <i class="fas fa-lock"></i>
                    <input type="password" 
                           id="password" 
                           placeholder="请输入密码" 
                           class="form-control" 
                           name="password" 
                           value="<?php echo $password; ?>" 
                           required
                           autocomplete="current-password">
                </div>
            </div>
            
            <div class="form-group">
                <label for="verifyCode">验证码</label>
                <div class="captcha-wrapper">
                    <div class="input-container">
                        <i class="fas fa-shield-alt"></i>
                        <input type="text" 
                               id="verifyCode"
                               class="form-control" 
                               placeholder="请输入验证码" 
                               value="<?php echo $verifyCode; ?>"  
                               name="verifyCode" 
                               maxlength="6"  
                               required
                               autocomplete="off">
                    </div>
                    
                    <img src="./temp/yzm.php" 
                         alt="验证码" 
                         title="点击更新验证码"  
                         class="captcha-img"
                         onclick="refreshCaptcha()"/>
                </div>
            </div>
            
            <div class="remember-option">
                <input type="checkbox" id="remember" name="remember">
                <label for="remember">记住账号</label>
            </div>
            
            <button type="submit" class="login-btn">
                <span class="btn-text">登录</span>
                <i class="fas fa-spinner loading-icon"></i>
            </button>
        </form>
        
        <div class="login-footer">
            <p>如忘记账号或密码，请联系市场部</p>
            <p>© <?php echo date('Y'); ?> GaoPro 保留所有权利</p>
        </div>
    </div>

    <script>
        // 刷新验证码函数
        function refreshCaptcha() {
            const captchaImage = document.querySelector('.captcha-img');
            captchaImage.src = './temp/yzm.php?' + new Date().getTime();
        }
        
        // 表单提交处理
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const submitBtn = this.querySelector('.login-btn');
            const btnText = submitBtn.querySelector('.btn-text');
            const loadingIcon = submitBtn.querySelector('.loading-icon');
            
            // 显示加载状态
            btnText.textContent = '登录中...';
            loadingIcon.style.display = 'inline-block';
            submitBtn.disabled = true;
            
            // 如果验证通过，表单会自动提交到 login_code.php
            // 如果验证失败，需要恢复按钮状态
            setTimeout(() => {
                // 防止表单卡在加载状态
                btnText.textContent = '登录';
                loadingIcon.style.display = 'none';
                submitBtn.disabled = false;
            }, 5000); // 5秒后恢复，防止卡死
        });
        
        // 页面加载完成后聚焦到用户名输入框
        document.addEventListener('DOMContentLoaded', function() {
            const usernameInput = document.getElementById('username');
            if (usernameInput && !usernameInput.value) {
                usernameInput.focus();
            }
        });
    </script>
</body>
</html>