<?php  
session_start();

// 生成一个四位数验证码  
$code = rand(1000, 9999);  
$_SESSION['captcha'] = $code;  
  
// 创建透明画布
$img = imagecreate(100, 40);  
  
// 设置透明背景
$transparent = imagecolorallocatealpha($img, 255, 255, 255, 127);
imagefill($img, 0, 0, $transparent);
imagecolortransparent($img, $transparent);

// 纯黑色文字
$textColor = imagecolorallocate($img, 0, 0, 0);

// 使用最大的内置字体
$font = 10; // 这是最大的内置字体
$charWidth = imagefontwidth($font); // 单个字符宽度
$charHeight = imagefontheight($font); // 单个字符高度
$textWidth = $charWidth * 4; // 4个字符的总宽度

// 计算居中位置
$x = (100 - $textWidth) / 2;
$y = (40 - $charHeight) / 2 - 1; // 微调垂直居中

// 绘制验证码
imagestring($img, $font, $x, $y, $code, $textColor);

// 输出
header('Content-type: image/png');  
header('Cache-Control: no-cache');
imagepng($img);  
imagedestroy($img);  
exit;
?>