<?php
// PHP代码必须放在最前面，不能有任何输出
require_once "./api/fn.php";
session();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>修改密码 · 抖音本地通消耗追踪</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <style>
    /* ====== DeepSeek风格CSS变量与重置 ====== */
    :root {
      /* DeepSeek主色调 */
      --primary-color: #10a37f;
      --primary-dark: #0d8c6d;
      --primary-light: #e6f7f2;
      
      /* 中性色调 */
      --gray-900: #1a1a1a;
      --gray-800: #2d2d2d;
      --gray-700: #404040;
      --gray-600: #666666;
      --gray-500: #8c8c8c;
      --gray-400: #b3b3b3;
      --gray-300: #d9d9d9;
      --gray-200: #e6e6e6;
      --gray-100: #f5f5f5;
      --gray-50: #fafafa;
      
      /* 功能色 */
      --success-color: #10a37f;
      --warning-color: #ff9800;
      --error-color: #f44336;
      --info-color: #2196f3;
      
      /* 排版 */
      --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      --font-family-mono: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Courier, monospace;
      
      /* 间距 */
      --spacing-xs: 4px;
      --spacing-sm: 8px;
      --spacing-md: 12px;
      --spacing-lg: 16px;
      --spacing-xl: 24px;
      --spacing-xxl: 32px;
      
      /* 圆角 */
      --radius-sm: 4px;
      --radius-md: 6px;
      --radius-lg: 8px;
      --radius-xl: 12px;
      --radius-full: 9999px;
      
      /* 阴影 */
      --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
      --shadow-md: 0 2px 8px rgba(0, 0, 0, 0.08);
      --shadow-lg: 0 4px 16px rgba(0, 0, 0, 0.12);
      
      /* 过渡 */
      --transition-fast: 150ms ease;
      --transition-normal: 250ms ease;
      --transition-slow: 350ms ease;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: var(--font-family);
      color: var(--gray-900);
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      line-height: 1.6;
      font-size: 14px;
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-md);
    }
    
    /* ====== 主容器 ====== */
    .auth-container {
      width: 100%;
      max-width: 420px;
      margin: 0 auto;
    }
    
    /* ====== 卡片样式 ====== */
    .auth-card {
      background-color: white;
      border-radius: var(--radius-xl);
      border: 1px solid var(--gray-200);
      box-shadow: var(--shadow-lg);
      overflow: hidden;
      transition: all var(--transition-normal);
    }
    
    .auth-card:hover {
      box-shadow: var(--shadow-lg);
    }
    
    .auth-header {
      padding: var(--spacing-xl) var(--spacing-xl) var(--spacing-lg);
      text-align: center;
      border-bottom: 1px solid var(--gray-100);
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      color: white;
    }
    
    .auth-header-icon {
      width: 48px;
      height: 48px;
      background-color: rgba(255, 255, 255, 0.2);
      border-radius: var(--radius-full);
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto var(--spacing-md);
    }
    
    .auth-title {
      font-size: 1.25rem;
      font-weight: 600;
      margin-bottom: var(--spacing-xs);
    }
    
    .auth-subtitle {
      font-size: 0.8125rem;
      color: rgba(255, 255, 255, 0.9);
      font-weight: 400;
    }
    
    .auth-body {
      padding: var(--spacing-xl);
    }
    
    /* ====== 表单样式 ====== */
    .form-group {
      margin-bottom: var(--spacing-lg);
    }
    
    .form-label {
      display: block;
      margin-bottom: var(--spacing-sm);
      font-weight: 500;
      color: var(--gray-700);
      font-size: 0.875rem;
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    .form-control-wrapper {
      position: relative;
    }
    
    .form-control {
      display: block;
      width: 100%;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      line-height: 1.5;
      color: var(--gray-900);
      background-color: white;
      border: 1px solid var(--gray-300);
      border-radius: var(--radius-md);
      transition: all var(--transition-fast);
      height: 40px;
    }
    
    .form-control:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(16, 163, 127, 0.1);
    }
    
    .form-control::placeholder {
      color: var(--gray-500);
    }
    
    .password-toggle {
      position: absolute;
      right: var(--spacing-md);
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      color: var(--gray-500);
      cursor: pointer;
      padding: 0;
      font-size: 1rem;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .password-toggle:hover {
      color: var(--gray-700);
    }
    
    /* ====== 密码强度指示器 ====== */
    .password-strength {
      margin-top: var(--spacing-xs);
    }
    
    .strength-bar {
      height: 3px;
      border-radius: var(--radius-sm);
      background-color: var(--gray-200);
      margin-top: var(--spacing-xs);
      overflow: hidden;
    }
    
    .strength-fill {
      height: 100%;
      width: 0%;
      transition: all var(--transition-normal);
    }
    
    .strength-fill.weak {
      width: 33%;
      background-color: var(--error-color);
    }
    
    .strength-fill.medium {
      width: 66%;
      background-color: var(--warning-color);
    }
    
    .strength-fill.strong {
      width: 100%;
      background-color: var(--success-color);
    }
    
    .strength-text {
      font-size: 0.75rem;
      color: var(--gray-600);
      display: flex;
      justify-content: space-between;
      margin-top: 2px;
    }
    
    /* ====== 密码提示 ====== */
    .password-tips {
      background-color: var(--primary-light);
      padding: var(--spacing-md);
      border-radius: var(--radius-md);
      margin: var(--spacing-lg) 0;
      border-left: 3px solid var(--primary-color);
    }
    
    .password-tips-title {
      font-size: 0.8125rem;
      font-weight: 600;
      color: var(--primary-dark);
      margin-bottom: var(--spacing-xs);
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    .password-tips-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .password-tips-list li {
      font-size: 0.75rem;
      color: var(--gray-700);
      margin-bottom: 4px;
      display: flex;
      align-items: center;
      gap: var(--spacing-xs);
    }
    
    .password-tips-list li:last-child {
      margin-bottom: 0;
    }
    
    .password-tips-list li::before {
      content: "•";
      color: var(--primary-color);
      font-weight: bold;
      font-size: 1rem;
    }
    
    /* ====== 按钮组 ====== */
    .btn-group {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--spacing-md);
      margin-top: var(--spacing-xl);
    }
    
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      font-weight: 500;
      line-height: 1.5;
      border-radius: var(--radius-md);
      border: 1px solid transparent;
      cursor: pointer;
      transition: all var(--transition-fast);
      text-decoration: none;
      gap: var(--spacing-sm);
      height: 40px;
    }
    
    .btn-primary {
      background-color: var(--primary-color);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      transform: translateY(-1px);
      box-shadow: var(--shadow-md);
    }
    
    .btn-secondary {
      background-color: white;
      color: var(--gray-700);
      border-color: var(--gray-300);
    }
    
    .btn-secondary:hover {
      background-color: var(--gray-100);
      border-color: var(--gray-400);
      transform: translateY(-1px);
    }
    
    /* ====== 动画效果 ====== */
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .fade-in {
      animation: fadeIn 0.4s ease forwards;
    }
    
    /* ====== 响应式设计 ====== */
    @media (max-width: 480px) {
      .auth-container {
        max-width: 100%;
      }
      
      .auth-header {
        padding: var(--spacing-lg) var(--spacing-lg) var(--spacing-md);
      }
      
      .auth-body {
        padding: var(--spacing-lg);
      }
      
      .btn-group {
        grid-template-columns: 1fr;
        gap: var(--spacing-sm);
      }
    }
    
    /* ====== 深色模式支持 ====== */
    @media (prefers-color-scheme: dark) {
      :root {
        --gray-900: #f5f5f5;
        --gray-800: #e6e6e6;
        --gray-700: #d9d9d9;
        --gray-600: #b3b3b3;
        --gray-500: #8c8c8c;
        --gray-400: #666666;
        --gray-300: #404040;
        --gray-200: #2d2d2d;
        --gray-100: #1a1a1a;
        --gray-50: #111111;
        
        --primary-light: rgba(16, 163, 127, 0.2);
      }
      
      body {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      }
      
      .auth-card {
        background-color: var(--gray-100);
        border-color: var(--gray-300);
      }
      
      .auth-header {
        background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      }
      
      .form-control {
        background-color: var(--gray-200);
        border-color: var(--gray-400);
        color: var(--gray-900);
      }
      
      .password-tips {
        background-color: rgba(16, 163, 127, 0.15);
        border-left-color: var(--primary-color);
      }
      
      .btn-secondary {
        background-color: var(--gray-200);
        border-color: var(--gray-400);
        color: var(--gray-800);
      }
      
      .btn-secondary:hover {
        background-color: var(--gray-300);
      }
      
      .strength-bar {
        background-color: var(--gray-400);
      }
    }
  </style>
</head>
<body>
  <div class="auth-container">
    <!-- 修改密码卡片 -->
    <div class="auth-card fade-in">
      <!-- 头部 -->
      <div class="auth-header">
        <div class="auth-header-icon">
          <span class="material-icons" style="font-size: 1.5rem; color: white;">lock</span>
        </div>
        <h1 class="auth-title">修改密码</h1>
        <p class="auth-subtitle">保护账户安全，建议定期更新</p>
      </div>
      
      <!-- 表单内容 -->
      <div class="auth-body">
        <form action="./temp/password_update.php" method="post" id="passwordForm">
          <!-- 旧密码 -->
          <div class="form-group">
            <label class="form-label">
              <span class="material-icons" style="font-size: 1rem;">lock_open</span>
              当前密码
            </label>
            <div class="form-control-wrapper">
              <input 
                type="password" 
                class="form-control" 
                name="password_j" 
                placeholder="请输入当前密码"
                value="<?= isset($_SESSION['password_j']) ? htmlspecialchars($_SESSION['password_j']) : ''; ?>"
                required
                autocomplete="current-password"
                autofocus>
            </div>
          </div>
          
          <!-- 新密码 -->
          <div class="form-group">
            <label class="form-label">
              <span class="material-icons" style="font-size: 1rem;">lock</span>
              新密码
            </label>
            <div class="form-control-wrapper">
              <input 
                type="password" 
                class="form-control" 
                name="password_x" 
                id="newPassword"
                placeholder="请输入新密码"
                value="<?= isset($_SESSION['password_x']) ? htmlspecialchars($_SESSION['password_x']) : ''; ?>"
                required
                autocomplete="new-password">
            </div>
            <div class="password-strength">
              <div class="strength-bar">
                <div class="strength-fill" id="passwordStrength"></div>
              </div>
              <div class="strength-text">
                <span id="passwordStrengthText">密码强度</span>
                <span id="passwordLengthText">0/6</span>
              </div>
            </div>
          </div>
          
          <!-- 密码提示 -->
          <div class="password-tips">
            <div class="password-tips-title">
              <span class="material-icons" style="font-size: 0.875rem;">info</span>
              密码要求
            </div>
            <ul class="password-tips-list">
              <li>长度：6-20位字符</li>
              <li>包含：数字和字母</li>
              <li>安全：不能与原密码相同</li>
            </ul>
          </div>
          
          <!-- 操作按钮 -->
          <div class="btn-group">
            <button type="submit" class="btn btn-primary">
              <span class="material-icons" style="font-size: 1rem;">check_circle</span>
              确认修改
            </button>
            <button type="reset" class="btn btn-secondary">
              <span class="material-icons" style="font-size: 1rem;">restart_alt</span>
              重置
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <?php
  // 清除session数据
  unset($_SESSION['password_j']);
  unset($_SESSION['password_x']);
  ?>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const newPasswordInput = document.getElementById('newPassword');
      const passwordStrength = document.getElementById('passwordStrength');
      const passwordStrengthText = document.getElementById('passwordStrengthText');
      const passwordLengthText = document.getElementById('passwordLengthText');
      const form = document.getElementById('passwordForm');
      
      // 密码强度检测
      newPasswordInput.addEventListener('input', function() {
        const password = this.value;
        const length = password.length;
        
        // 更新长度显示
        passwordLengthText.textContent = `${length}/6`;
        
        if (length === 0) {
          passwordStrength.className = 'strength-fill';
          passwordStrengthText.textContent = '密码强度';
          return;
        }
        
        if (length < 6) {
          passwordStrength.className = 'strength-fill weak';
          passwordStrengthText.textContent = '太短';
          return;
        }
        
        if (length > 20) {
          passwordStrength.className = 'strength-fill weak';
          passwordStrengthText.textContent = '太长';
          return;
        }
        
        // 检查密码复杂度
        const hasNumber = /\d/.test(password);
        const hasLower = /[a-z]/.test(password);
        const hasUpper = /[A-Z]/.test(password);
        const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
        
        let score = 0;
        if (hasNumber) score++;
        if (hasLower) score++;
        if (hasUpper) score++;
        if (hasSpecial) score++;
        
        if (score >= 3 && length >= 10) {
          passwordStrength.className = 'strength-fill strong';
          passwordStrengthText.textContent = '强';
        } else if (score >= 2) {
          passwordStrength.className = 'strength-fill medium';
          passwordStrengthText.textContent = '中';
        } else {
          passwordStrength.className = 'strength-fill weak';
          passwordStrengthText.textContent = '弱';
        }
      });
      
      // 表单提交验证
      form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const oldPassword = document.querySelector('input[name="password_j"]').value.trim();
        const newPassword = newPasswordInput.value.trim();
        
        // 验证非空
        if (oldPassword === '' || newPassword === '') {
          alert('密码不能为空！');
          return;
        }
        
        // 验证新旧密码是否一致
        if (oldPassword === newPassword) {
          alert('新旧密码不能相同！');
          return;
        }
        
        // 验证密码格式
        const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d!@#$%^&*(),.?":{}|<>]{6,20}$/;
        if (!passwordRegex.test(newPassword)) {
          alert('密码必须包含数字和字母，长度为6-20位');
          return;
        }
        
        // 确认对话框
        if (!confirm('确定要修改密码吗？修改后需要重新登录。')) {
          return;
        }
        
        // 提交表单
        this.submit();
      });
      
      // 重置表单事件
      form.addEventListener('reset', function() {
        // 清空密码强度显示
        passwordStrength.className = 'strength-fill';
        passwordStrengthText.textContent = '密码强度';
        passwordLengthText.textContent = '0/6';
        
        // 重新聚焦到旧密码输入框
        setTimeout(() => {
          document.querySelector('input[name="password_j"]').focus();
        }, 100);
      });
    });
  </script>
</body>
</html>