<?php
// PHP代码必须放在最前面，不能有任何输出
require_once "./api/fn.php";
session();

// 获取ID参数
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    echo "<script>alert('参数错误！'); window.location.href='home.php';</script>";
    exit;
}

// 获取详情数据
$detail = get_consumption_detail($id);

if (!$detail) {
    echo "<script>alert('数据不存在！'); window.location.href='home.php';</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>消耗详情 - <?= $detail['year'] ?>年<?= $detail['month'] ?>月 · 抖音本地通消耗追踪</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <style>
    /* ====== DeepSeek风格CSS变量与重置 ====== */
    :root {
      /* DeepSeek主色调 */
      --primary-color: #10a37f;
      --primary-dark: #0d8c6d;
      --primary-light: #e6f7f2;
      
      /* 中性色调 */
      --gray-900: #1a1a1a;
      --gray-800: #2d2d2d;
      --gray-700: #404040;
      --gray-600: #666666;
      --gray-500: #8c8c8c;
      --gray-400: #b3b3b3;
      --gray-300: #d9d9d9;
      --gray-200: #e6e6e6;
      --gray-100: #f5f5f5;
      --gray-50: #fafafa;
      
      /* 功能色 */
      --success-color: #10a37f;
      --warning-color: #ff9800;
      --error-color: #f44336;
      --info-color: #2196f3;
      --accent-color: #9c27b0;
      --budget-color: #2196f3;
      --consumption-color: #f44336;
      --leads-color: #9c27b0;
      --orders-color: #4caf50;
      
      /* 排版 */
      --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      --font-family-mono: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Courier, monospace;
      
      /* 间距 */
      --spacing-xs: 4px;
      --spacing-sm: 8px;
      --spacing-md: 12px;
      --spacing-lg: 16px;
      --spacing-xl: 24px;
      --spacing-xxl: 32px;
      
      /* 圆角 */
      --radius-sm: 4px;
      --radius-md: 6px;
      --radius-lg: 8px;
      --radius-xl: 12px;
      --radius-full: 9999px;
      
      /* 阴影 */
      --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
      --shadow-md: 0 2px 8px rgba(0, 0, 0, 0.08);
      --shadow-lg: 0 4px 16px rgba(0, 0, 0, 0.12);
      
      /* 过渡 */
      --transition-fast: 150ms ease;
      --transition-normal: 250ms ease;
      --transition-slow: 350ms ease;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: var(--font-family);
      color: var(--gray-900);
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      line-height: 1.6;
      font-size: 14px;
      padding: var(--spacing-lg);
      min-height: 100vh;
    }
    
    /* ====== 主容器 ====== */
    .main-container {
      max-width: 1200px;
      margin: 0 auto;
    }
    
    /* ====== 卡片样式 ====== */
    .card {
      background-color: white;
      border-radius: var(--radius-xl);
      border: 1px solid var(--gray-200);
      box-shadow: var(--shadow-lg);
      overflow: hidden;
      transition: all var(--transition-normal);
      margin-bottom: var(--spacing-lg);
    }
    
    .card:hover {
      box-shadow: var(--shadow-lg);
    }
    
    .card-header {
      padding: var(--spacing-xl);
      border-bottom: 1px solid var(--gray-200);
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .card-body {
      padding: var(--spacing-xl);
    }
    
    /* ====== 标题和文本 ====== */
    .page-title {
      font-size: 1.25rem;
      font-weight: 600;
      margin: 0;
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    .text-muted {
      color: var(--gray-600);
    }
    
    /* ====== 按钮样式 ====== */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      font-weight: 500;
      line-height: 1.5;
      border-radius: var(--radius-md);
      border: 1px solid transparent;
      cursor: pointer;
      transition: all var(--transition-fast);
      text-decoration: none;
      gap: var(--spacing-sm);
    }
    
    .btn-outline {
      background-color: transparent;
      color: white;
      border-color: rgba(255, 255, 255, 0.5);
    }
    
    .btn-outline:hover {
      background-color: rgba(255, 255, 255, 0.1);
      border-color: white;
      transform: translateY(-2px);
    }
    
    /* ====== 部分标题 ====== */
    .section-title {
      font-size: 1rem;
      font-weight: 600;
      color: var(--gray-900);
      margin-bottom: var(--spacing-lg);
      padding-bottom: var(--spacing-sm);
      border-bottom: 2px solid var(--gray-200);
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    /* ====== 统计卡片网格 ====== */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: var(--spacing-md);
      margin-bottom: var(--spacing-lg);
    }
    
    @media (max-width: 1200px) {
      .stats-grid {
        grid-template-columns: repeat(2, 1fr);
      }
    }
    
    @media (max-width: 768px) {
      .stats-grid {
        grid-template-columns: 1fr;
      }
    }
    
    .stat-card {
      background-color: white;
      border: 1px solid var(--gray-200);
      border-radius: var(--radius-lg);
      padding: var(--spacing-lg);
      transition: all var(--transition-normal);
      position: relative;
      overflow: hidden;
    }
    
    .stat-card:hover {
      border-color: var(--primary-color);
      transform: translateY(-4px);
      box-shadow: var(--shadow-md);
    }
    
    .stat-card::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 4px;
      height: 100%;
      background-color: var(--primary-color);
    }
    
    .stat-label {
      font-size: 0.8125rem;
      font-weight: 500;
      color: var(--gray-600);
      margin-bottom: var(--spacing-sm);
      display: flex;
      align-items: center;
      gap: var(--spacing-xs);
    }
    
    .stat-value {
      font-size: 1.5rem;
      font-weight: 600;
      color: var(--gray-900);
      line-height: 1.2;
    }
    
    .stat-value.budget {
      color: var(--budget-color);
    }
    
    .stat-value.consumption {
      color: var(--consumption-color);
    }
    
    .stat-value.leads {
      color: var(--leads-color);
    }
    
    .stat-value.orders {
      color: var(--orders-color);
    }
    
    .stat-value.success {
      color: var(--success-color);
    }
    
    .stat-value.warning {
      color: var(--warning-color);
    }
    
    .stat-value.danger {
      color: var(--error-color);
    }
    
    .stat-value.info {
      color: var(--info-color);
    }
    
    .stat-sub {
      font-size: 0.75rem;
      color: var(--gray-500);
      margin-top: var(--spacing-xs);
      line-height: 1.4;
    }
    
    /* ====== 进度条样式 ====== */
    .progress-container {
      margin-top: var(--spacing-md);
    }
    
    .progress-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--spacing-xs);
    }
    
    .progress-label {
      font-size: 0.75rem;
      color: var(--gray-600);
      font-weight: 500;
    }
    
    .progress-value {
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .progress-bar {
      width: 100%;
      height: 8px;
      background-color: var(--gray-200);
      border-radius: var(--radius-full);
      overflow: hidden;
    }
    
    .progress-fill {
      height: 100%;
      border-radius: var(--radius-full);
      transition: width 0.6s ease;
      position: relative;
    }
    
    .progress-fill.success {
      background: linear-gradient(90deg, var(--success-color), #0d8c6d);
    }
    
    .progress-fill.warning {
      background: linear-gradient(90deg, var(--warning-color), #e67e22);
    }
    
    .progress-fill.danger {
      background: linear-gradient(90deg, var(--error-color), #d32f2f);
    }
    
    .progress-fill.info {
      background: linear-gradient(90deg, var(--info-color), #1976d2);
    }
    
    /* ====== 汇总表格样式 ====== */
    .summary-table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
      background: white;
      border-radius: var(--radius-lg);
      overflow: hidden;
      border: 1px solid var(--gray-200);
    }
    
    .summary-table tr {
      transition: background-color var(--transition-fast);
    }
    
    .summary-table tr:hover {
      background-color: var(--gray-50);
    }
    
    .summary-table td {
      padding: var(--spacing-md);
      border-bottom: 1px solid var(--gray-200);
    }
    
    .summary-table tr:last-child td {
      border-bottom: none;
    }
    
    .summary-table td:first-child {
      width: 35%;
      font-weight: 600;
      color: var(--gray-700);
      background-color: var(--gray-50);
      border-right: 1px solid var(--gray-200);
    }
    
    /* ====== 每日明细表格样式 ====== */
    .daily-table-container {
      overflow-x: auto;
      border-radius: var(--radius-lg);
      border: 1px solid var(--gray-200);
      background: white;
    }
    
    .daily-table {
      width: 100%;
      border-collapse: collapse;
      min-width: 800px;
    }
    
    .daily-table th {
      padding: var(--spacing-md);
      font-weight: 600;
      font-size: 0.8125rem;
      color: var(--gray-700);
      background-color: var(--gray-50);
      border-bottom: 2px solid var(--gray-200);
      text-align: center;
      position: sticky;
      top: 0;
      z-index: 10;
    }
    
    .daily-table td {
      padding: var(--spacing-md);
      border-bottom: 1px solid var(--gray-200);
      text-align: center;
      font-size: 0.875rem;
    }
    
    .daily-table tbody tr {
      transition: background-color var(--transition-fast);
    }
    
    .daily-table tbody tr:hover {
      background-color: var(--gray-50);
    }
    
    .daily-table tbody tr:last-child td {
      border-bottom: none;
    }
    
    .daily-table .total-row {
      background: linear-gradient(135deg, var(--primary-light), #e6f7f2);
      font-weight: 600;
    }
    
    .daily-table .total-row td {
      color: var(--primary-dark);
    }
    
    .daily-table .total-row td:first-child {
      background-color: var(--primary-color);
      color: white;
    }
    
    .value-cell {
      font-weight: 500;
    }
    
    .value-cell.budget {
      color: var(--budget-color);
    }
    
    .value-cell.consumption {
      color: var(--consumption-color);
    }
    
    .value-cell.leads {
      color: var(--leads-color);
    }
    
    .value-cell.orders {
      color: var(--orders-color);
    }
    
    /* ====== 备注样式 ====== */
    .remarks-container {
      background-color: var(--primary-light);
      padding: var(--spacing-lg);
      border-radius: var(--radius-lg);
      border-left: 4px solid var(--primary-color);
      line-height: 1.6;
    }
    
    .remarks-content {
      color: var(--gray-800);
      font-size: 0.875rem;
    }
    
    /* ====== 动画效果 ====== */
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .fade-in {
      animation: fadeIn 0.4s ease forwards;
    }
    
    /* ====== 响应式设计 ====== */
    @media (max-width: 768px) {
      body {
        padding: var(--spacing-sm);
      }
      
      .main-container {
        max-width: 100%;
      }
      
      .card-header {
        padding: var(--spacing-lg);
        flex-direction: column;
        align-items: flex-start;
        gap: var(--spacing-md);
      }
      
      .card-body {
        padding: var(--spacing-lg);
      }
      
      .btn span:last-child:not(.material-icons) {
        display: none;
      }
      
      .btn .material-icons {
        margin-right: 0;
      }
    }
    
    /* ====== 深色模式支持 ====== */
    @media (prefers-color-scheme: dark) {
      :root {
        --gray-900: #f5f5f5;
        --gray-800: #e6e6e6;
        --gray-700: #d9d9d9;
        --gray-600: #b3b3b3;
        --gray-500: #8c8c8c;
        --gray-400: #666666;
        --gray-300: #404040;
        --gray-200: #2d2d2d;
        --gray-100: #1a1a1a;
        --gray-50: #111111;
        
        --primary-light: rgba(16, 163, 127, 0.2);
      }
      
      body {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      }
      
      .card {
        background-color: var(--gray-100);
        border-color: var(--gray-300);
      }
      
      .card-header {
        background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      }
      
      .stat-card {
        background-color: var(--gray-200);
        border-color: var(--gray-300);
      }
      
      .summary-table {
        background-color: var(--gray-200);
        border-color: var(--gray-300);
      }
      
      .summary-table td:first-child {
        background-color: var(--gray-300);
        border-color: var(--gray-400);
      }
      
      .daily-table-container {
        background-color: var(--gray-200);
        border-color: var(--gray-300);
      }
      
      .daily-table th {
        background-color: var(--gray-300);
        border-color: var(--gray-400);
      }
      
      .daily-table td {
        border-color: var(--gray-300);
      }
      
      .daily-table .total-row {
        background: linear-gradient(135deg, rgba(16, 163, 127, 0.2), rgba(16, 163, 127, 0.1));
      }
      
      .remarks-container {
        background-color: rgba(16, 163, 127, 0.15);
        border-left-color: var(--primary-color);
      }
    }
  </style>
</head>
<body>
  <div class="main-container">
    <!-- 页面标题 -->
    <div class="card fade-in">
      <div class="card-header">
        <h1 class="page-title">
          <span class="material-icons">analytics</span>
          消耗详情 - <?= $detail['year'] ?>年<?= $detail['month'] ?>月
        </h1>
        <a href="home.php" class="btn btn-outline">
          <span class="material-icons" style="font-size: 1rem;">arrow_back</span>
          返回列表
        </a>
      </div>
    </div>

    <!-- 预算统计 -->
    <div class="card fade-in" style="animation-delay: 0.1s;">
      <div class="card-body">
        <div class="section-title">
          <span class="material-icons">account_balance_wallet</span>
          预算统计
        </div>
        
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">request_quote</span>
              本月消耗预算
            </div>
            <div class="stat-value budget">¥<?= number_format($detail['budget'], 2) ?></div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">money_off</span>
              已消耗金额
            </div>
            <div class="stat-value consumption">¥<?= number_format($detail['total_consumption'], 2) ?></div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">account_balance</span>
              剩余预算
            </div>
            <div class="stat-value <?= $detail['remaining_budget'] > 0 ? 'success' : 'danger' ?>">
              ¥<?= number_format($detail['remaining_budget'], 2) ?>
            </div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">trending_up</span>
              预算使用率
            </div>
            <div class="stat-value <?= $detail['budget_usage_rate'] > 100 ? 'danger' : ($detail['budget_usage_rate'] > 80 ? 'warning' : 'success') ?>">
              <?= number_format($detail['budget_usage_rate'], 1) ?>%
            </div>
            <div class="progress-container">
              <div class="progress-header">
                <span class="progress-label">使用进度</span>
                <span class="progress-value"><?= number_format(min($detail['budget_usage_rate'], 100), 1) ?>%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill <?= $detail['budget_usage_rate'] > 100 ? 'danger' : ($detail['budget_usage_rate'] > 80 ? 'warning' : 'success') ?>" 
                     style="width: <?= min($detail['budget_usage_rate'], 100) ?>%;"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 线索统计 -->
    <div class="card fade-in" style="animation-delay: 0.2s;">
      <div class="card-body">
        <div class="section-title">
          <span class="material-icons">person_search</span>
          线索统计
        </div>
        
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">assignment</span>
              月度线索任务
            </div>
            <div class="stat-value"><?= number_format($detail['task_quantity']) ?> 条</div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">people</span>
              本月已有线索
            </div>
            <div class="stat-value info"><?= number_format($detail['total_leads']) ?> 条</div>
            <div class="stat-sub">
              自然线索: <?= number_format($detail['total_natural_leads']) ?> | 
              广告线索: <?= number_format($detail['total_ad_leads']) ?>
            </div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">compare</span>
              月度线索差额
            </div>
            <div class="stat-value <?= $detail['leads_diff'] <= 0 ? 'success' : 'warning' ?>">
              <?= $detail['leads_diff'] > 0 ? '' : '' ?><?= number_format($detail['leads_diff']) ?> 条
            </div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">task_alt</span>
              线索任务完成率
            </div>
            <div class="stat-value <?= $detail['leads_completion_rate'] >= 100 ? 'success' : 'warning' ?>">
              <?= number_format($detail['leads_completion_rate'], 1) ?>%
            </div>
            <div class="progress-container">
              <div class="progress-header">
                <span class="progress-label">完成进度</span>
                <span class="progress-value"><?= number_format(min($detail['leads_completion_rate'], 100), 1) ?>%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill <?= $detail['leads_completion_rate'] >= 100 ? 'success' : 'warning' ?>" 
                     style="width: <?= min($detail['leads_completion_rate'], 100) ?>%;"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 订单统计 -->
    <div class="card fade-in" style="animation-delay: 0.3s;">
      <div class="card-body">
        <div class="section-title">
          <span class="material-icons">shopping_cart</span>
          订单统计
        </div>
        
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">target</span>
              本月订单目标
            </div>
            <div class="stat-value"><?= number_format($detail['target_volume']) ?> 单</div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">check_circle</span>
              本月订单数
            </div>
            <div class="stat-value success"><?= number_format($detail['total_orders']) ?> 单</div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">trending_up</span>
              订单完成率
            </div>
            <div class="stat-value <?= $detail['order_completion_rate'] >= 100 ? 'success' : 'warning' ?>">
              <?= number_format($detail['order_completion_rate'], 1) ?>%
            </div>
            <div class="progress-container">
              <div class="progress-header">
                <span class="progress-label">完成进度</span>
                <span class="progress-value"><?= number_format(min($detail['order_completion_rate'], 100), 1) ?>%</span>
              </div>
              <div class="progress-bar">
                <div class="progress-fill <?= $detail['order_completion_rate'] >= 100 ? 'success' : 'warning' ?>" 
                     style="width: <?= min($detail['order_completion_rate'], 100) ?>%;"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 成本分析 -->
    <div class="card fade-in" style="animation-delay: 0.4s;">
      <div class="card-body">
        <div class="section-title">
          <span class="material-icons">attach_money</span>
          成本分析
        </div>
        
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">calculate</span>
              总线索成本
            </div>
            <div class="stat-value">¥<?= number_format($detail['cost_per_lead'], 2) ?></div>
            <div class="stat-sub">已消耗 ÷ 本月已有线索</div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">monetization_on</span>
              订单成本
            </div>
            <div class="stat-value">¥<?= number_format($detail['cost_per_order'], 2) ?></div>
            <div class="stat-sub">已消耗 ÷ 订单数</div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">ads_click</span>
              广告线索数量
            </div>
            <div class="stat-value info"><?= number_format($detail['total_ad_leads']) ?> 条</div>
          </div>
          
          <div class="stat-card">
            <div class="stat-label">
              <span class="material-icons" style="font-size: 0.875rem;">paid</span>
              广告线索成本
            </div>
            <div class="stat-value">¥<?= number_format($detail['ad_leads_cost'], 2) ?></div>
            <div class="stat-sub">已消耗 ÷ 广告线索数量</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 备注信息 -->
    <?php if (!empty($detail['remarks'])): ?>
    <div class="card fade-in" style="animation-delay: 0.5s;">
      <div class="card-body">
        <div class="section-title">
          <span class="material-icons">description</span>
          备注信息
        </div>
        <div class="remarks-container">
          <div class="remarks-content">
            <?= nl2br(htmlspecialchars($detail['remarks'])) ?>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- 汇总信息表 -->
    <div class="card fade-in" style="animation-delay: 0.6s;">
      <div class="card-body">
        <div class="section-title">
          <span class="material-icons">summarize</span>
          数据汇总
        </div>
        
        <table class="summary-table">
          <tbody>
            <tr>
              <td>统计年月</td>
              <td><strong><?= $detail['year'] ?>年<?= $detail['month'] ?>月</strong></td>
            </tr>
            <tr>
              <td>本月消耗预算</td>
              <td><strong class="value-cell budget">¥<?= number_format($detail['budget'], 2) ?></strong></td>
            </tr>
            <tr>
              <td>已消耗金额</td>
              <td><strong class="value-cell consumption">¥<?= number_format($detail['total_consumption'], 2) ?></strong></td>
            </tr>
            <tr>
              <td>剩余预算</td>
              <td><strong class="<?= $detail['remaining_budget'] > 0 ? 'value-cell success' : 'value-cell danger' ?>">¥<?= number_format($detail['remaining_budget'], 2) ?></strong></td>
            </tr>
            <tr>
              <td>预算使用率</td>
              <td><strong class="<?= $detail['budget_usage_rate'] > 100 ? 'value-cell danger' : ($detail['budget_usage_rate'] > 80 ? 'value-cell warning' : 'value-cell success') ?>"><?= number_format($detail['budget_usage_rate'], 1) ?>%</strong></td>
            </tr>
            <tr>
              <td>月度线索任务</td>
              <td><strong><?= number_format($detail['task_quantity']) ?> 条</strong></td>
            </tr>
            <tr>
              <td>本月已有线索</td>
              <td><strong class="value-cell info"><?= number_format($detail['total_leads']) ?> 条</strong> (自然: <?= number_format($detail['total_natural_leads']) ?> + 广告: <?= number_format($detail['total_ad_leads']) ?>)</td>
            </tr>
            <tr>
              <td>线索任务完成率</td>
              <td><strong class="<?= $detail['leads_completion_rate'] >= 100 ? 'value-cell success' : 'value-cell warning' ?>"><?= number_format($detail['leads_completion_rate'], 1) ?>%</strong></td>
            </tr>
            <tr>
              <td>本月订单目标</td>
              <td><strong><?= number_format($detail['target_volume']) ?> 单</strong></td>
            </tr>
            <tr>
              <td>本月订单数</td>
              <td><strong class="value-cell success"><?= number_format($detail['total_orders']) ?> 单</strong></td>
            </tr>
            <tr>
              <td>订单完成率</td>
              <td><strong class="<?= $detail['order_completion_rate'] >= 100 ? 'value-cell success' : 'value-cell warning' ?>"><?= number_format($detail['order_completion_rate'], 1) ?>%</strong></td>
            </tr>
            <tr>
              <td>总线索成本</td>
              <td><strong>¥<?= number_format($detail['cost_per_lead'], 2) ?> / 条</strong></td>
            </tr>
            <tr>
              <td>订单成本</td>
              <td><strong>¥<?= number_format($detail['cost_per_order'], 2) ?> / 单</strong></td>
            </tr>
            <tr>
              <td>广告线索数量</td>
              <td><strong><?= number_format($detail['total_ad_leads']) ?> 条</strong></td>
            </tr>
            <tr>
              <td>广告线索成本</td>
              <td><strong>¥<?= number_format($detail['ad_leads_cost'], 2) ?> / 条</strong></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- 每日业务明细 -->
    <div class="card fade-in" style="animation-delay: 0.7s;">
      <div class="card-body">
        <div class="section-title">
          <span class="material-icons">calendar_today</span>
          每日业务明细
        </div>
        
        <div class="daily-table-container">
          <table class="daily-table">
            <thead>
              <tr>
                <th>日期</th>
                <th>自然线索</th>
                <th>广告线索</th>
                <th>日消耗 (元)</th>
                <th>订单数量</th>
                <th>当日总线索</th>
                <th>线索成本 (元)</th>
              </tr>
            </thead>
            <tbody>
              <?php 
              $total_natural = 0;
              $total_ad = 0;
              $total_consumption = 0;
              $total_orders = 0;
              $total_leads = 0;
              $total_cost_sum = 0;
              
              foreach ($detail['daily_details'] as $daily): 
                $day_total_leads = intval($daily['natural_leads']) + intval($daily['ad_leads']);
                $day_cost_per_lead = $day_total_leads > 0 ? floatval($daily['daily_consumption']) / $day_total_leads : 0;
                
                $total_natural += intval($daily['natural_leads']);
                $total_ad += intval($daily['ad_leads']);
                $total_consumption += floatval($daily['daily_consumption']);
                $total_orders += intval($daily['order_quantity']);
                $total_leads += $day_total_leads;
                $total_cost_sum += $day_cost_per_lead;
              ?>
              <tr>
                <td><strong><?= $detail['month'] ?>月<?= $daily['day_of_month'] ?>日</strong></td>
                <td><?= number_format($daily['natural_leads']) ?></td>
                <td><?= number_format($daily['ad_leads']) ?></td>
                <td class="value-cell consumption">¥<?= number_format($daily['daily_consumption'], 2) ?></td>
                <td><?= number_format($daily['order_quantity']) ?></td>
                <td class="value-cell leads"><?= number_format($day_total_leads) ?></td>
                <td class="value-cell">¥<?= $day_total_leads > 0 ? number_format($day_cost_per_lead, 2) : '0.00' ?></td>
              </tr>
              <?php endforeach; ?>
              
              <!-- 合计行 -->
              <tr class="total-row">
                <td>合计</td>
                <td class="value-cell leads"><?= number_format($total_natural) ?></td>
                <td class="value-cell leads"><?= number_format($total_ad) ?></td>
                <td class="value-cell consumption">¥<?= number_format($total_consumption, 2) ?></td>
                <td class="value-cell orders"><?= number_format($total_orders) ?></td>
                <td class="value-cell leads"><?= number_format($total_leads) ?></td>
                <td class="value-cell">¥<?= number_format($total_cost_sum, 2) ?></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</body>
</html>