<?php
require_once "../api/fn.php";
session();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $password_confirm = isset($_POST['password_confirm']) ? trim($_POST['password_confirm']) : '';

    // 验证必填字段
    if (empty($name) || empty($password)) {
        echo "<script>alert('用户名和密码不能为空！'); history.back();</script>";
        exit;
    }

    // 验证密码一致性
    if ($password !== $password_confirm) {
        echo "<script>alert('两次输入的密码不一致！'); history.back();</script>";
        exit;
    }

    // 验证密码长度
    if (strlen($password) < 6) {
        echo "<script>alert('密码长度至少为6位！'); history.back();</script>";
        exit;
    }
    // 盐值
    $yan = bin2hex(random_bytes(16));
    // 加密
    $password = password_hash($password . $yan, PASSWORD_DEFAULT);

    // 调用添加函数
    $result = add_user($name, $password, $yan);


    if ($result) {
        echo "<script>alert('用户添加成功！'); window.location.href='../user_list.php';</script>";
    } else {
        echo "<script>alert('用户名已存在！'); history.back();</script>";
    }
} else {
    header('Location: ../user_list.php');
    exit;
}
