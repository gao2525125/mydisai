<?php
session_start();
if (!isset($_SESSION['user_name'])) {
    ?>
    <script type="text/javascript">
        alert('请先登入');
        window.location.href = './login.php';
    </script>
    <?php
    exit;
}
require_once "./api/fn.php";

// 获取当前年月
$current_year = date('Y');
$current_month = date('n');

// 获取当月数据
$data = get_current_month_data($current_year, $current_month);

if (!$data) {
    echo "<script>alert('当前月份暂无配置数据！请联系管理员添加。');</script>";
    $data = array(
        'config' => array(
            'year' => $current_year,
            'month' => $current_month,
            'budget' => 0,
            'task_quantity' => 0,
            'target_volume' => 0,
            'remarks' => '暂无数据'
        ),
        'details' => array(),
        'nodes' => array(),
        'summary' => array(
            'total_consumption' => 0,
            'total_natural_leads' => 0,
            'total_ad_leads' => 0,
            'total_orders' => 0,
            'total_leads' => 0,
            'remaining_budget' => 0,
            'budget_usage_rate' => 0,
            'leads_diff' => 0,
            'leads_completion_rate' => 0,
            'order_completion_rate' => 0,
            'cost_per_lead' => 0
        )
    );
}

$config = $data['config'];
$details = $data['details'];
$nodes = $data['nodes'];
$summary = $data['summary'];
?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>中国星-抖音本地通每日消耗进度追踪表</title>
    <script src="./js/xlsx.full.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Microsoft YaHei', Arial, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            padding: 25px;
        }

        header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #eaeaea;
        }

        h1 {
            color: #ff2e63;
            margin-bottom: 10px;
            font-size: 28px;
        }

        .description {
            color: #666;
            font-size: 16px;
            max-width: 800px;
            margin: 0 auto;
        }

        .controls {
            display: flex;
            justify-content: space-between;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .button-group {
            display: flex;
            gap: 10px;
        }

        button {
            padding: 10px 20px;
            background-color: #4a6cf7;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
        }

        button:hover {
            background-color: #3050d8;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        #saveBtn {
            background-color: #10b981;
        }

        #saveBtn:hover {
            background-color: #0da271;
        }

        #downloadBtn {
            background-color: #3b82f6;
        }

        #downloadBtn:hover {
            background-color: #2563eb;
        }

        #adminBtn {
            background-color: #8b5cf6;
        }

        #adminBtn:hover {
            background-color: #7c3aed;
        }

        .month-selector {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .month-selector label {
            font-weight: bold;
            color: #555;
        }

        .month-selector select,
        .month-selector input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .table-container {
            overflow-x: auto;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #e0e0e0;
            padding: 12px 8px;
            text-align: center;
            font-size: 14px;
        }

        th {
            background-color: #f8f9fa;
            font-weight: bold;
            color: #444;
        }

        .section-title {
            background-color: #f0f7ff;
            font-weight: bold;
            text-align: left;
            padding-left: 15px;
            color: #4a6cf7;
            font-size: 18px;
            padding: 15px;
            margin-top: 20px;
            border-radius: 5px;
            border-left: 5px solid #4a6cf7;
        }

        .summary-row {
            background-color: #f9f9f9;
            font-weight: bold;
        }

        .highlight {
            background-color: #e8f5e9;
        }

        .warning {
            background-color: #fff3e0;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            text-align: center;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        input[type="date"]:focus {
            outline: none;
            border-color: #4a6cf7;
            box-shadow: 0 0 0 2px rgba(74, 108, 247, 0.2);
        }

        .calculations {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            border-left: 4px solid #10b981;
        }

        .calculations h3 {
            margin-bottom: 10px;
            color: #10b981;
        }

        .calculations div {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding-bottom: 8px;
            border-bottom: 1px dashed #ddd;
        }

        .calculations span {
            font-weight: bold;
            color: #4a6cf7;
        }

        .admin-info {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
            border-left: 4px solid #f59e0b;
        }

        .admin-info h3 {
            margin-bottom: 10px;
            color: #f59e0b;
        }

        .admin-info .item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding-bottom: 8px;
            border-bottom: 1px dashed #ddd;
        }

        .admin-info .item span:first-child {
            font-weight: bold;
            color: #666;
        }

        .admin-info .item span:last-child {
            font-weight: bold;
            color: #4a6cf7;
        }

        .remarks-section {
            background-color: #f0f9ff;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            border-left: 4px solid #3b82f6;
        }

        .remarks-section h3 {
            margin-bottom: 15px;
            color: #3b82f6;
        }

        #remarksContent {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 18px;
            line-height: 1.5;
            background-color: #fff;
            min-height: 40px;
        }

        .status-message {
            padding: 12px 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: center;
            display: none;
        }

        .status-message.success {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
            display: block;
        }

        .status-message.error {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
            display: block;
        }

        footer {
            text-align: center;
            margin-top: 30px;
            color: #888;
            font-size: 14px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .readonly-cell {
            background-color: #f8f9fa;
            padding: 8px;
            border-radius: 4px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .controls {
                flex-direction: column;
            }

            .button-group {
                justify-content: center;
            }

            .month-selector {
                justify-content: center;
            }

            th,
            td {
                padding: 8px 5px;
                font-size: 12px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <h1>中国星<?= $config['year'] ?>年<?= $config['month'] ?>月本地通数据进度追踪表</h1>
            <p class="description">本表格用于追踪抖音本地通账户的每日消耗进度、预算使用情况、线索获取数据及核销节点管理。</p>
        </header>

        <div class="controls">
            <div class="month-selector">
                <label>当前月份：</label>
                <strong
                    style="font-size: 18px; color: #4a6cf7;"><?= $config['year'] ?>年<?= $config['month'] ?>月</strong>
            </div>

            <div class="button-group">
                <button id="saveBtn" type="button" onclick="saveData()">提交每日数据</button>
                <button id="downloadBtn" type="button" onclick="downloadExcel()">下载Excel表格</button>
                <button  type="button" style="background-color: #c73e3a;" onclick="window.location.href='./temp/xiaohui.php'">退出登入</button>
            </div>
        </div>

        <div id="statusMessage" class="status-message"></div>

        <div class="table-container">
                       <!-- 核销节点追踪 -->
            <div class="section-title">核销节点追踪（后端填写）</div>
            <table id="verificationTable">
                <thead>
                    <tr>
                        <th>核销节点</th>
                        <th>核销日期</th>
                        <th>核销金额 (元)</th>
                        <th>统计日期范围</th>
                        <th>已消耗金额 (元)</th>
                        <th>消耗差额 (元)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($nodes) > 0): ?>
                        <?php foreach ($nodes as $index => $node): ?>
                            <tr>
                                <td>节点 <?= $index + 1 ?></td>
                                <td><?= date('Y-m-d', strtotime($node['write_off_date'])) ?></td>
                                <td>¥<?= number_format($node['amount'], 2) ?></td>
                                <td><?= $node['start_date'] ?>日 - <?= $node['end_date'] ?>日</td>
                                <td style="color: #3b82f6; font-weight: bold;">
                                    ¥<?= number_format($node['consumed_amount'], 2) ?></td>
                                <td
                                    style="color: <?= $node['consumption_diff'] >= 0 ? '#10b981' : '#c73e3a' ?>; font-weight: bold;">
                                    ¥<?= number_format($node['consumption_diff'], 2) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #999;">暂无核销节点数据</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <!-- 备注内容 -->
            <div class="remarks-section">
                <h3>备注内容</h3>
                <div id="remarksContent">
                    <?= !empty($config['remarks']) ? nl2br(htmlspecialchars($config['remarks'])) : '暂无备注内容' ?></div>
            </div>
            <!-- 每日消耗与线索明细 -->
            <div class="section-title">每日消耗与线索明细</div>
            <form id="dailyForm" method="post" action="./temp/save_daily.php">
                <table id="dailyTable">
                    <thead>
                        <tr>
                            <th>日期</th>
                            <th>自然线索</th>
                            <th>广告线索</th>
                            <th>当日消耗 (元)</th>
                            <th>订单数</th>
                            <th>当日总线索</th>
                            <th>线索成本 (元)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($details as $detail):
                            $day_total_leads = intval($detail['natural_leads']) + intval($detail['ad_leads']);
                            $day_cost = $day_total_leads > 0 ? floatval($detail['daily_consumption']) / $day_total_leads : 0;
                            ?>
                            <tr>
                                <td><strong><?= $config['month'] ?>月<?= $detail['day_of_month'] ?>日</strong></td>
                                <td>
                                    <input type="hidden" name="details[<?= $detail['id'] ?>][id]"
                                        value="<?= $detail['id'] ?>">
                                    <input type="number" name="details[<?= $detail['id'] ?>][natural_leads]"
                                        value="<?= $detail['natural_leads'] ?>" min="0" class="detail-input"
                                        onchange="calculateRow(this)">
                                </td>
                                <td>
                                    <input type="number" name="details[<?= $detail['id'] ?>][ad_leads]"
                                        value="<?= $detail['ad_leads'] ?>" min="0" class="detail-input"
                                        onchange="calculateRow(this)">
                                </td>
                                <td>
                                    <input type="number" name="details[<?= $detail['id'] ?>][daily_consumption]"
                                        value="<?= $detail['daily_consumption'] ?>" step="0.01" min="0" class="detail-input"
                                        onchange="calculateRow(this)">
                                </td>
                                <td>
                                    <input type="number" name="details[<?= $detail['id'] ?>][order_quantity]"
                                        value="<?= $detail['order_quantity'] ?>" min="0" class="detail-input">
                                </td>
                                <td class="readonly-cell"><?= number_format($day_total_leads) ?></td>
                                <td class="readonly-cell">¥<?= number_format($day_cost, 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>
        </div>

        <footer>
            <p>抖音本地通消耗进度追踪系统 &copy; 2025 | 版本：1.0</p>
        </footer>
    </div>

    <script>
        // 保存数据
        function saveData() {
            if (confirm('确定要提交当前填写的每日数据吗？')) {
                document.getElementById('dailyForm').submit();
            }
        }

        // 计算行数据（当输入改变时）
        function calculateRow(input) {
            const row = input.closest('tr');
            const naturalLeads = parseInt(row.querySelector('input[name*="[natural_leads]"]').value) || 0;
            const adLeads = parseInt(row.querySelector('input[name*="[ad_leads]"]').value) || 0;
            const dailyConsumption = parseFloat(row.querySelector('input[name*="[daily_consumption]"]').value) || 0;

            const totalLeads = naturalLeads + adLeads;
            const leadCost = totalLeads > 0 ? (dailyConsumption / totalLeads) : 0;

            // 更新只读单元格
            const cells = row.querySelectorAll('.readonly-cell');
            if (cells[0]) cells[0].textContent = totalLeads.toLocaleString();
            if (cells[1]) cells[1].textContent = '¥' + leadCost.toFixed(2);
        }

        // 下载Excel
        function downloadExcel() {
            window.location.href = './temp/excel.php';
        }
    </script>
</body>

</html>