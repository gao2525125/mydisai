<?php  
require_once "../api/fn.php"; 
// session();
  session_start();
// 生成一个四位数验证码  
$code = rand(1000, 9999);  
  
// 将验证码保存到会话中  
$_SESSION['captcha'] = $code;  
  
// 创建一个 100x30 的画布  
$img = imagecreatetruecolor(100, 30);  
  
// 设置背景色为白色  
$bgColor = imagecolorallocate($img, 255, 255, 255);  
imagefill($img, 0, 0, $bgColor);  
  
// 设置数字的颜色  
$colors = [  
    imagecolorallocate($img, 0, 0, 0), // 黑色  
    imagecolorallocate($img, 255, 0, 0), // 红色  
    imagecolorallocate($img, 0, 255, 0), // 绿色  
    imagecolorallocate($img, 0, 0, 255) // 蓝色  
];  
  
// 绘制每个数字  
$x = 10; // 起始x坐标  
for ($i = 0; $i < 4; $i++) {  
    $digit = (int)($code / pow(10, 3 - $i)) % 10; // 获取每一位数字  
    $color = $colors[$i % count($colors)]; // 选择颜色  
    imagechar($img, 5, $x + ($i * 20), 5, $digit, $color); // 绘制数字  
}  
  
// 干扰线（可选）  
// ...  
  
// 输出图像  
header('Content-type: image/png');  
imagepng($img);  
  
// 清理资源  
imagedestroy($img);  
?>  