<?php
// PHP代码必须放在最前面，不能有任何输出
require_once "./api/fn.php";
session();

// 获取用户ID
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    echo "<script>alert('参数错误！'); window.location.href='user_list.php';</script>";
    exit;
}

// 获取用户信息
$user = get_user_by_id($id);

if (!$user) {
    echo "<script>alert('用户不存在！'); window.location.href='user_list.php';</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>编辑用户 · 抖音本地通消耗追踪</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <style>
    /* ====== DeepSeek风格CSS变量与重置 ====== */
    :root {
      /* DeepSeek主色调 */
      --primary-color: #10a37f;
      --primary-dark: #0d8c6d;
      --primary-light: #e6f7f2;
      
      /* 中性色调 */
      --gray-900: #1a1a1a;
      --gray-800: #2d2d2d;
      --gray-700: #404040;
      --gray-600: #666666;
      --gray-500: #8c8c8c;
      --gray-400: #b3b3b3;
      --gray-300: #d9d9d9;
      --gray-200: #e6e6e6;
      --gray-100: #f5f5f5;
      --gray-50: #fafafa;
      
      /* 功能色 */
      --success-color: #10a37f;
      --warning-color: #ff9800;
      --error-color: #f44336;
      --info-color: #2196f3;
      
      /* 排版 */
      --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      --font-family-mono: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Courier, monospace;
      
      /* 间距 */
      --spacing-xs: 4px;
      --spacing-sm: 8px;
      --spacing-md: 16px;
      --spacing-lg: 24px;
      --spacing-xl: 32px;
      --spacing-xxl: 48px;
      
      /* 圆角 */
      --radius-sm: 4px;
      --radius-md: 8px;
      --radius-lg: 12px;
      --radius-xl: 16px;
      --radius-full: 9999px;
      
      /* 阴影 */
      --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.05);
      --shadow-md: 0 4px 16px rgba(0, 0, 0, 0.1);
      --shadow-lg: 0 8px 32px rgba(0, 0, 0, 0.12);
      
      /* 过渡 */
      --transition-fast: 150ms ease;
      --transition-normal: 250ms ease;
      --transition-slow: 350ms ease;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: var(--font-family);
      color: var(--gray-900);
      background-color: var(--gray-50);
      line-height: 1.6;
      font-size: 16px;
      padding: var(--spacing-md);
      min-height: 100vh;
    }
    
    /* ====== 卡片样式 ====== */
    .card {
      background-color: white;
      border-radius: var(--radius-lg);
      border: 1px solid var(--gray-200);
      box-shadow: var(--shadow-sm);
      overflow: hidden;
      transition: box-shadow var(--transition-normal), transform var(--transition-normal);
      margin-bottom: var(--spacing-lg);
    }
    
    .card:hover {
      box-shadow: var(--shadow-md);
    }
    
    .card-header {
      padding: var(--spacing-lg);
      border-bottom: 1px solid var(--gray-200);
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .card-body {
      padding: var(--spacing-lg);
    }
    
    /* ====== 标题和文本 ====== */
    .page-title {
      font-size: 1.75rem;
      font-weight: 600;
      margin: 0;
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    .text-muted {
      color: var(--gray-600);
    }
    
    .text-center {
      text-align: center;
    }
    
    /* ====== 按钮样式 ====== */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      font-weight: 500;
      line-height: 1.5;
      border-radius: var(--radius-md);
      border: 1px solid transparent;
      cursor: pointer;
      transition: all var(--transition-fast);
      text-decoration: none;
      gap: var(--spacing-sm);
    }
    
    .btn-primary {
      background-color: var(--primary-color);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      color: white;
      text-decoration: none;
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .btn-outline {
      background-color: transparent;
      color: var(--primary-color);
      border-color: var(--gray-300);
    }
    
    .btn-outline:hover {
      background-color: var(--primary-light);
      color: var(--primary-dark);
      text-decoration: none;
      border-color: var(--primary-color);
      transform: translateY(-2px);
    }
    
    /* ====== 表单样式 ====== */
    .form-control {
      display: block;
      width: 100%;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      line-height: 1.5;
      color: var(--gray-900);
      background-color: white;
      border: 1px solid var(--gray-300);
      border-radius: var(--radius-md);
      transition: border-color var(--transition-fast), box-shadow var(--transition-fast);
    }
    
    .form-control:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(16, 163, 127, 0.1);
    }
    
    .form-control::placeholder {
      color: var(--gray-500);
    }
    
    /* ====== 表单布局 ====== */
    .form-table {
      width: 100%;
      border-collapse: collapse;
    }
    
    .form-table td {
      padding: var(--spacing-md) var(--spacing-sm);
      vertical-align: top;
    }
    
    .form-table tr:not(:last-child) {
      border-bottom: 1px solid var(--gray-200);
    }
    
    .form-label {
      font-weight: 600;
      color: var(--gray-700);
      white-space: nowrap;
      padding-right: var(--spacing-md);
    }
    
    .form-label .required {
      color: var(--error-color);
      margin-left: 2px;
    }
    
    .form-input-wrapper {
      width: 100%;
    }
    
    /* ====== 表单组样式 ====== */
    .form-group {
      margin-bottom: var(--spacing-lg);
    }
    
    .form-help-text {
      display: block;
      margin-top: var(--spacing-xs);
      font-size: 0.75rem;
      color: var(--gray-600);
    }
    
    /* ====== 表单操作区域 ====== */
    .form-actions {
      margin-top: var(--spacing-xl);
      padding-top: var(--spacing-lg);
      border-top: 2px solid var(--gray-200);
      display: flex;
      gap: var(--spacing-sm);
      justify-content: flex-end;
    }
    
    /* ====== 动画效果 ====== */
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .fade-in {
      animation: fadeIn 0.5s ease forwards;
    }
    
    /* ====== 密码强度指示器 ====== */
    .password-strength {
      margin-top: var(--spacing-xs);
    }
    
    .strength-bar {
      height: 4px;
      border-radius: var(--radius-sm);
      background-color: var(--gray-300);
      margin-top: var(--spacing-xs);
      overflow: hidden;
    }
    
    .strength-fill {
      height: 100%;
      width: 0%;
      background-color: var(--error-color);
      transition: all var(--transition-normal);
    }
    
    .strength-fill.weak {
      width: 33%;
      background-color: var(--error-color);
    }
    
    .strength-fill.medium {
      width: 66%;
      background-color: var(--warning-color);
    }
    
    .strength-fill.strong {
      width: 100%;
      background-color: var(--success-color);
    }
    
    /* ====== 响应式设计 ====== */
    @media (max-width: 768px) {
      body {
        padding: var(--spacing-sm);
      }
      
      .card-header,
      .card-body {
        padding: var(--spacing-md);
      }
      
      .form-table {
        display: block;
      }
      
      .form-table tr {
        display: flex;
        flex-direction: column;
        padding: var(--spacing-md) 0;
      }
      
      .form-table td {
        padding: var(--spacing-xs) 0;
        width: 100%;
      }
      
      .form-label {
        padding-right: 0;
        margin-bottom: var(--spacing-sm);
      }
      
      .form-actions {
        flex-direction: column;
      }
      
      .form-actions .btn {
        width: 100%;
        justify-content: center;
      }
    }
    
    @media (max-width: 576px) {
      .page-title {
        font-size: 1.5rem;
      }
      
      .card-header {
        flex-direction: column;
        align-items: flex-start;
        gap: var(--spacing-md);
      }
      
      .btn span:last-child:not(.material-icons) {
        display: none;
      }
      
      .btn .material-icons {
        margin-right: 0;
      }
    }
    
    /* ====== 深色模式支持 ====== */
    @media (prefers-color-scheme: dark) {
      :root {
        --gray-900: #f5f5f5;
        --gray-800: #e6e6e6;
        --gray-700: #d9d9d9;
        --gray-600: #b3b3b3;
        --gray-500: #8c8c8c;
        --gray-400: #666666;
        --gray-300: #404040;
        --gray-200: #2d2d2d;
        --gray-100: #1a1a1a;
        --gray-50: #111111;
        
        --primary-light: rgba(16, 163, 127, 0.2);
      }
      
      body {
        background-color: var(--gray-50);
        color: var(--gray-900);
      }
      
      .card {
        background-color: var(--gray-100);
        border-color: var(--gray-300);
      }
      
      .card-header {
        background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      }
      
      .form-control {
        background-color: var(--gray-200);
        border-color: var(--gray-400);
        color: var(--gray-900);
      }
      
      .form-table tr:not(:last-child) {
        border-color: var(--gray-300);
      }
      
      .form-actions {
        border-color: var(--gray-300);
      }
      
      .strength-bar {
        background-color: var(--gray-400);
      }
    }
  </style>
</head>
<body>
  <!-- 页面标题卡片 -->
  <div class="card fade-in">
    <div class="card-header">
      <h1 class="page-title">
        <span class="material-icons">edit</span>
        编辑用户
      </h1>
      <a href="user_list.php" class="btn btn-outline">
        <span class="material-icons" style="font-size: 1rem;">arrow_back</span>
        返回列表
      </a>
    </div>
  </div>

  <!-- 表单卡片 -->
  <div class="card fade-in" style="animation-delay: 0.1s;">
    <div class="card-body">
      <form action="./temp/edit_user.php" method="post" id="userForm">
        <input type="hidden" name="id" value="<?= $user['id'] ?>">
        
        <table class="form-table">
          <tbody>
            <tr>
              <td class="form-label">
                用户名<span class="required">*</span>
              </td>
              <td>
                <div class="form-input-wrapper">
                  <input 
                    type="text" 
                    name="name" 
                    class="form-control" 
                    value="<?= htmlspecialchars($user['name']) ?>"
                    placeholder="请输入用户名" 
                    required
                    autofocus>
                  <small class="form-help-text">用户名将用于登录系统</small>
                </div>
              </td>
            </tr>
            <tr>
              <td class="form-label">
                新密码<span class="required">*</span>
              </td>
              <td>
                <div class="form-input-wrapper">
                  <input 
                    type="password" 
                    name="password" 
                    id="password" 
                    class="form-control" 
                    placeholder="请输入新密码" 
                    required>
                  <div class="password-strength">
                    <small class="form-help-text">密码至少6位字符</small>
                    <div class="strength-bar">
                      <div class="strength-fill" id="passwordStrength"></div>
                    </div>
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <td class="form-label">
                确认新密码<span class="required">*</span>
              </td>
              <td>
                <div class="form-input-wrapper">
                  <input 
                    type="password" 
                    name="password_confirm" 
                    id="password_confirm" 
                    class="form-control" 
                    placeholder="请再次输入新密码" 
                    required>
                  <small class="form-help-text" id="passwordMatchText"></small>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <!-- 提交按钮 -->
        <div class="form-actions">
          <a href="user_list.php" class="btn btn-outline">
            <span class="material-icons" style="font-size: 1rem;">close</span>
            取消
          </a>
          <button type="submit" class="btn btn-primary">
            <span class="material-icons" style="font-size: 1rem;">save</span>
            保存修改
          </button>
        </div>
      </form>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const passwordInput = document.getElementById('password');
      const passwordConfirmInput = document.getElementById('password_confirm');
      const passwordStrength = document.getElementById('passwordStrength');
      const passwordMatchText = document.getElementById('passwordMatchText');
      
      // 密码强度检测
      passwordInput.addEventListener('input', function() {
        const password = this.value;
        let strength = '';
        
        if (password.length === 0) {
          strength = '';
        } else if (password.length < 6) {
          strength = 'weak';
        } else if (password.length < 10) {
          strength = 'medium';
        } else {
          // 检查是否包含数字、字母和特殊字符
          const hasNumber = /\d/.test(password);
          const hasLetter = /[a-zA-Z]/.test(password);
          const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
          
          if (hasNumber && hasLetter && hasSpecial) {
            strength = 'strong';
          } else if (hasNumber && hasLetter) {
            strength = 'medium';
          } else {
            strength = 'weak';
          }
        }
        
        passwordStrength.className = 'strength-fill ' + strength;
      });
      
      // 密码一致性检查
      function checkPasswordMatch() {
        const password = passwordInput.value;
        const confirm = passwordConfirmInput.value;
        
        if (confirm.length === 0) {
          passwordMatchText.textContent = '';
          passwordMatchText.style.color = '';
        } else if (password === confirm) {
          passwordMatchText.textContent = '✓ 密码匹配';
          passwordMatchText.style.color = '#10a37f';
        } else {
          passwordMatchText.textContent = '✗ 密码不匹配';
          passwordMatchText.style.color = '#f44336';
        }
      }
      
      passwordInput.addEventListener('input', checkPasswordMatch);
      passwordConfirmInput.addEventListener('input', checkPasswordMatch);
      
      // 表单提交验证
      document.getElementById('userForm').addEventListener('submit', function(e) {
        const password = passwordInput.value;
        const passwordConfirm = passwordConfirmInput.value;

        // 必须填写新密码
        if (!password || !passwordConfirm) {
          e.preventDefault();
          alert('请填写新密码！');
          passwordInput.focus();
          return false;
        }

        // 验证密码一致性
        if (password !== passwordConfirm) {
          e.preventDefault();
          alert('两次输入的密码不一致！');
          passwordConfirmInput.focus();
          return false;
        }

        // 验证密码长度
        if (password.length < 6) {
          e.preventDefault();
          alert('密码长度至少为6位！');
          passwordInput.focus();
          return false;
        }

        // 确认对话框
        const userName = document.querySelector('input[name="name"]').value;
        if (!confirm(`确定要更新用户 "${userName}" 的信息吗？`)) {
          e.preventDefault();
          return false;
        }

        return true;
      });
    });
  </script>
</body>
</html>