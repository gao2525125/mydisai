
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>抖音本地通消耗追踪 - 管理员登录</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
            padding: 20px;
        }

        .container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 440px;
            padding: 40px;
            position: relative;
            overflow: hidden;
        }

        .container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        }

        .system-title {
            text-align: center;
            margin-bottom: 36px;
        }

        .system-title h1 {
            color: #1a202c;
            font-size: 24px;
            font-weight: 600;
            line-height: 1.3;
            margin-bottom: 8px;
        }

        .system-title p {
            color: #718096;
            font-size: 14px;
            font-weight: 400;
        }

        .form-group {
            margin-bottom: 24px;
        }

        .form-group label {
            display: block;
            color: #4a5568;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 6px;
        }

        .form-input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.2s ease;
            background: white;
        }

        .form-input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .form-input::placeholder {
            color: #a0aec0;
        }

        .verify-code-group {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .verify-code-input {
            flex: 1;
        }

        .verify-code-img {
            width: 120px;
            height: 44px;
            border-radius: 6px;
            cursor: pointer;
            border: 1px solid #e2e8f0;
            transition: opacity 0.2s ease;
        }

        .verify-code-img:hover {
            opacity: 0.9;
        }

        .remember-me {
            display: flex;
            align-items: center;
            margin-bottom: 28px;
        }

        .remember-me input[type="checkbox"] {
            width: 18px;
            height: 18px;
            border: 2px solid #cbd5e0;
            border-radius: 4px;
            margin-right: 10px;
            cursor: pointer;
            appearance: none;
            position: relative;
            transition: all 0.2s ease;
        }

        .remember-me input[type="checkbox"]:checked {
            background-color: #667eea;
            border-color: #667eea;
        }

        .remember-me input[type="checkbox"]:checked::after {
            content: '✓';
            position: absolute;
            color: white;
            font-size: 12px;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .remember-me label {
            color: #4a5568;
            font-size: 14px;
            cursor: pointer;
            user-select: none;
        }

        .login-button {
            width: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 14px;
            font-size: 16px;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            letter-spacing: 0.5px;
        }

        .login-button:hover {
            transform: translateY(-1px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }

        .login-button:active {
            transform: translateY(0);
        }

        .form-footer {
            margin-top: 8px;
            font-size: 14px;
            color: #718096;
        }

        @media (max-width: 480px) {
            .container {
                padding: 30px 24px;
            }
            
            .system-title h1 {
                font-size: 20px;
            }
            
            .verify-code-group {
                flex-direction: column;
                align-items: stretch;
            }
            
            .verify-code-img {
                width: 100%;
                height: 44px;
            }
        }
    </style>
</head>

<body>
<div class="container">
    <div class="system-title">
        <h1>抖音本地通消耗追踪</h1>
        <p>管理员登录系统</p>
    </div>

    <div id="Login" class="tabcontent">
        <form action="temp/login_code.php" method="post">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" 
                       class="form-input" 
                       placeholder="请输入用户名"  
                       name="username" 
                       value="<?php echo isset($_SESSION['username_l']) ? htmlspecialchars($_SESSION['username_l']) : ''; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label>密码</label>
                <input type="password" 
                       class="form-input" 
                       placeholder="请输入密码" 
                       name="password" 
                       value="<?php echo isset($_SESSION['password_l']) ? htmlspecialchars($_SESSION['password_l']) : ''; ?>" 
                       required>
            </div>
            
            <div class="form-group">
                <label>验证码</label>
                <div class="verify-code-group">
                    <input type="text" 
                           class="form-input verify-code-input" 
                           placeholder="请输入验证码" 
                           value="<?php echo isset($_SESSION['verifyCode_l']) ? htmlspecialchars($_SESSION['verifyCode_l']) : ''; ?>"  
                           name="verifyCode" 
                           required>
                    <img src="./temp/yzm.php" 
                         class="verify-code-img" 
                         alt="验证码" 
                         title="点击刷新验证码" 
                         onclick="this.src='./temp/yzm.php?'+ Date.now();"/>
                </div>
            </div>

            <div class="remember-me">
                <input type="checkbox" id="rememberMe" name="checkbox">
                <label for="rememberMe">保持登录状态</label>
            </div>
            
            <button type="submit" class="login-button">登录系统</button>
        </form>
    </div>
</div>

<script src="./js/login.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // 表单验证
        const form = document.querySelector('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                const inputs = this.querySelectorAll('input[required]');
                let isValid = true;
                
                inputs.forEach(input => {
                    if (!input.value.trim()) {
                        isValid = false;
                        input.style.borderColor = '#fc8181';
                        // 添加抖动效果
                        input.style.animation = 'shake 0.5s';
                        setTimeout(() => {
                            input.style.animation = '';
                        }, 500);
                    } else {
                        input.style.borderColor = '#e2e8f0';
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                    // 创建错误提示
                    showError('请填写所有必填字段');
                }
            });
        }

        // 为输入框添加焦点恢复效果
        const inputs = document.querySelectorAll('.form-input');
        inputs.forEach(input => {
            input.addEventListener('focus', function() {
                this.style.borderColor = '#667eea';
            });
            
            input.addEventListener('blur', function() {
                if (this.value.trim()) {
                    this.style.borderColor = '#48bb78';
                } else {
                    this.style.borderColor = '#e2e8f0';
                }
            });
        });

        // 显示错误提示
        function showError(message) {
            // 移除已有的错误提示
            const existingError = document.querySelector('.error-message');
            if (existingError) {
                existingError.remove();
            }

            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.textContent = message;
            errorDiv.style.cssText = `
                background: #fed7d7;
                color: #c53030;
                padding: 12px;
                border-radius: 8px;
                font-size: 14px;
                margin-bottom: 20px;
                text-align: center;
                animation: fadeIn 0.3s ease;
            `;
            
            const form = document.querySelector('form');
            form.insertBefore(errorDiv, form.firstChild);
            
            // 3秒后自动消失
            setTimeout(() => {
                if (errorDiv.parentNode) {
                    errorDiv.style.opacity = '0';
                    errorDiv.style.transition = 'opacity 0.3s ease';
                    setTimeout(() => {
                        if (errorDiv.parentNode) {
                            errorDiv.remove();
                        }
                    }, 300);
                }
            }, 3000);
        }

        // 添加CSS动画
        const style = document.createElement('style');
        style.textContent = `
            @keyframes shake {
                0%, 100% { transform: translateX(0); }
                10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
                20%, 40%, 60%, 80% { transform: translateX(5px); }
            }
            
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(-10px); }
                to { opacity: 1; transform: translateY(0); }
            }
        `;
        document.head.appendChild(style);
    });
</script>
</body>
</html>