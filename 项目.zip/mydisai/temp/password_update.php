<?php
require_once "../api/fn.php";
session();
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
// 管理员信息
$admin_info = login($username);

// 超全局  
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取诗名和更新注释  
    $password_j = isset($_POST['password_j']) ? $_POST['password_j'] : '';
    $password_x = isset($_POST['password_x']) ? $_POST['password_x'] : '';



    // 解密验证码
    $password_true = password_verify($password_j . $admin_info["yan"], $admin_info["password"]);
    // 旧密码正确才可以更改
    if ($password_true) {


        $yan_x = bin2hex(random_bytes(16)); // 生成一个32字符的十六进制字符串  
        // 使用 password_hash() 函数创建密码的哈希值  
        $hashedPassword = password_hash($password_x . $yan_x, PASSWORD_DEFAULT); // 将密码和盐拼接后哈希  
        $isupdata = password_update($hashedPassword, $yan_x, $username);
        if ($isupdata) {
            unset($_SESSION["username"]);
            setcookie('remember_token', '', time() - 3600, '/');
            // 输出JavaScript来执行跳转和显示消息   
            ?>
            <script type="text/javascript">
                // 使用 setTimeout 函数在1秒后执行跳转  

                alert("修改成功,请重新登入");
                setTimeout(function () {
                    // 修改密码成功后
                    top.window.location.href = '../login.php';

                }, 200); // 延迟1秒（1000毫秒）  
            </script>
            <?php
        }
    } else {
        $_SESSION['password_j'] = $_POST['password_j'];
        $_SESSION['password_x'] = $_POST['password_x'];
        ?>
        <script type="text/javascript">
            // 使用 setTimeout 函数在1秒后执行跳转  
            alert("旧密码错误");
            setTimeout(function () {
                window.location.href = "../data/edit_password.php";
            }, 100);
        </script>
        <?php
    }
} 


?>