<?php
// PHP代码必须放在最前面，不能有任何输出
require_once "./api/fn.php";
session();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>添加用户 · 抖音本地通消耗追踪</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <style>
    /* ====== DeepSeek风格CSS变量与重置 ====== */
    :root {
      /* DeepSeek主色调 */
      --primary-color: #10a37f;
      --primary-dark: #0d8c6d;
      --primary-light: #e6f7f2;
      
      /* 中性色调 */
      --gray-900: #1a1a1a;
      --gray-800: #2d2d2d;
      --gray-700: #404040;
      --gray-600: #666666;
      --gray-500: #8c8c8c;
      --gray-400: #b3b3b3;
      --gray-300: #d9d9d9;
      --gray-200: #e6e6e6;
      --gray-100: #f5f5f5;
      --gray-50: #fafafa;
      
      /* 功能色 */
      --success-color: #10a37f;
      --warning-color: #ff9800;
      --error-color: #f44336;
      --info-color: #2196f3;
      
      /* 排版 */
      --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      --font-family-mono: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Courier, monospace;
      
      /* 间距 */
      --spacing-xs: 4px;
      --spacing-sm: 8px;
      --spacing-md: 12px;
      --spacing-lg: 16px;
      --spacing-xl: 24px;
      --spacing-xxl: 32px;
      
      /* 圆角 */
      --radius-sm: 4px;
      --radius-md: 6px;
      --radius-lg: 8px;
      --radius-xl: 12px;
      --radius-full: 9999px;
      
      /* 阴影 */
      --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
      --shadow-md: 0 2px 8px rgba(0, 0, 0, 0.08);
      --shadow-lg: 0 4px 16px rgba(0, 0, 0, 0.12);
      
      /* 过渡 */
      --transition-fast: 150ms ease;
      --transition-normal: 250ms ease;
      --transition-slow: 350ms ease;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: var(--font-family);
      color: var(--gray-900);
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      line-height: 1.6;
      font-size: 14px;
      min-height: 100vh;
      padding: var(--spacing-lg);
    }
    
    /* ====== 主容器 ====== */
    .main-container {
      max-width: 480px;
      margin: 0 auto;
    }
    
    /* ====== 卡片样式 ====== */
    .card {
      background-color: white;
      border-radius: var(--radius-xl);
      border: 1px solid var(--gray-200);
      box-shadow: var(--shadow-lg);
      overflow: hidden;
      transition: all var(--transition-normal);
      margin-bottom: var(--spacing-lg);
    }
    
    .card:hover {
      box-shadow: var(--shadow-lg);
    }
    
    .card-header {
      padding: var(--spacing-xl);
      border-bottom: 1px solid var(--gray-200);
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .card-body {
      padding: var(--spacing-xl);
    }
    
    /* ====== 标题和文本 ====== */
    .page-title {
      font-size: 1.25rem;
      font-weight: 600;
      margin: 0;
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    .text-muted {
      color: var(--gray-600);
    }
    
    /* ====== 按钮样式 ====== */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      font-weight: 500;
      line-height: 1.5;
      border-radius: var(--radius-md);
      border: 1px solid transparent;
      cursor: pointer;
      transition: all var(--transition-fast);
      text-decoration: none;
      gap: var(--spacing-sm);
    }
    
    .btn-primary {
      background-color: var(--primary-color);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      color: white;
      text-decoration: none;
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .btn-outline {
      background-color: transparent;
      color: var(--primary-color);
      border-color: var(--gray-300);
    }
    
    .btn-outline:hover {
      background-color: var(--primary-light);
      color: var(--primary-dark);
      text-decoration: none;
      border-color: var(--primary-color);
      transform: translateY(-2px);
    }
    
    /* ====== 表单样式 ====== */
    .form-group {
      margin-bottom: var(--spacing-xl);
    }
    
    .form-label {
      display: block;
      margin-bottom: var(--spacing-sm);
      font-weight: 600;
      color: var(--gray-800);
      font-size: 0.875rem;
    }
    
    .form-label .required {
      color: var(--error-color);
      margin-left: 2px;
    }
    
    .form-control-wrapper {
      position: relative;
    }
    
    .form-control {
      display: block;
      width: 100%;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      line-height: 1.5;
      color: var(--gray-900);
      background-color: white;
      border: 1px solid var(--gray-300);
      border-radius: var(--radius-md);
      transition: all var(--transition-fast);
      height: 40px;
    }
    
    .form-control:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(16, 163, 127, 0.1);
    }
    
    .form-control::placeholder {
      color: var(--gray-500);
    }
    
    .form-help {
      display: block;
      margin-top: var(--spacing-xs);
      font-size: 0.75rem;
      color: var(--gray-600);
      line-height: 1.5;
    }
    
    /* ====== 密码强度指示器 ====== */
    .password-strength {
      margin-top: var(--spacing-xs);
    }
    
    .strength-bar {
      height: 3px;
      border-radius: var(--radius-sm);
      background-color: var(--gray-200);
      margin-top: var(--spacing-xs);
      overflow: hidden;
    }
    
    .strength-fill {
      height: 100%;
      width: 0%;
      transition: all var(--transition-normal);
    }
    
    .strength-fill.weak {
      width: 33%;
      background-color: var(--error-color);
    }
    
    .strength-fill.medium {
      width: 66%;
      background-color: var(--warning-color);
    }
    
    .strength-fill.strong {
      width: 100%;
      background-color: var(--success-color);
    }
    
    .strength-text {
      font-size: 0.75rem;
      color: var(--gray-600);
      display: flex;
      justify-content: space-between;
      margin-top: 2px;
    }
    
    /* ====== 密码匹配提示 ====== */
    .match-indicator {
      font-size: 0.75rem;
      margin-top: var(--spacing-xs);
      display: flex;
      align-items: center;
      gap: var(--spacing-xs);
    }
    
    .match-indicator.match {
      color: var(--success-color);
    }
    
    .match-indicator.mismatch {
      color: var(--error-color);
    }
    
    /* ====== 密码提示 ====== */
    .password-tips {
      background-color: var(--primary-light);
      padding: var(--spacing-md);
      border-radius: var(--radius-md);
      margin: var(--spacing-lg) 0;
      border-left: 3px solid var(--primary-color);
    }
    
    .password-tips-title {
      font-size: 0.8125rem;
      font-weight: 600;
      color: var(--primary-dark);
      margin-bottom: var(--spacing-xs);
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    .password-tips-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .password-tips-list li {
      font-size: 0.75rem;
      color: var(--gray-700);
      margin-bottom: 4px;
      display: flex;
      align-items: center;
      gap: var(--spacing-xs);
    }
    
    .password-tips-list li:last-child {
      margin-bottom: 0;
    }
    
    .password-tips-list li::before {
      content: "•";
      color: var(--primary-color);
      font-weight: bold;
      font-size: 1rem;
    }
    
    /* ====== 表单操作区域 ====== */
    .form-actions {
      margin-top: var(--spacing-xl);
      padding-top: var(--spacing-lg);
      border-top: 2px solid var(--gray-200);
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--spacing-md);
    }
    
    /* ====== 动画效果 ====== */
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .fade-in {
      animation: fadeIn 0.4s ease forwards;
    }
    
    /* ====== 响应式设计 ====== */
    @media (max-width: 576px) {
      body {
        padding: var(--spacing-sm);
      }
      
      .main-container {
        max-width: 100%;
      }
      
      .card-header {
        padding: var(--spacing-lg);
        flex-direction: column;
        align-items: flex-start;
        gap: var(--spacing-md);
      }
      
      .card-body {
        padding: var(--spacing-lg);
      }
      
      .form-actions {
        grid-template-columns: 1fr;
      }
      
      .btn span:last-child:not(.material-icons) {
        display: none;
      }
      
      .btn .material-icons {
        margin-right: 0;
      }
    }
    
    /* ====== 深色模式支持 ====== */
    @media (prefers-color-scheme: dark) {
      :root {
        --gray-900: #f5f5f5;
        --gray-800: #e6e6e6;
        --gray-700: #d9d9d9;
        --gray-600: #b3b3b3;
        --gray-500: #8c8c8c;
        --gray-400: #666666;
        --gray-300: #404040;
        --gray-200: #2d2d2d;
        --gray-100: #1a1a1a;
        --gray-50: #111111;
        
        --primary-light: rgba(16, 163, 127, 0.2);
      }
      
      body {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      }
      
      .card {
        background-color: var(--gray-100);
        border-color: var(--gray-300);
      }
      
      .card-header {
        background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      }
      
      .form-control {
        background-color: var(--gray-200);
        border-color: var(--gray-400);
        color: var(--gray-900);
      }
      
      .password-tips {
        background-color: rgba(16, 163, 127, 0.15);
        border-left-color: var(--primary-color);
      }
      
      .strength-bar {
        background-color: var(--gray-400);
      }
    }
  </style>
</head>
<body>
  <div class="main-container">
    <!-- 页面标题卡片 -->
    <div class="card fade-in">
      <div class="card-header">
        <h1 class="page-title">
          <span class="material-icons">person_add</span>
          添加用户
        </h1>
        <a href="user_list.php" class="btn btn-outline">
          <span class="material-icons" style="font-size: 1rem;">arrow_back</span>
          返回列表
        </a>
      </div>
    </div>

    <!-- 表单卡片 -->
    <div class="card fade-in" style="animation-delay: 0.1s;">
      <div class="card-body">
        <form action="./temp/add_user.php" method="post" id="userForm">
          <!-- 用户名 -->
          <div class="form-group">
            <label class="form-label">
              用户名<span class="required">*</span>
            </label>
            <div class="form-control-wrapper">
              <input 
                type="text" 
                name="name" 
                class="form-control" 
                placeholder="请输入用户名"
                required
                autofocus>
            </div>
            <small class="form-help">用户名将用于系统登录</small>
          </div>

          <!-- 密码 -->
          <div class="form-group">
            <label class="form-label">
              密码<span class="required">*</span>
            </label>
            <div class="form-control-wrapper">
              <input 
                type="password" 
                name="password" 
                id="password" 
                class="form-control" 
                placeholder="请输入密码"
                required>
            </div>
            <div class="password-strength">
              <div class="strength-bar">
                <div class="strength-fill" id="passwordStrength"></div>
              </div>
              <div class="strength-text">
                <span id="passwordStrengthText">密码强度</span>
                <span id="passwordLengthText">0/6</span>
              </div>
            </div>
          </div>

          <!-- 确认密码 -->
          <div class="form-group">
            <label class="form-label">
              确认密码<span class="required">*</span>
            </label>
            <div class="form-control-wrapper">
              <input 
                type="password" 
                name="password_confirm" 
                id="password_confirm" 
                class="form-control" 
                placeholder="请再次输入密码"
                required>
            </div>
            <div class="match-indicator" id="passwordMatchIndicator">
              <!-- 实时显示密码匹配状态 -->
            </div>
          </div>

          <!-- 密码提示 -->
          <div class="password-tips">
            <div class="password-tips-title">
              <span class="material-icons" style="font-size: 0.875rem;">info</span>
              密码要求
            </div>
            <ul class="password-tips-list">
              <li>长度：至少6位字符</li>
              <li>安全：建议使用数字和字母组合</li>
              <li>确认：两次输入密码必须一致</li>
            </ul>
          </div>

          <!-- 提交按钮 -->
          <div class="form-actions">
            <a href="user_list.php" class="btn btn-outline">
              <span class="material-icons" style="font-size: 1rem;">close</span>
              取消
            </a>
            <button type="submit" class="btn btn-primary">
              <span class="material-icons" style="font-size: 1rem;">person_add</span>
              添加用户
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const passwordInput = document.getElementById('password');
      const passwordConfirmInput = document.getElementById('password_confirm');
      const passwordStrength = document.getElementById('passwordStrength');
      const passwordStrengthText = document.getElementById('passwordStrengthText');
      const passwordLengthText = document.getElementById('passwordLengthText');
      const passwordMatchIndicator = document.getElementById('passwordMatchIndicator');
      const form = document.getElementById('userForm');
      
      // 密码强度检测
      passwordInput.addEventListener('input', function() {
        const password = this.value;
        const length = password.length;
        
        // 更新长度显示
        passwordLengthText.textContent = `${length}/6`;
        
        if (length === 0) {
          passwordStrength.className = 'strength-fill';
          passwordStrengthText.textContent = '密码强度';
          return;
        }
        
        if (length < 6) {
          passwordStrength.className = 'strength-fill weak';
          passwordStrengthText.textContent = '太短';
          return;
        }
        
        // 检查密码复杂度
        const hasNumber = /\d/.test(password);
        const hasLetter = /[a-zA-Z]/.test(password);
        const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);
        
        let score = 0;
        if (hasNumber) score++;
        if (hasLetter) score++;
        if (hasSpecial) score++;
        
        if (score >= 2 && length >= 8) {
          passwordStrength.className = 'strength-fill strong';
          passwordStrengthText.textContent = '强';
        } else if (score >= 2) {
          passwordStrength.className = 'strength-fill medium';
          passwordStrengthText.textContent = '中';
        } else {
          passwordStrength.className = 'strength-fill weak';
          passwordStrengthText.textContent = '弱';
        }
        
        // 触发密码匹配检查
        checkPasswordMatch();
      });
      
      // 密码匹配检查
      function checkPasswordMatch() {
        const password = passwordInput.value;
        const confirm = passwordConfirmInput.value;
        
        if (confirm.length === 0) {
          passwordMatchIndicator.innerHTML = '';
          passwordMatchIndicator.className = 'match-indicator';
          return;
        }
        
        if (password === confirm) {
          passwordMatchIndicator.innerHTML = '<span class="material-icons" style="font-size: 0.875rem;">check_circle</span> 密码匹配';
          passwordMatchIndicator.className = 'match-indicator match';
        } else {
          passwordMatchIndicator.innerHTML = '<span class="material-icons" style="font-size: 0.875rem;">error</span> 密码不匹配';
          passwordMatchIndicator.className = 'match-indicator mismatch';
        }
      }
      
      passwordConfirmInput.addEventListener('input', checkPasswordMatch);
      
      // 表单提交验证
      form.addEventListener('submit', function(e) {
        const password = passwordInput.value;
        const passwordConfirm = passwordConfirmInput.value;
        const username = document.querySelector('input[name="name"]').value.trim();

        // 用户名验证
        if (username.length === 0) {
          e.preventDefault();
          alert('请输入用户名！');
          document.querySelector('input[name="name"]').focus();
          return false;
        }
        
        // 用户名长度验证
        if (username.length < 2 || username.length > 20) {
          e.preventDefault();
          alert('用户名长度应为2-20个字符！');
          document.querySelector('input[name="name"]').focus();
          return false;
        }

        // 密码一致性验证
        if (password !== passwordConfirm) {
          e.preventDefault();
          alert('两次输入的密码不一致！');
          passwordConfirmInput.focus();
          return false;
        }

        // 密码长度验证
        if (password.length < 6) {
          e.preventDefault();
          alert('密码长度至少为6位！');
          passwordInput.focus();
          return false;
        }

        // 确认对话框
        if (!confirm(`确定要添加用户 "${username}" 吗？`)) {
          e.preventDefault();
          return false;
        }

        return true;
      });
      
      // 表单重置事件
      form.addEventListener('reset', function() {
        // 清空所有指示器
        passwordStrength.className = 'strength-fill';
        passwordStrengthText.textContent = '密码强度';
        passwordLengthText.textContent = '0/6';
        passwordMatchIndicator.innerHTML = '';
        passwordMatchIndicator.className = 'match-indicator';
        
        // 重新聚焦到用户名输入框
        setTimeout(() => {
          document.querySelector('input[name="name"]').focus();
        }, 100);
      });
    });
  </script>
</body>
</html>