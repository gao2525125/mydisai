<?php
// PHP代码必须放在最前面，不能有任何输出
require_once "./api/fn.php";
session();

// 获取要编辑的配置ID
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    echo "<script>alert('参数错误！'); window.location.href='home.php';</script>";
    exit;
}

// 获取编辑数据
$editData = get_edit_data($id);

if (!$editData) {
    echo "<script>alert('配置不存在！'); window.location.href='home.php';</script>";
    exit;
}

$config = $editData['config'];
$nodes = $editData['nodes'];
$details = $editData['details'];
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>编辑消耗配置 - <?= $config['year'] ?>年<?= $config['month'] ?>月 · 抖音本地通消耗追踪</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <style>
    /* ====== DeepSeek风格CSS变量与重置 ====== */
    :root {
      /* DeepSeek主色调 */
      --primary-color: #10a37f;
      --primary-dark: #0d8c6d;
      --primary-light: #e6f7f2;
      
      /* 中性色调 */
      --gray-900: #1a1a1a;
      --gray-800: #2d2d2d;
      --gray-700: #404040;
      --gray-600: #666666;
      --gray-500: #8c8c8c;
      --gray-400: #b3b3b3;
      --gray-300: #d9d9d9;
      --gray-200: #e6e6e6;
      --gray-100: #f5f5f5;
      --gray-50: #fafafa;
      
      /* 功能色 */
      --success-color: #10a37f;
      --warning-color: #ff9800;
      --error-color: #f44336;
      --info-color: #2196f3;
      --accent-color: #9c27b0;
      --budget-color: #2196f3;
      --consumption-color: #f44336;
      
      /* 排版 */
      --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      --font-family-mono: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Courier, monospace;
      
      /* 间距 */
      --spacing-xs: 4px;
      --spacing-sm: 8px;
      --spacing-md: 12px;
      --spacing-lg: 16px;
      --spacing-xl: 24px;
      --spacing-xxl: 32px;
      
      /* 圆角 */
      --radius-sm: 4px;
      --radius-md: 6px;
      --radius-lg: 8px;
      --radius-xl: 12px;
      --radius-full: 9999px;
      
      /* 阴影 */
      --shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.1);
      --shadow-md: 0 2px 8px rgba(0, 0, 0, 0.08);
      --shadow-lg: 0 4px 16px rgba(0, 0, 0, 0.12);
      
      /* 过渡 */
      --transition-fast: 150ms ease;
      --transition-normal: 250ms ease;
      --transition-slow: 350ms ease;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: var(--font-family);
      color: var(--gray-900);
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      line-height: 1.6;
      font-size: 14px;
      padding: var(--spacing-lg);
      min-height: 100vh;
    }
    
    /* ====== 主容器 ====== */
    .main-container {
      max-width: 1200px;
      margin: 0 auto;
    }
    
    /* ====== 卡片样式 ====== */
    .card {
      background-color: white;
      border-radius: var(--radius-xl);
      border: 1px solid var(--gray-200);
      box-shadow: var(--shadow-lg);
      overflow: hidden;
      transition: all var(--transition-normal);
      margin-bottom: var(--spacing-lg);
    }
    
    .card:hover {
      box-shadow: var(--shadow-lg);
    }
    
    .card-header {
      padding: var(--spacing-xl);
      border-bottom: 1px solid var(--gray-200);
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    
    .card-body {
      padding: var(--spacing-xl);
    }
    
    /* ====== 标题和文本 ====== */
    .page-title {
      font-size: 1.25rem;
      font-weight: 600;
      margin: 0;
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    /* ====== 按钮样式 ====== */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      font-weight: 500;
      line-height: 1.5;
      border-radius: var(--radius-md);
      border: 1px solid transparent;
      cursor: pointer;
      transition: all var(--transition-fast);
      text-decoration: none;
      gap: var(--spacing-sm);
    }
    
    .btn-outline {
      background-color: transparent;
      color: white;
      border-color: rgba(255, 255, 255, 0.5);
    }
    
    .btn-outline:hover {
      background-color: rgba(255, 255, 255, 0.1);
      border-color: white;
      transform: translateY(-2px);
    }
    
    .btn-primary {
      background-color: var(--primary-color);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      color: white;
      text-decoration: none;
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .btn-success {
      background-color: var(--success-color);
      color: white;
    }
    
    .btn-success:hover {
      background-color: #0d8c6d;
      color: white;
      text-decoration: none;
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    /* ====== 表单样式 ====== */
    .form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--spacing-lg);
      margin-bottom: var(--spacing-xl);
    }
    
    @media (max-width: 768px) {
      .form-grid {
        grid-template-columns: 1fr;
        gap: var(--spacing-md);
      }
    }
    
    .form-group {
      margin-bottom: var(--spacing-lg);
    }
    
    .form-label {
      display: block;
      margin-bottom: var(--spacing-sm);
      font-weight: 600;
      color: var(--gray-800);
      font-size: 0.875rem;
    }
    
    .form-label .required {
      color: var(--error-color);
      margin-left: 2px;
    }
    
    .form-control {
      display: block;
      width: 100%;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      line-height: 1.5;
      color: var(--gray-900);
      background-color: white;
      border: 1px solid var(--gray-300);
      border-radius: var(--radius-md);
      transition: all var(--transition-fast);
      height: 40px;
    }
    
    .form-control:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(16, 163, 127, 0.1);
    }
    
    .form-control::placeholder {
      color: var(--gray-500);
    }
    
    .form-control.readonly {
      background-color: var(--gray-100);
      color: var(--gray-600);
      cursor: not-allowed;
      border-color: var(--gray-300);
    }
    
    textarea.form-control {
      min-height: 100px;
      resize: vertical;
      line-height: 1.5;
      padding: var(--spacing-md);
      height: auto;
    }
    
    .form-help {
      display: block;
      margin-top: var(--spacing-xs);
      font-size: 0.75rem;
      color: var(--gray-600);
      line-height: 1.5;
    }
    
    /* ====== 部分标题 ====== */
    .section-title {
      font-size: 1rem;
      font-weight: 600;
      color: var(--gray-900);
      margin: var(--spacing-xl) 0 var(--spacing-lg);
      padding-bottom: var(--spacing-sm);
      border-bottom: 2px solid var(--gray-200);
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    
    .section-subtitle {
      font-size: 0.75rem;
      font-weight: 400;
      color: var(--gray-600);
    }
    
    /* ====== 核销节点样式 ====== */
    .node-container {
      margin: var(--spacing-lg) 0;
    }
    
    .node-item {
      background-color: white;
      border: 1px solid var(--gray-200);
      border-radius: var(--radius-lg);
      padding: var(--spacing-lg);
      margin-bottom: var(--spacing-md);
      box-shadow: var(--shadow-sm);
      transition: all var(--transition-normal);
      position: relative;
    }
    
    .node-item:hover {
      border-color: var(--primary-color);
      box-shadow: var(--shadow-md);
    }
    
    .node-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: var(--spacing-lg);
      padding-bottom: var(--spacing-sm);
      border-bottom: 1px solid var(--gray-200);
    }
    
    .node-title {
      font-size: 0.875rem;
      font-weight: 600;
      color: var(--primary-color);
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    .node-number {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 24px;
      height: 24px;
      background-color: var(--primary-color);
      color: white;
      border-radius: var(--radius-full);
      font-size: 0.75rem;
      font-weight: 600;
    }
    
    .btn-remove {
      background-color: transparent;
      color: var(--error-color);
      border: 1px solid var(--gray-300);
      padding: var(--spacing-xs) var(--spacing-sm);
      border-radius: var(--radius-sm);
      font-size: 0.75rem;
      cursor: pointer;
      transition: all var(--transition-fast);
      display: flex;
      align-items: center;
      gap: var(--spacing-xs);
    }
    
    .btn-remove:hover {
      background-color: var(--error-color);
      color: white;
      border-color: var(--error-color);
    }
    
    /* ====== 日期范围样式 ====== */
    .date-range {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    .date-range .form-control {
      flex: 1;
    }
    
    .date-range-separator {
      color: var(--gray-500);
      font-weight: 500;
    }
    
    /* ====== 每日明细表格样式 ====== */
    .daily-table-container {
      overflow-x: auto;
      border-radius: var(--radius-lg);
      border: 1px solid var(--gray-200);
      background: white;
      margin-top: var(--spacing-lg);
    }
    
    .daily-table {
      width: 100%;
      border-collapse: collapse;
      min-width: 800px;
    }
    
    .daily-table th {
      padding: var(--spacing-md);
      font-weight: 600;
      font-size: 0.8125rem;
      color: var(--gray-700);
      background-color: var(--gray-50);
      border-bottom: 2px solid var(--gray-200);
      text-align: center;
      position: sticky;
      top: 0;
      z-index: 10;
    }
    
    .daily-table td {
      padding: var(--spacing-md);
      border-bottom: 1px solid var(--gray-200);
      text-align: center;
      font-size: 0.875rem;
    }
    
    .daily-table tbody tr {
      transition: background-color var(--transition-fast);
    }
    
    .daily-table tbody tr:hover {
      background-color: var(--gray-50);
    }
    
    .daily-table tbody tr:last-child td {
      border-bottom: none;
    }
    
    .daily-table input {
      width: 80px;
      padding: var(--spacing-xs) var(--spacing-sm);
      border: 1px solid var(--gray-300);
      border-radius: var(--radius-sm);
      text-align: center;
      font-size: 0.875rem;
      transition: all var(--transition-fast);
    }
    
    .daily-table input:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 2px rgba(16, 163, 127, 0.1);
    }
    
    .daily-table input.readonly {
      background-color: var(--gray-100);
      color: var(--gray-600);
      cursor: not-allowed;
      border-color: var(--gray-300);
    }
    
    /* ====== 表单操作区域 ====== */
    .form-actions {
      margin-top: var(--spacing-xl);
      padding-top: var(--spacing-lg);
      border-top: 2px solid var(--gray-200);
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: var(--spacing-md);
    }
    
    /* ====== 动画效果 ====== */
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(10px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .fade-in {
      animation: fadeIn 0.4s ease forwards;
    }
    
    /* ====== 响应式设计 ====== */
    @media (max-width: 768px) {
      body {
        padding: var(--spacing-sm);
      }
      
      .main-container {
        max-width: 100%;
      }
      
      .card-header {
        padding: var(--spacing-lg);
        flex-direction: column;
        align-items: flex-start;
        gap: var(--spacing-md);
      }
      
      .card-body {
        padding: var(--spacing-lg);
      }
      
      .form-actions {
        grid-template-columns: 1fr;
      }
      
      .btn span:last-child:not(.material-icons) {
        display: none;
      }
      
      .btn .material-icons {
        margin-right: 0;
      }
    }
    
    /* ====== 深色模式支持 ====== */
    @media (prefers-color-scheme: dark) {
      :root {
        --gray-900: #f5f5f5;
        --gray-800: #e6e6e6;
        --gray-700: #d9d9d9;
        --gray-600: #b3b3b3;
        --gray-500: #8c8c8c;
        --gray-400: #666666;
        --gray-300: #404040;
        --gray-200: #2d2d2d;
        --gray-100: #1a1a1a;
        --gray-50: #111111;
        
        --primary-light: rgba(16, 163, 127, 0.2);
      }
      
      body {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
      }
      
      .card {
        background-color: var(--gray-100);
        border-color: var(--gray-300);
      }
      
      .card-header {
        background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      }
      
      .form-control {
        background-color: var(--gray-200);
        border-color: var(--gray-400);
        color: var(--gray-900);
      }
      
      .form-control.readonly {
        background-color: var(--gray-300);
        color: var(--gray-600);
        border-color: var(--gray-400);
      }
      
      .node-item {
        background-color: var(--gray-200);
        border-color: var(--gray-300);
      }
      
      .node-item:hover {
        border-color: var(--primary-color);
      }
      
      .node-header {
        border-color: var(--gray-300);
      }
      
      .section-title {
        border-color: var(--gray-300);
      }
      
      .daily-table-container {
        background-color: var(--gray-200);
        border-color: var(--gray-300);
      }
      
      .daily-table th {
        background-color: var(--gray-300);
        border-color: var(--gray-400);
      }
      
      .daily-table td {
        border-color: var(--gray-300);
      }
      
      .daily-table input {
        background-color: var(--gray-300);
        border-color: var(--gray-400);
        color: var(--gray-900);
      }
      
      .daily-table input.readonly {
        background-color: var(--gray-400);
        color: var(--gray-600);
      }
      
      .form-actions {
        border-color: var(--gray-300);
      }
    }
  </style>
</head>
<body>
  <div class="main-container">
    <!-- 页面标题 -->
    <div class="card fade-in">
      <div class="card-header">
        <h1 class="page-title">
          <span class="material-icons">edit</span>
          编辑消耗配置 - <?= $config['year'] ?>年<?= $config['month'] ?>月
        </h1>
        <a href="home.php" class="btn btn-outline">
          <span class="material-icons" style="font-size: 1rem;">arrow_back</span>
          返回列表
        </a>
      </div>
    </div>

    <!-- 表单卡片 -->
    <div class="card fade-in" style="animation-delay: 0.1s;">
      <div class="card-body">
        <form action="./temp/edit.php" method="post" id="configForm">
          <input type="hidden" name="id" value="<?= $config['id'] ?>">
          <input type="hidden" name="year" value="<?= $config['year'] ?>">
          <input type="hidden" name="month" value="<?= $config['month'] ?>">
          
          <!-- 基础设置 -->
          <div class="section-title">
            <span>基础设置</span>
          </div>
          
          <div class="form-grid">
            <!-- 年份 -->
            <div class="form-group">
              <label class="form-label">
                年份
              </label>
              <input 
                type="text" 
                class="form-control readonly" 
                value="<?= $config['year'] ?>年" 
                readonly>
              <small class="form-help">年份不可修改</small>
            </div>
            
            <!-- 月份 -->
            <div class="form-group">
              <label class="form-label">
                月份
              </label>
              <input 
                type="text" 
                class="form-control readonly" 
                value="<?= $config['month'] ?>月" 
                readonly>
              <small class="form-help">月份不可修改</small>
            </div>
            
            <!-- 本月消耗预算 -->
            <div class="form-group">
              <label class="form-label">
                本月消耗预算 (元)<span class="required">*</span>
              </label>
              <input 
                type="number" 
                name="budget" 
                class="form-control" 
                value="<?= $config['budget'] ?>"
                placeholder="请输入本月预算" 
                step="0.01" 
                min="0" 
                required>
              <small class="form-help">请输入本月预算金额</small>
            </div>
            
            <!-- 月度线索任务 -->
            <div class="form-group">
              <label class="form-label">
                月度线索任务 (条)<span class="required">*</span>
              </label>
              <input 
                type="number" 
                name="task_quantity" 
                class="form-control" 
                value="<?= $config['task_quantity'] ?>"
                placeholder="请输入线索任务数" 
                min="0" 
                required>
              <small class="form-help">请输入本月线索任务数量</small>
            </div>
            
            <!-- 本月订单目标 -->
            <div class="form-group">
              <label class="form-label">
                本月订单目标 (单)<span class="required">*</span>
              </label>
              <input 
                type="number" 
                name="target_volume" 
                class="form-control" 
                value="<?= $config['target_volume'] ?>"
                placeholder="请输入订单目标数" 
                min="0" 
                required>
              <small class="form-help">请输入本月订单目标数量</small>
            </div>
          </div>
          
          <!-- 备注 -->
          <div class="form-group">
            <label class="form-label">
              备注内容
            </label>
            <textarea 
              name="remarks" 
              class="form-control" 
              placeholder="请输入备注信息（选填）"
              rows="3"><?= htmlspecialchars($config['remarks']) ?></textarea>
            <small class="form-help">可选的备注信息，用于记录特殊情况或说明</small>
          </div>

          <!-- 核销节点设置 -->
          <div class="section-title">
            <span>核销节点设置</span>
            <span class="section-subtitle">（可选，至少添加一个核销节点）</span>
          </div>

          <div id="nodesContainer" class="node-container">
            <?php foreach ($nodes as $index => $node): 
              $start_day = $node['start_date'];
              $end_day = $node['end_date'];
            ?>
            <div class="node-item fade-in" id="node-<?= $index + 1 ?>">
              <div class="node-header">
                <div class="node-title">
                  <span class="node-number"><?= $index + 1 ?></span>
                  核销节点
                </div>
                <button type="button" class="btn-remove" onclick="removeNode(<?= $index + 1 ?>)">
                  <span class="material-icons" style="font-size: 0.875rem;">delete</span>
                  删除
                </button>
              </div>
              <div class="form-grid">
                <div class="form-group">
                  <label class="form-label">
                    核销日期<span class="required">*</span>
                  </label>
                  <input 
                    type="date" 
                    name="nodes[<?= $index + 1 ?>][write_off_date]" 
                    class="form-control" 
                    value="<?= $node['write_off_date'] ?>" 
                    required>
                </div>
                <div class="form-group">
                  <label class="form-label">
                    核销金额 (元)<span class="required">*</span>
                  </label>
                  <input 
                    type="number" 
                    name="nodes[<?= $index + 1 ?>][amount]" 
                    class="form-control" 
                    value="<?= $node['amount'] ?>"
                    placeholder="请输入核销金额" 
                    step="0.01" 
                    min="0" 
                    required>
                  <small class="form-help">请输入本次核销的金额</small>
                </div>
              </div>
              <div class="form-group">
                <label class="form-label">
                  统计日期范围<span class="required">*</span>
                </label>
                <div class="date-range">
                  <input 
                    type="number" 
                    name="nodes[<?= $index + 1 ?>][start_day]" 
                    class="form-control" 
                    value="<?= $start_day ?>"
                    placeholder="起始日" 
                    min="1" 
                    max="31" 
                    required>
                  <span class="date-range-separator">至</span>
                  <input 
                    type="number" 
                    name="nodes[<?= $index + 1 ?>][end_day]" 
                    class="form-control" 
                    value="<?= $end_day ?>"
                    placeholder="结束日" 
                    min="1" 
                    max="31" 
                    required>
                </div>
                <small class="form-help">请输入统计周期的起始日和结束日（1-31日）</small>
              </div>
            </div>
            <?php endforeach; ?>
          </div>

          <!-- 添加节点按钮 -->
          <button type="button" class="btn btn-success" onclick="addNode()">
            <span class="material-icons" style="font-size: 1rem;">add</span>
            添加核销节点
          </button>

          <!-- 每日业务明细 -->
          <div class="section-title" style="margin-top: var(--spacing-xl);">
            <span>每日业务明细</span>
            <span class="section-subtitle">（填写每日的实际数据）</span>
          </div>

          <div class="daily-table-container">
            <table class="daily-table">
              <thead>
                <tr>
                  <th>日期</th>
                  <th>自然线索</th>
                  <th>广告线索</th>
                  <th>日消耗 (元)</th>
                  <th>订单数量</th>
                  <th>当日总线索</th>
                  <th>线索成本 (元)</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($details as $detail): 
                  $total_leads = $detail['natural_leads'] + $detail['ad_leads'];
                  $cost_per_lead = $total_leads > 0 ? $detail['daily_consumption'] / $total_leads : 0;
                ?>
                <tr>
                  <td>
                    <strong><?= $config['month'] ?>月<?= $detail['day_of_month'] ?>日</strong>
                    <input type="hidden" name="details[<?= $detail['id'] ?>][id]" value="<?= $detail['id'] ?>">
                  </td>
                  <td>
                    <input 
                      type="number" 
                      name="details[<?= $detail['id'] ?>][natural_leads]" 
                      value="<?= $detail['natural_leads'] ?>" 
                      min="0" 
                      required>
                  </td>
                  <td>
                    <input 
                      type="number" 
                      name="details[<?= $detail['id'] ?>][ad_leads]" 
                      value="<?= $detail['ad_leads'] ?>" 
                      min="0" 
                      required>
                  </td>
                  <td>
                    <input 
                      type="number" 
                      name="details[<?= $detail['id'] ?>][daily_consumption]" 
                      value="<?= $detail['daily_consumption'] ?>" 
                      step="0.01" 
                      min="0" 
                      required>
                  </td>
                  <td>
                    <input 
                      type="number" 
                      name="details[<?= $detail['id'] ?>][order_quantity]" 
                      value="<?= $detail['order_quantity'] ?>" 
                      min="0" 
                      required>
                  </td>
                  <td>
                    <input 
                      type="number" 
                      value="<?= $total_leads ?>" 
                      class="readonly" 
                      readonly>
                  </td>
                  <td>
                    <input 
                      type="number" 
                      value="<?= number_format($cost_per_lead, 2) ?>" 
                      class="readonly" 
                      readonly>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <!-- 提交按钮 -->
          <div class="form-actions">
            <a href="home.php" class="btn btn-outline" style="border-color: var(--gray-300); color: var(--gray-700);">
              <span class="material-icons" style="font-size: 1rem;">close</span>
              取消
            </a>
            <button type="submit" class="btn btn-primary">
              <span class="material-icons" style="font-size: 1rem;">save</span>
              保存修改
            </button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script>
    let nodeCount = <?= count($nodes) ?>;

    // 添加核销节点
    function addNode() {
      nodeCount++;
      const container = document.getElementById('nodesContainer');
      const nodeDiv = document.createElement('div');
      nodeDiv.className = 'node-item fade-in';
      nodeDiv.id = 'node-' + nodeCount;
      
      // 设置当前日期为默认值
      const today = new Date();
      const currentDate = today.toISOString().split('T')[0];
      
      nodeDiv.innerHTML = `
        <div class="node-header">
          <div class="node-title">
            <span class="node-number">${nodeCount}</span>
            核销节点
          </div>
          <button type="button" class="btn-remove" onclick="removeNode(${nodeCount})">
            <span class="material-icons" style="font-size: 0.875rem;">delete</span>
            删除
          </button>
        </div>
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">
              核销日期<span class="required">*</span>
            </label>
            <input 
              type="date" 
              name="nodes[${nodeCount}][write_off_date]" 
              class="form-control" 
              value="${currentDate}"
              required>
          </div>
          <div class="form-group">
            <label class="form-label">
              核销金额 (元)<span class="required">*</span>
            </label>
            <input 
              type="number" 
              name="nodes[${nodeCount}][amount]" 
              class="form-control" 
              placeholder="请输入核销金额" 
              step="0.01" 
              min="0" 
              required>
            <small class="form-help">请输入本次核销的金额</small>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">
            统计日期范围<span class="required">*</span>
          </label>
          <div class="date-range">
            <input 
              type="number" 
              name="nodes[${nodeCount}][start_day]" 
              class="form-control" 
              placeholder="起始日" 
              min="1" 
              max="31" 
              required>
            <span class="date-range-separator">至</span>
            <input 
              type="number" 
              name="nodes[${nodeCount}][end_day]" 
              class="form-control" 
              placeholder="结束日" 
              min="1" 
              max="31" 
              required>
          </div>
          <small class="form-help">请输入统计周期的起始日和结束日（1-31日）</small>
        </div>
      `;
      
      container.appendChild(nodeDiv);
      
      // 添加动画效果
      setTimeout(() => {
        nodeDiv.style.animation = 'fadeIn 0.4s ease forwards';
      }, 10);
    }

    // 删除核销节点
    function removeNode(id) {
      const node = document.getElementById('node-' + id);
      if (node) {
        if (confirm('确定要删除这个核销节点吗？')) {
          // 添加淡出动画
          node.style.opacity = '0';
          node.style.transform = 'translateY(-10px)';
          node.style.transition = 'all 0.3s ease';
          
          setTimeout(() => {
            node.remove();
          }, 300);
        }
      }
    }

    // 表单验证
    document.getElementById('configForm').addEventListener('submit', function(e) {
      const budget = document.querySelector('input[name="budget"]').value;
      const taskQuantity = document.querySelector('input[name="task_quantity"]').value;
      const targetVolume = document.querySelector('input[name="target_volume"]').value;

      if (!budget || !taskQuantity || !targetVolume) {
        e.preventDefault();
        alert('请填写所有必填项！');
        return false;
      }

      if (parseFloat(budget) <= 0) {
        e.preventDefault();
        alert('预算金额必须大于0！');
        return false;
      }

      if (parseInt(taskQuantity) <= 0) {
        e.preventDefault();
        alert('线索任务数必须大于0！');
        return false;
      }

      if (parseInt(targetVolume) <= 0) {
        e.preventDefault();
        alert('订单目标数必须大于0！');
        return false;
      }

      // 检查核销节点
      const nodeElements = document.querySelectorAll('.node-item');
      if (nodeElements.length === 0) {
        e.preventDefault();
        alert('请至少添加一个核销节点！');
        return false;
      }

      // 验证所有核销节点
      let isValid = true;
      nodeElements.forEach((node, index) => {
        const amount = node.querySelector('input[name^="nodes"][name$="[amount]"]').value;
        const startDay = node.querySelector('input[name^="nodes"][name$="[start_day]"]').value;
        const endDay = node.querySelector('input[name^="nodes"][name$="[end_day]"]').value;
        
        if (!amount || !startDay || !endDay) {
          isValid = false;
        }
        
        if (parseFloat(amount) <= 0) {
          isValid = false;
        }
        
        if (parseInt(startDay) > parseInt(endDay)) {
          isValid = false;
        }
      });
      
      if (!isValid) {
        e.preventDefault();
        alert('请检查核销节点信息，确保金额大于0且日期范围有效！');
        return false;
      }

      // 确认对话框
      const year = document.querySelector('input[name="year"]').value;
      const month = document.querySelector('input[name="month"]').value;
      if (!confirm(`确定要更新 ${year}年${month}月 的消耗配置吗？`)) {
        e.preventDefault();
        return false;
      }

      return true;
    });

    // 实时计算每日总线索和线索成本
    document.addEventListener('input', function(e) {
      const target = e.target;
      
      // 检查是否是每日明细表格的输入框
      if (target.name && target.name.includes('details') && 
          (target.name.includes('[natural_leads]') || 
           target.name.includes('[ad_leads]') || 
           target.name.includes('[daily_consumption]'))) {
        
        // 找到对应的行
        const row = target.closest('tr');
        if (row) {
          const naturalLeadsInput = row.querySelector('input[name*="[natural_leads]"]');
          const adLeadsInput = row.querySelector('input[name*="[ad_leads]"]');
          const dailyConsumptionInput = row.querySelector('input[name*="[daily_consumption]"]');
          const totalLeadsInput = row.querySelector('input[value]:not([name])');
          const costPerLeadInput = row.querySelectorAll('input[value]:not([name])')[1];
          
          if (naturalLeadsInput && adLeadsInput && dailyConsumptionInput && totalLeadsInput && costPerLeadInput) {
            const naturalLeads = parseInt(naturalLeadsInput.value) || 0;
            const adLeads = parseInt(adLeadsInput.value) || 0;
            const dailyConsumption = parseFloat(dailyConsumptionInput.value) || 0;
            const totalLeads = naturalLeads + adLeads;
            
            // 更新总线索
            totalLeadsInput.value = totalLeads;
            
            // 计算并更新线索成本
            const costPerLead = totalLeads > 0 ? (dailyConsumption / totalLeads) : 0;
            costPerLeadInput.value = costPerLead.toFixed(2);
          }
        }
      }
    });
  </script>
</body>
</html>