<?php
require_once "../api/fn.php";
session();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    $password_confirm = isset($_POST['password_confirm']) ? trim($_POST['password_confirm']) : '';

    // 验证ID
    if ($id <= 0) {
        echo "<script>alert('参数错误！'); history.back();</script>";
        exit;
    }

    // 验证用户名
    if (empty($name)) {
        echo "<script>alert('用户名不能为空！'); history.back();</script>";
        exit;
    }

    // 验证必须填写新密码
    if (empty($password) || empty($password_confirm)) {
        echo "<script>alert('请填写新密码！'); history.back();</script>";
        exit;
    }

    // 验证密码一致性
    if ($password !== $password_confirm) {
        echo "<script>alert('两次输入的密码不一致！'); history.back();</script>";
        exit;
    }

    // 验证密码长度
    if (strlen($password) < 6) {
        echo "<script>alert('密码长度至少为6位！'); history.back();</script>";
        exit;
    }

    // 获取原用户信息
    $user = get_user_by_id($id);
    if (!$user) {
        echo "<script>alert('用户不存在！'); window.location.href='../user_list.php';</script>";
        exit;
    }
    // 盐值
    $yan_x = bin2hex(random_bytes(16));
    
    // 加密新密码
    $password_encrypted = password_hash($password . $yan_x, PASSWORD_DEFAULT);

    // 调用更新函数
    $result = update_user($id, $name, $password_encrypted, $yan_x );

    if ($result) {
        echo "<script>alert('用户更新成功！'); window.location.href='../user_list.php';</script>";
    } else {
        echo "<script>alert('用户更新失败！'); history.back();</script>";
    }
} else {
    header('Location: ../user_list.php');
    exit;
}
