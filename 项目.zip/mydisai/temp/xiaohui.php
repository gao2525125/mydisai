<?php

require_once "../api/fn.php";
session();
unset($_SESSION["username"]);
setcookie('remember_token', '', time() - 3600, '/');


?>  
<script type="text/javascript">  
    // 使用 setTimeout 函数在1秒后执行跳转  
    alert("退出成功");  
    setTimeout(function () {  
       top.window.location.href = "../login.php";  
    }, 200); // 延迟1秒（1000毫秒）  
</script>  
<?php 
?>