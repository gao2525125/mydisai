<?php
require "../api/fn.php";
session_start(); // 开始会话  




if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取表单数据
    $username = $_POST['username'];
    $password = $_POST['password'];
    $verifyCode = $_POST['verifyCode'];
    $rememberMe = isset($_POST['checkbox']); // 检查复选框是否被选中  


// 获取会话中存储的验证码  
    $realCaptcha = isset($_SESSION['captcha']) ? $_SESSION['captcha'] : '';
    // 清除会话中的验证码，防止重复使用  
    unset($_SESSION['captcha']);
    // 数据库的管理员信息
    $data = login($username);

    // 解密验证码
    $password_true = password_verify($password . $data["yan"], $data["password"]);


    // 验证账号密码
    if ($username === $data["name"] && $password_true) {

        // 验证验证码
        if ($verifyCode == $realCaptcha) {
            $_SESSION['username'] = $username;
            // var_dump( $_SESSION['username']);
            if ($rememberMe) {
                $cookieValue = uniqid(); // 生成一个唯一的令牌作为cookie的值  
                // 保持7天
                setcookie('remember_token', $cookieValue, time() + 3600 * 24 * 7, '/');
            }

            ?>
            <script type="text/javascript">
                // 使用 setTimeout 函数在1秒后执行跳转  
                alert("登入成功");
                setTimeout(function () {
                    window.location.href = "../index.php";
                }, 100);
            </script>
            <?php
            // header('Location: ../data/index.php');
            exit; // 确保重定向发生，后面的代码不会被执行  
        } else {
            $_SESSION['username_l'] = $_POST['username'];
            $_SESSION['verifyCode_l'] = $_POST['verifyCode'];
            $_SESSION['password_l'] = $_POST['password'];
            ?>
            <script type="text/javascript">
                // 使用 setTimeout 函数在1秒后执行跳转  
                alert("验证码错误，请重新输入");
                setTimeout(function () {
                    window.location.href = "../login.php";
                }, 100);
            </script>
            <?php
        }



    } else {
        // 将输入的数据存储在会话中  
        $_SESSION['username_l'] = $_POST['username'];
        $_SESSION['password_l'] = $_POST['password'];
        $_SESSION['verifyCode_l'] = $_POST['verifyCode'];
        ?>
        <script type="text/javascript">
            // 使用 setTimeout 函数在1秒后执行跳转  
            alert("账号密码错误");
            setTimeout(function () {
                window.location.href = "../login.php";
            }, 100);
        </script>
        <?php
    }
}





?>