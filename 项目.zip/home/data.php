<?php
$ad_cost_threshold = 120; // 广告线索成本阈值
$comprehensive_cost_threshold = 100; // 综合线索成本阈值
require_once "./api/fn.php";

// 获取当前年月
$current_year = date('Y');
$current_month = date('n');

// 从GET参数获取选择的月份，如果没有则使用当前月份
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : $current_year;
$selected_month = isset($_GET['month']) ? intval($_GET['month']) : $current_month;

// 获取当月数据
$data = get_current_month_data($selected_year, $selected_month);

if (!$data) {
    echo "<script>alert('" . $selected_year . "年" . $selected_month . "月暂无配置数据！请联系管理员添加。');</script>";
    $data = array(
        'config' => array(
            'year' => $selected_year,
            'month' => $selected_month,
            'budget' => 0,
            'task_quantity' => 0,
            'target_volume' => 0,
            'remarks' => '暂无数据'
        ),
        'details' => array(),
        'nodes' => array(),
        'summary' => array(
            'total_consumption' => 0,
            'total_natural_leads' => 0,
            'total_ad_leads' => 0,
            'total_orders' => 0,
            'total_leads' => 0,
            'remaining_budget' => 0,
            'budget_usage_rate' => 0,
            'leads_diff' => 0,
            'leads_completion_rate' => 0,
            'order_completion_rate' => 0,
            'cost_per_lead' => 0
        )
    );
}

$config = $data['config'];
$details = $data['details'];
$nodes = $data['nodes'];
$summary = $data['summary'];
?>

<!DOCTYPE html>
<html lang="zh-CN">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>中国星-每日消耗进度追踪表</title>
    <script src="./js/xlsx.full.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Microsoft YaHei', Arial, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            padding: 25px;
        }

        header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #eaeaea;
        }

        h1 {
            color: #ff2e63;
            margin-bottom: 10px;
            font-size: 28px;
        }

        .description {
            color: #666;
            font-size: 16px;
            max-width: 800px;
            margin: 0 auto;
        }

        .controls {
            display: flex;
            justify-content: space-between;
            margin-bottom: 25px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .button-group {
            display: flex;
            gap: 10px;
        }

        button {
            padding: 10px 20px;
            background-color: #4a6cf7;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
        }

        button:hover {
            background-color: #3050d8;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        #saveBtn {
            background-color: #10b981;
        }

        #saveBtn:hover {
            background-color: #0da271;
        }

        #downloadBtn {
            background-color: #3b82f6;
        }

        #downloadBtn:hover {
            background-color: #2563eb;
        }

        #adminBtn {
            background-color: #8b5cf6;
        }

        #adminBtn:hover {
            background-color: #7c3aed;
        }

        .month-selector {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .month-selector label {
            font-weight: bold;
            color: #555;
        }

        .month-selector select,
        .month-selector input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .table-container {
            overflow-x: auto;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #e0e0e0;
            padding: 12px 8px;
            text-align: center;
            font-size: 14px;
        }

        th {
            background-color: #f8f9fa;
            font-weight: bold;
            color: #444;
        }

        .section-title {
            background-color: #f0f7ff;
            font-weight: bold;
            text-align: left;
            padding-left: 15px;
            color: #4a6cf7;
            font-size: 18px;
            padding: 15px;
            margin-top: 20px;
            border-radius: 5px;
            border-left: 5px solid #4a6cf7;
        }

        .summary-row {
            background-color: #f9f9f9;
            font-weight: bold;
        }

        .highlight {
            background-color: #e8f5e9;
        }

        .warning {
            background-color: #fff3e0;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            text-align: center;
        }

        input[type="text"]:focus,
        input[type="number"]:focus,
        input[type="date"]:focus {
            outline: none;
            border-color: #4a6cf7;
            box-shadow: 0 0 0 2px rgba(74, 108, 247, 0.2);
        }

        .calculations {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            border-left: 4px solid #d80104;
        }

        .calculations h3 {
            margin-bottom: 10px;
            color: #d80104;
        }

        .calculations div {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding-bottom: 8px;
            border-bottom: 1px dashed #ddd;
        }

        .calculations span {
            font-weight: bold;
            color: #4a6cf7;
        }

        .admin-info {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
            border-left: 4px solid #f59e0b;
        }

        .admin-info h3 {
            margin-bottom: 10px;
            color: #f59e0b;
        }

        .admin-info .item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            padding-bottom: 8px;
            border-bottom: 1px dashed #ddd;
        }

        .admin-info .item span:first-child {
            font-weight: bold;
            color: #666;
        }

        .admin-info .item span:last-child {
            font-weight: bold;
            color: #4a6cf7;
        }

        .remarks-section {
            background-color: #f0f9ff;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            border-left: 4px solid #3b82f6;
        }

        .remarks-section h3 {
            margin-bottom: 15px;
            color: #3b82f6;
        }

        #remarksContent {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 18px;
            line-height: 1.5;
            background-color: #fff;
            min-height: 40px;
        }

        .status-message {
            padding: 12px 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: center;
            display: none;
        }

        .status-message.success {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
            display: block;
        }

        .status-message.error {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
            display: block;
        }

        footer {
            text-align: center;
            margin-top: 30px;
            color: #888;
            font-size: 14px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .readonly-cell {
            background-color: #f8f9fa;
            padding: 8px;
            border-radius: 4px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .controls {
                flex-direction: column;
            }

            .button-group {
                justify-content: center;
            }

            .month-selector {
                justify-content: center;
            }

            th,
            td {
                padding: 8px 5px;
                font-size: 12px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <header>
            <h1>中国星<?= $config['year'] ?>年<?= $config['month'] ?>月本地通数据进度追踪表</h1>
            <p class="description">本表格用于追踪抖音本地通账户的每日消耗进度、预算使用情况、线索获取数据及核销节点管理。</p>
        </header>

        <div class="controls">
            <div class="month-selector">
                <form id="monthForm" method="get" style="display: flex; align-items: center; gap: 10px;">
                    <label>选择月份：</label>
                    <select id="yearSelect" name="year" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px;">
                        <?php
                        // 生成年份选项，最近5年
                        for ($y = $current_year; $y >= $current_year - 4; $y--) {
                            $selected = ($y == $selected_year) ? 'selected' : '';
                            echo "<option value='$y' $selected>$y 年</option>";
                        }
                        ?>
                    </select>
                    <select id="monthSelect" name="month" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 5px; font-size: 16px;">
                        <?php
                        // 生成月份选项
                        for ($m = 1; $m <= 12; $m++) {
                            $selected = ($m == $selected_month) ? 'selected' : '';
                            echo "<option value='$m' $selected>$m 月</option>";
                        }
                        ?>
                    </select>
                    <button type="submit" style="padding: 8px 20px; background-color: #10b981; margin-left: 0;">查询</button>
                </form>
            </div>

            <div class="button-group">
                <button id="downloadBtn" type="button" onclick="downloadExcel()">下载Excel表格</button>
                <button type="button" style="background-color: #c73e3a;" onclick="window.location.href='./temp/xiaohui.php'">数据填报</button>
            </div>
        </div>

        <div id="statusMessage" class="status-message"></div>

        <div class="table-container">
            
            <!-- 关键指标 -->
            <div class="calculations">
                <h3>关键指标计算结果</h3>
                <div>
                    <span>预算使用率：</span>
                    <span
                        style="color: <?= $summary['budget_usage_rate'] > 100 ? '#c73e3a' : ($summary['budget_usage_rate'] > 80 ? '#f59e0b' : '#10b981') ?>;">
                        <?= number_format($summary['budget_usage_rate'], 2) ?>%
                    </span>
                </div>
                <div>
                    <span>已消耗金额：</span>
                    <span>¥<?= number_format($summary['total_consumption'], 2) ?></span>
                </div>
                <div>
                    <span>剩余预算：</span>
                    <span style="color: <?= $summary['remaining_budget'] > 0 ? '#10b981' : '#e00d10' ?>;">
                        ¥<?= number_format($summary['remaining_budget'], 2) ?>
                    </span>
                </div>
                
                <div>
                    <span>本月线索情况：</span>
                    <span style="color: <?= $summary['leads_completion_rate'] >= 100 ? '#10b981' : '#e00d10' ?>; font-size: 14pt;">
                        本月线索任务：<?= number_format($config['task_quantity']) ?>条，
                        已完成：<?= number_format($summary['total_leads']) ?>条，
                        完成率：<?= number_format($summary['leads_completion_rate'], 2) ?>%
                    </span>
                </div>
                
                <div>
                    <span>订单完成情况：</span>
                    <span style="color: <?= $summary['order_completion_rate'] >= 100 ? '#10b981' : '#e00d10' ?>; font-size: 14pt;">
                        本月订单任务：<?= number_format($config['target_volume']) ?>台，
                        已完成：<?= number_format($summary['total_orders']) ?>台，
                        完成率：<?= number_format($summary['order_completion_rate'], 2) ?>%
                    </span>
                </div>
                

                <div>
                    <span>本月线索成本：</span>
                    <span style="font-size: 14pt;">
                        广告成本：<span style="color: <?= $summary['ad_leads_cost'] <= $ad_cost_threshold ? '#10b981' : '#e00d10' ?>;">
                            ¥<?= number_format($summary['ad_leads_cost'], 2) ?> / 条
                        </span>，
                        综合成本：<span style="color: <?= $summary['cost_per_lead'] <= $comprehensive_cost_threshold ? '#10b981' : '#e00d10' ?>;">
                            ¥<?= number_format($summary['cost_per_lead'], 2) ?> / 条
                        </span>
                    </span>
                </div>
               <div>
                    <span>线索差额：</span>
                    <span style="color: <?= $summary['leads_diff'] <= 0 ? '#10b981' : '#e00d10' ?>; font-size: 14pt;">
                            <?php if ($summary['leads_diff'] > 0): ?>
                                差<?= number_format($summary['leads_diff']) ?> 条
                            <?php elseif ($summary['leads_diff'] < 0): ?>
                                超任务完成<?= number_format(abs($summary['leads_diff'])) ?> 条
                            <?php else: ?>
                                刚好完成
                            <?php endif; ?>
                    </span>
                    </div>
               </div>
               
            
            
            
            
            
             <!-- 核销节点追踪 -->
            <div class="section-title">核销节点追踪</div>
            <table id="verificationTable">
                <thead>
                    <tr>
                        <th>核销节点</th>
                        <th>核销日期</th>
                        <th>核销金额 (元)</th>
                        <th>统计日期范围</th>
                        <th>已消耗金额 (元)</th>
                        <th>消耗差额 (元)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($nodes) > 0): ?>
                        <?php foreach ($nodes as $index => $node): ?>
                            <tr>
                                <td>节点 <?= $index + 1 ?></td>
                                <td><?= date('Y-m-d', strtotime($node['write_off_date'])) ?></td>
                                <td>¥<?= number_format($node['amount'], 2) ?></td>
                                <td><?= $node['start_date'] ?>日 - <?= $node['end_date'] ?>日</td>
                                <td style="color: #3b82f6; font-weight: bold;">
                                    ¥<?= number_format($node['consumed_amount'], 2) ?></td>
                                <td
                                    style="color: <?= $node['consumption_diff'] >= 0 ? '#10b981' : '#c73e3a' ?>; font-weight: bold;">
                                    ¥<?= number_format($node['consumption_diff'], 2) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #999;">暂无核销节点数据</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <!-- 账户信息与月度汇总 -->
            <div class="section-title">账户信息与月度汇总</div>
            <table id="accountSummaryTable">
                <tbody>
                    <tr>
                        <td style="width: 10%;">统计年月</td>
                        <td style="width: 23.33%;" class="readonly-cell"><?= $config['year'] ?>年<?= $config['month'] ?>月
                        </td>
                        <td style="width: 10%;">本月消耗预算</td>
                        <td style="width: 23.33%;" class="readonly-cell">¥<?= number_format($config['budget'], 2) ?>
                        </td>
                        <td style="width: 10%;">已消耗金额</td>
                        <td style="width: 23.33%;" style="color: #c73e3a; font-weight: bold;">
                            ¥<?= number_format($summary['total_consumption'], 2) ?></td>
                    </tr>
                    <tr>
                        <td>剩余预算</td>
                        <td
                            style="color: <?= $summary['remaining_budget'] > 0 ? '#10b981' : '#c73e3a' ?>; font-weight: bold;">
                            ¥<?= number_format($summary['remaining_budget'], 2) ?></td>
                        <td>预算使用率</td>
                        <td
                            style="color: <?= $summary['budget_usage_rate'] > 100 ? '#c73e3a' : ($summary['budget_usage_rate'] > 80 ? '#f59e0b' : '#10b981') ?>; font-weight: bold;">
                            <?= number_format($summary['budget_usage_rate'], 2) ?>%</td>
                        <td>月度线索任务</td>
                        <td class="readonly-cell"><?= number_format($config['task_quantity']) ?> 条</td>
                    </tr>
                    <tr>
                        <td>本月已有线索</td>
                        <td style="color: #3b82f6; font-weight: bold;"><?= number_format($summary['total_leads']) ?> 条
                        </td>
                        <td>线索任务完成率</td>
                        <td
                            style="color: <?= $summary['leads_completion_rate'] >= 100 ? '#10b981' : '#e00d10' ?>; font-weight: bold;">
                            <?= number_format($summary['leads_completion_rate'], 2) ?>%</td>
                        <td>本月订单目标</td>
                        <td class="readonly-cell"><?= number_format($config['target_volume']) ?> 单</td>
                    </tr>
                    <tr>
                        <td>本月订单数</td>
                        <td style="color: #10b981; font-weight: bold;"><?= number_format($summary['total_orders']) ?> 单
                        </td>
                        <td>订单完成率</td>
                        <td
                            style="color: <?= $summary['order_completion_rate'] >= 100 ? '#10b981' : '#e00d10' ?>; font-weight: bold;">
                            <?= number_format($summary['order_completion_rate'], 2) ?>%</td>
                        <td>线索综合成本</td>
                        <td style="color: #ff0000; font-weight: bold; font-size: 14pt;">¥<?= number_format($summary['cost_per_lead'], 2) ?> / 条</td>
                    </tr>
                    <tr>
                        <td>订单成本</td>
                        <td style="color: #ff0000; font-weight: bold; font-size: 14pt;">¥<?= number_format($summary['cost_per_order'], 2) ?> / 单</td>
                        <td>广告线索数量</td>
                        <td><?= number_format($summary['total_ad_leads']) ?> 条</td>
                        <td>广告线索成本</td>
                        <td style="color: #ff0000; font-weight: bold; font-size: 14pt;">¥<?= number_format($summary['ad_leads_cost'], 2) ?> / 条</td>
                    </tr>
                </tbody>
            </table>
			
            <!-- 每日消耗与线索明细 -->
            <div class="section-title">每日消耗与线索明细</div>
            <form id="dailyForm" method="post" action="./temp/save_daily.php">
                <table id="dailyTable">
                    <thead>
                        <tr>
                            <th>日期</th>
                            <th>自然线索</th>
                            <th>广告线索</th>
                            <th>当日消耗 (元)</th>
                            <th>订单数</th>
                            <th>当日总线索</th>
                            <th>线索成本 (元)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($details as $detail):
                            $day_total_leads = intval($detail['natural_leads']) + intval($detail['ad_leads']);
                            $day_cost = $day_total_leads > 0 ? floatval($detail['daily_consumption']) / $day_total_leads : 0;
                            ?>
                            <tr>
                                <td><strong><?= $config['month'] ?>月<?= $detail['day_of_month'] ?>日</strong></td>
                                <td>
                                    <input type="hidden" name="details[<?= $detail['id'] ?>][id]"
                                        value="<?= $detail['id'] ?>">
                                    <input type="number" name="details[<?= $detail['id'] ?>][natural_leads]"
                                        value="<?= $detail['natural_leads'] ?>" readonly class="no-border"
                                        onchange="calculateRow(this)">
                                </td>
                                <td>
                                    <input type="number" name="details[<?= $detail['id'] ?>][ad_leads]"
                                        value="<?= $detail['ad_leads'] ?>" readonly class="no-border"
                                        onchange="calculateRow(this)">
                                </td>
                                <td>
                                    <input type="number" name="details[<?= $detail['id'] ?>][daily_consumption]"
                                        value="<?= $detail['daily_consumption'] ?>" step="0.01" readonly class="no-border"
                                        onchange="calculateRow(this)">
                                </td>
                                <td>
                                    <input type="number" name="details[<?= $detail['id'] ?>][order_quantity]"
                                        value="<?= $detail['order_quantity'] ?>" readonly class="no-border">
                                </td>
                                <td class="readonly-cell"><?= number_format($day_total_leads) ?></td>
                                <td class="readonly-cell">¥<?= number_format($day_cost, 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>

           

            <!-- 备注内容 -->
            <div class="remarks-section">
                <h3>备注内容</h3>
                <div id="remarksContent">
                    <?= !empty($config['remarks']) ? nl2br(htmlspecialchars($config['remarks'])) : '暂无备注内容' ?>
                </div>
            </div>

        </div>

        <footer>
            <p>抖音本地通消耗进度追踪系统 &copy; 2025 | 版本：1.0</p>
        </footer>
    </div>

    <script>
        // 添加简单的表单提交提示
        document.getElementById('monthForm').addEventListener('submit', function(e) {
            // 显示加载提示
            document.getElementById('statusMessage').innerHTML = '正在加载' + 
                document.getElementById('yearSelect').value + '年' + 
                document.getElementById('monthSelect').value + '月数据...';
            document.getElementById('statusMessage').className = 'status-message success';
            document.getElementById('statusMessage').style.display = 'block';
        });

        // 下载Excel
        function downloadExcel() {
            // 修改下载链接，带上当前选择的月份参数
            var year = document.getElementById('yearSelect').value;
            var month = document.getElementById('monthSelect').value;
            window.location.href = './temp/excel.php?year=' + year + '&month=' + month;
        }
    </script>
</body>

</html>