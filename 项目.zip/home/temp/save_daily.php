<?php
require_once "../api/fn.php";

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $details = isset($_POST['details']) ? $_POST['details'] : array();

    // 处理业务明细数据
    $processed_details = array();
    if (!empty($details) && is_array($details)) {
        foreach ($details as $detail) {
            if (isset($detail['id'])) {
                $natural_leads = isset($detail['natural_leads']) ? intval($detail['natural_leads']) : 0;
                $ad_leads = isset($detail['ad_leads']) ? intval($detail['ad_leads']) : 0;
                $daily_consumption = isset($detail['daily_consumption']) ? floatval($detail['daily_consumption']) : 0;
                $order_quantity = isset($detail['order_quantity']) ? intval($detail['order_quantity']) : 0;
                
                // 验证数据
                if ($natural_leads < 0 || $ad_leads < 0 || $daily_consumption < 0 || $order_quantity < 0) {
                    echo "<script>alert('业务明细数据不能为负数！'); history.back();</script>";
                    exit;
                }
                
                $processed_details[] = array(
                    'id' => $detail['id'],
                    'natural_leads' => $natural_leads,
                    'ad_leads' => $ad_leads,
                    'daily_consumption' => $daily_consumption,
                    'order_quantity' => $order_quantity
                );
            }
        }
    }

    // 更新数据
    $result = update_daily_details($processed_details);

    if ($result['success']) {
        echo "<script>alert('保存成功！'); window.location.href='../index.php';</script>";
    } else {
        echo "<script>alert('保存失败：" . addslashes($result['message']) . "'); history.back();</script>";
    }
} else {
    header('Location: ../index.php');
    exit;
}

