<?php

session_start();
unset($_SESSION["user_name"]);


?>
<script type="text/javascript">
    alert("ok");
    window.location.href = "../login.php";  
</script>