<?php

// 本地
$servername = "localhost";
$username = "zhongguoxing";//数据库名
$password = "GAObuhaoba.123";//密码
$dbname = "zhongguoxing";//用户名
$dbport = "3306";


// 创建连接
$mysqli = new mysqli($servername, $username, $password, $dbname, $dbport);

// 检查连接
if ($mysqli->connect_error) {
    die("连接失败: " . $mysqli->connect_error);
}

// 设置字符集，不设置会造成数据库乱码
if (!$mysqli->set_charset('utf8')) {
    exit($mysqli->error);
}
