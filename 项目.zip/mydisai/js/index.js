document.addEventListener('DOMContentLoaded', function () {
    const iframe = document.querySelector('#list_windows iframe');
    const shiren = document.querySelector('#shiren_list');
    const add_shiren = document.querySelector('#shiren');
    const edit_password = document.querySelector('#edit_password');



    // 诗人列表
    shiren.addEventListener('click', function (event) {
        event.preventDefault();
        iframe.src = "./shiren_list.php";
    });



    // 添加诗人
    add_shiren.addEventListener('click', function (event) {
        event.preventDefault();
        iframe.src = "./add_shiren.php";
    });

    // 修改密码
    edit_password.addEventListener('click', function (event) {
        event.preventDefault();
        iframe.src = "./edit_password.php";
    })




});

// 选中样式
function setActiveLink(element) {
    // 移除所有链接的 active 样式
    var links = document.querySelectorAll('.nav-link');
    links.forEach(function (link) {
        link.classList.remove('active');
    });

    // 给被点击的链接添加 active 样式
    element.classList.add('active');
}



// 在主页面中修改密码后退出
window.addEventListener('message', function(event) {  
if (event.data === 'password_changed') {  
// 退出到登录界面的逻辑，例如重定向到登录页面的URL  
window.location.href = '../login.php';  
}  
}, false);
