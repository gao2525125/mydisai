<?php
require_once "../api/fn.php";
session();

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 获取基础配置数据
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $year = isset($_POST['year']) ? intval($_POST['year']) : 0;
    $month = isset($_POST['month']) ? intval($_POST['month']) : 0;
    $budget = isset($_POST['budget']) ? floatval($_POST['budget']) : 0;
    $task_quantity = isset($_POST['task_quantity']) ? intval($_POST['task_quantity']) : 0;
    $target_volume = isset($_POST['target_volume']) ? intval($_POST['target_volume']) : 0;
    $remarks = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';
    $nodes = isset($_POST['nodes']) ? $_POST['nodes'] : array();
    $details = isset($_POST['details']) ? $_POST['details'] : array();

    // 验证必填字段
    if (empty($id) || empty($year) || empty($month) || empty($budget) || empty($task_quantity) || empty($target_volume)) {
        echo "<script>alert('请填写所有必填项！'); history.back();</script>";
        exit;
    }

    // 验证数据有效性
    if ($budget <= 0) {
        echo "<script>alert('预算金额必须大于0！'); history.back();</script>";
        exit;
    }

    if ($task_quantity <= 0) {
        echo "<script>alert('线索任务数必须大于0！'); history.back();</script>";
        exit;
    }

    if ($target_volume <= 0) {
        echo "<script>alert('订单目标数必须大于0！'); history.back();</script>";
        exit;
    }

    // 处理核销节点数据，将日期转换为完整日期格式
    $processed_nodes = array();
    if (!empty($nodes) && is_array($nodes)) {
        foreach ($nodes as $node) {
            if (isset($node['write_off_date']) && isset($node['amount']) && 
                isset($node['start_day']) && isset($node['end_day'])) {
                
                $start_day = intval($node['start_day']);
                $end_day = intval($node['end_day']);
                
                // 验证日期范围
                if ($start_day < 1 || $start_day > 31 || $end_day < 1 || $end_day > 31) {
                    echo "<script>alert('日期必须在1-31之间！'); history.back();</script>";
                    exit;
                }
                
                if ($start_day > $end_day) {
                    echo "<script>alert('起始日不能大于结束日！'); history.back();</script>";
                    exit;
                }
                
                // 直接存储日期数字
                $processed_nodes[] = array(
                    'write_off_date' => $node['write_off_date'],
                    'amount' => $node['amount'],
                    'start_date' => $start_day,
                    'end_date' => $end_day
                );
            }
        }
    }

    // 处理业务明细数据
    $processed_details = array();
    if (!empty($details) && is_array($details)) {
        foreach ($details as $detail) {
            if (isset($detail['id'])) {
                $natural_leads = isset($detail['natural_leads']) ? intval($detail['natural_leads']) : 0;
                $ad_leads = isset($detail['ad_leads']) ? intval($detail['ad_leads']) : 0;
                $daily_consumption = isset($detail['daily_consumption']) ? floatval($detail['daily_consumption']) : 0;
                $order_quantity = isset($detail['order_quantity']) ? intval($detail['order_quantity']) : 0;
                
                // 验证数据
                if ($natural_leads < 0 || $ad_leads < 0 || $daily_consumption < 0 || $order_quantity < 0) {
                    echo "<script>alert('业务明细数据不能为负数！'); history.back();</script>";
                    exit;
                }
                
                $processed_details[] = array(
                    'id' => $detail['id'],
                    'natural_leads' => $natural_leads,
                    'ad_leads' => $ad_leads,
                    'daily_consumption' => $daily_consumption,
                    'order_quantity' => $order_quantity
                );
            }
        }
    }

    // 更新配置
    $result = update_config_with_nodes_and_details($id, $budget, $task_quantity, $target_volume, $remarks, $processed_nodes, $processed_details);

    if ($result['success']) {
        echo "<script>alert('更新成功！'); window.location.href='../home.php';</script>";
    } else {
        echo "<script>alert('更新失败：" . addslashes($result['message']) . "'); history.back();</script>";
    }
} else {
    header('Location: ../home.php');
    exit;
}

