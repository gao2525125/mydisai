<?php
require_once "../api/fn.php";
require_once "../vendor/autoload.php";

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Border;

// 获取当前年月
$current_year = date('Y');
$current_month = date('n');

// 获取数据
$data = get_current_month_data($current_year, $current_month);

if (!$data) {
    echo "<script>alert('当前月份暂无配置数据！'); window.history.back();</script>";
    exit;
}

$config = $data['config'];
$details = $data['details'];
$nodes = $data['nodes'];
$summary = $data['summary'];

// 创建Excel对象
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

$rowIndex = 1;

// ==================== 标题 ====================
$sheet->setCellValue('A' . $rowIndex, '抖音本地通每日消耗进度追踪表 (' . $config['year'] . '年' . $config['month'] . '月)');
$sheet->mergeCells('A' . $rowIndex . ':G' . $rowIndex);
$sheet->getStyle('A' . $rowIndex)->getFont()->setSize(16)->setBold(true);
$sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getRowDimension($rowIndex)->setRowHeight(30);
$rowIndex++;
$rowIndex++; // 空一行

// ==================== 账户信息与月度汇总 ====================
$sheet->setCellValue('A' . $rowIndex, '账户信息与月度汇总');
$sheet->mergeCells('A' . $rowIndex . ':G' . $rowIndex);
$sheet->getStyle('A' . $rowIndex)->getFont()->setSize(14)->setBold(true);
$sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFE8F5E9');
$rowIndex++;

// 账户信息数据
$accountInfo = array(
    array('统计年月', $config['year'] . '年' . $config['month'] . '月', '本月消耗预算', '¥' . number_format($config['budget'], 2), '已消耗金额', '¥' . number_format($summary['total_consumption'], 2)),
    array('剩余预算', '¥' . number_format($summary['remaining_budget'], 2), '预算使用率', number_format($summary['budget_usage_rate'], 2) . '%', '月度线索任务', number_format($config['task_quantity']) . ' 条'),
    array('本月已有线索', number_format($summary['total_leads']) . ' 条', '线索任务完成率', number_format($summary['leads_completion_rate'], 2) . '%', '本月订单目标', number_format($config['target_volume']) . ' 单'),
    array('本月订单数', number_format($summary['total_orders']) . ' 单', '订单完成率', number_format($summary['order_completion_rate'], 2) . '%', '总线索成本', '¥' . number_format($summary['cost_per_lead'], 2) . ' / 条'),
    array('订单成本', '¥' . number_format($summary['cost_per_order'], 2) . ' / 单', '广告线索数量', number_format($summary['total_ad_leads']) . ' 条', '广告线索成本', '¥' . number_format($summary['ad_leads_cost'], 2) . ' / 条')
);

foreach ($accountInfo as $row) {
    $sheet->fromArray($row, NULL, 'A' . $rowIndex);
    // 设置样式
    for ($col = 'A'; $col <= 'F'; $col++) {
        $cell = $col . $rowIndex;
        $sheet->getStyle($cell)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle($cell)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getStyle($cell)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
        
        // 标题列加粗
        if ($col == 'A' || $col == 'C' || $col == 'E') {
            $sheet->getStyle($cell)->getFont()->setBold(true);
            $sheet->getStyle($cell)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFF0F0F0');
        }
    }
    $rowIndex++;
}
$rowIndex++; // 空一行

// ==================== 每日消耗与线索明细 ====================
$sheet->setCellValue('A' . $rowIndex, '每日消耗与线索明细');
$sheet->mergeCells('A' . $rowIndex . ':G' . $rowIndex);
$sheet->getStyle('A' . $rowIndex)->getFont()->setSize(14)->setBold(true);
$sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFE3F2FD');
$rowIndex++;

// 表头
$dailyHeader = array('日期', '自然线索', '广告线索', '当日消耗 (元)', '订单数', '当日总线索', '线索成本 (元)');
$sheet->fromArray($dailyHeader, NULL, 'A' . $rowIndex);
$sheet->getStyle('A' . $rowIndex . ':G' . $rowIndex)->getFont()->setBold(true);
$sheet->getStyle('A' . $rowIndex . ':G' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
$sheet->getStyle('A' . $rowIndex . ':G' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFE0E0E0');
$sheet->getStyle('A' . $rowIndex . ':G' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
$rowIndex++;

// 数据
$total_natural = 0;
$total_ad = 0;
$total_consumption = 0;
$total_orders = 0;
$total_cost_sum = 0; // 累加每日线索成本

foreach ($details as $detail) {
    $day_total_leads = intval($detail['natural_leads']) + intval($detail['ad_leads']);
    $day_cost = $day_total_leads > 0 ? floatval($detail['daily_consumption']) / $day_total_leads : 0;
    
    $dailyRow = array(
        $config['month'] . '月' . $detail['day_of_month'] . '日',
        number_format($detail['natural_leads']),
        number_format($detail['ad_leads']),
        '¥' . number_format($detail['daily_consumption'], 2),
        number_format($detail['order_quantity']),
        number_format($day_total_leads),
        '¥' . number_format($day_cost, 2)
    );
    
    $sheet->fromArray($dailyRow, NULL, 'A' . $rowIndex);
    
    // 设置样式
    for ($col = 'A'; $col <= 'G'; $col++) {
        $cell = $col . $rowIndex;
        $sheet->getStyle($cell)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
        $sheet->getStyle($cell)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
        $sheet->getStyle($cell)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
    }
    
    // 累加合计数据
    $total_natural += intval($detail['natural_leads']);
    $total_ad += intval($detail['ad_leads']);
    $total_consumption += floatval($detail['daily_consumption']);
    $total_orders += intval($detail['order_quantity']);
    $total_cost_sum += $day_cost; // 累加每日线索成本
    
    $rowIndex++;
}

// 合计行
$totalRow = array(
    '合计',
    number_format($total_natural),
    number_format($total_ad),
    '¥' . number_format($total_consumption, 2),
    number_format($total_orders),
    number_format($total_natural + $total_ad),
    '¥' . number_format($total_cost_sum, 2) // 每日线索成本的累加和
);
$sheet->fromArray($totalRow, NULL, 'A' . $rowIndex);
$sheet->getStyle('A' . $rowIndex . ':G' . $rowIndex)->getFont()->setBold(true);
$sheet->getStyle('A' . $rowIndex . ':G' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFFF3E0');
for ($col = 'A'; $col <= 'G'; $col++) {
    $cell = $col . $rowIndex;
    $sheet->getStyle($cell)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle($cell)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
}
$rowIndex++;
$rowIndex++; // 空一行

// ==================== 核销节点追踪 ====================
$sheet->setCellValue('A' . $rowIndex, '核销节点追踪（后端填写）');
$sheet->mergeCells('A' . $rowIndex . ':F' . $rowIndex);
$sheet->getStyle('A' . $rowIndex)->getFont()->setSize(14)->setBold(true);
$sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFFFF3E0');
$rowIndex++;

if (count($nodes) > 0) {
    // 表头
    $nodeHeader = array('核销节点', '核销日期', '核销金额 (元)', '统计日期范围', '已消耗金额 (元)', '消耗差额 (元)');
    $sheet->fromArray($nodeHeader, NULL, 'A' . $rowIndex);
    $sheet->getStyle('A' . $rowIndex . ':F' . $rowIndex)->getFont()->setBold(true);
    $sheet->getStyle('A' . $rowIndex . ':F' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle('A' . $rowIndex . ':F' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFE0E0E0');
    $sheet->getStyle('A' . $rowIndex . ':F' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
    $rowIndex++;
    
    // 数据
    foreach ($nodes as $index => $node) {
        $nodeRow = array(
            '节点 ' . ($index + 1),
            date('Y-m-d', strtotime($node['write_off_date'])),
            '¥' . number_format($node['amount'], 2),
            $node['start_date'] . '日 - ' . $node['end_date'] . '日',
            '¥' . number_format($node['consumed_amount'], 2),
            '¥' . number_format($node['consumption_diff'], 2)
        );
        
        $sheet->fromArray($nodeRow, NULL, 'A' . $rowIndex);
        
        // 设置样式
        for ($col = 'A'; $col <= 'F'; $col++) {
            $cell = $col . $rowIndex;
            $sheet->getStyle($cell)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
            $sheet->getStyle($cell)->getAlignment()->setVertical(Alignment::VERTICAL_CENTER);
            $sheet->getStyle($cell)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
        }
        
        $rowIndex++;
    }
} else {
    $sheet->setCellValue('A' . $rowIndex, '暂无核销节点数据');
    $sheet->mergeCells('A' . $rowIndex . ':F' . $rowIndex);
    $sheet->getStyle('A' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $rowIndex++;
}
$rowIndex++; // 空一行

// ==================== 管理员信息 ====================
$sheet->setCellValue('A' . $rowIndex, '管理员信息（后端填写）');
$sheet->mergeCells('A' . $rowIndex . ':D' . $rowIndex);
$sheet->getStyle('A' . $rowIndex)->getFont()->setSize(14)->setBold(true);
$sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFF3E5F5');
$rowIndex++;

$adminInfo = array(
    array('本月订单目标', number_format($config['target_volume']) . ' 单'),
    array('本月消耗预算', '¥' . number_format($config['budget'], 2)),
    array('月度线索任务', number_format($config['task_quantity']) . ' 条')
);

foreach ($adminInfo as $row) {
    $sheet->fromArray($row, NULL, 'A' . $rowIndex);
    $sheet->getStyle('A' . $rowIndex)->getFont()->setBold(true);
    $sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFF0F0F0');
    $sheet->getStyle('A' . $rowIndex . ':B' . $rowIndex)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle('A' . $rowIndex . ':B' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);
    $rowIndex++;
}
$rowIndex++; // 空一行

// ==================== 备注内容 ====================
$sheet->setCellValue('A' . $rowIndex, '备注内容（后端填写）');
$sheet->mergeCells('A' . $rowIndex . ':D' . $rowIndex);
$sheet->getStyle('A' . $rowIndex)->getFont()->setSize(14)->setBold(true);
$sheet->getStyle('A' . $rowIndex)->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('FFE1F5FE');
$rowIndex++;

$remarks = !empty($config['remarks']) ? $config['remarks'] : '暂无备注内容';
$sheet->setCellValue('A' . $rowIndex, $remarks);
$sheet->mergeCells('A' . $rowIndex . ':D' . $rowIndex);
$sheet->getStyle('A' . $rowIndex)->getAlignment()->setWrapText(true);
$sheet->getStyle('A' . $rowIndex)->getAlignment()->setVertical(Alignment::VERTICAL_TOP);
$sheet->getRowDimension($rowIndex)->setRowHeight(50);
$sheet->getStyle('A' . $rowIndex)->getBorders()->getAllBorders()->setBorderStyle(Border::BORDER_THIN);

// 设置列宽
$sheet->getColumnDimension('A')->setWidth(18);
$sheet->getColumnDimension('B')->setWidth(18);
$sheet->getColumnDimension('C')->setWidth(18);
$sheet->getColumnDimension('D')->setWidth(20);
$sheet->getColumnDimension('E')->setWidth(18);
$sheet->getColumnDimension('F')->setWidth(18);
$sheet->getColumnDimension('G')->setWidth(18);

// 创建Writer对象
$writer = new Xlsx($spreadsheet);

// 设置文件名
$filename = '抖音本地通消耗追踪表-' . $config['year'] . '年' . $config['month'] . '月.xlsx';

// 设置HTTP头
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . urlencode($filename) . '"');
header('Cache-Control: max-age=0');

// 输出到浏览器
$writer->save('php://output');
exit;
