<?php
$ad_cost_threshold = 120; // 广告线索成本阈值
$comprehensive_cost_threshold = 100; // 综合线索成本阈值
require_once "./api/fn.php";

// 获取当前年月
$current_year = date('Y');
$current_month = date('n');

// 从GET参数获取选择的月份，如果没有则使用当前月份
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : $current_year;
$selected_month = isset($_GET['month']) ? intval($_GET['month']) : $current_month;

// 获取当月数据
$data = get_current_month_data($selected_year, $selected_month);

if (!$data) {
    echo "<script>alert('" . $selected_year . "年" . $selected_month . "月暂无配置数据！请联系管理员添加。');</script>";
    $data = array(
        'config' => array(
            'year' => $selected_year,
            'month' => $selected_month,
            'budget' => 0,
            'task_quantity' => 0,
            'target_volume' => 0,
            'remarks' => '暂无数据'
        ),
        'details' => array(),
        'nodes' => array(),
        'summary' => array(
            'total_consumption' => 0,
            'total_natural_leads' => 0,
            'total_ad_leads' => 0,
            'total_orders' => 0,
            'total_leads' => 0,
            'remaining_budget' => 0,
            'budget_usage_rate' => 0,
            'leads_diff' => 0,
            'leads_completion_rate' => 0,
            'order_completion_rate' => 0,
            'cost_per_lead' => 0
        )
    );
}

$config = $data['config'];
$details = $data['details'];
$nodes = $data['nodes'];
$summary = $data['summary'];
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>中国星-新媒体数据进度追踪表</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="./js/xlsx.full.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif;
        }
        
        body {
            background-color: #f8fafc;
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        
        header {
            margin-bottom: 30px;
            padding: 20px;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            border-radius: 12px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
        }
        
        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 15px;
        }
        
        h1 {
            font-size: 28px;
            font-weight: 600;
        }
        
        .description {
            font-size: 16px;
            opacity: 0.9;
            max-width: 800px;
        }
        
        .controls {
            display: flex;
            align-items: center;
            gap: 10px;
            background: rgba(255, 255, 255, 0.15);
            padding: 8px 15px;
            border-radius: 8px;
            flex-wrap: wrap;
        }
        
        .controls label {
            font-weight: 500;
        }
        
        .controls select, .controls input {
            padding: 6px 12px;
            border-radius: 6px;
            border: none;
            background-color: white;
            color: #333;
            font-size: 14px;
        }
        
        .btn-query {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.3s;
        }
        
        .btn-query:hover {
            background-color: #3d8b40;
        }
        
        .btn-action {
            background-color: #2196F3;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.3s;
            font-size: 14px;
        }
        
        .btn-action:hover {
            background-color: #0b7dda;
        }
        
        .btn-danger {
            background-color: #f44336;
        }
        
        .btn-danger:hover {
            background-color: #d32f2f;
        }
        
        .btn-success {
            background-color: #10b981;
        }
        
        .btn-success:hover {
            background-color: #0da271;
        }
        
        .metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .metric-card {
            background-color: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .metric-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }
        
        .metric-title {
            font-size: 16px;
            color: #666;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .metric-value {
            font-size: 28px;
            font-weight: 700;
            color: #1e3c72;
            margin-bottom: 8px;
        }
        
        .metric-details {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        
        .detail-item {
            text-align: center;
            flex: 1;
        }
        
        .detail-label {
            font-size: 13px;
            color: #888;
            margin-bottom: 4px;
        }
        
        .detail-value {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        
        .progress-container {
            margin-top: 15px;
        }
        
        .progress-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 5px;
            font-size: 14px;
        }
        
        .progress-bar {
            height: 10px;
            background-color: #e9ecef;
            border-radius: 5px;
            overflow: hidden;
        }
        
        .progress-fill {
            height: 100%;
            background-color: #4CAF50;
            border-radius: 5px;
        }
        
        .table-container {
            background-color: white;
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
            overflow-x: auto;
        }
        
        h2 {
            font-size: 22px;
            margin-bottom: 20px;
            color: #1e3c72;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th {
            background-color: #f1f5f9;
            padding: 15px 12px;
            text-align: left;
            font-weight: 600;
            color: #475569;
            border-bottom: 2px solid #e2e8f0;
        }
        
        td {
            padding: 12px;
            border-bottom: 1px solid #e2e8f0;
        }
        
        tr:hover {
            background-color: #f8fafc;
        }
        
        .numeric {
            text-align: right;
            font-family: 'Courier New', monospace;
        }
        
        .calculation-formula {
            font-size: 12px;
            color: #888;
            font-style: italic;
            margin-top: 5px;
        }
        
        .summary-row {
            background-color: #f0f9ff;
            font-weight: 600;
        }
        
        .verification-table {
            margin-top: 30px;
        }
        
        footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
            color: #64748b;
            font-size: 14px;
        }
        
        @media (max-width: 768px) {
            .metrics-grid {
                grid-template-columns: 1fr;
            }
            
            .header-top {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .controls {
                width: 100%;
                justify-content: space-between;
            }
            
            h1 {
                font-size: 24px;
            }
        }
        
        .icon {
            width: 24px;
            height: 24px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            background-color: #e8f4ff;
            color: #2196F3;
        }
        
        .metric-icon {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        
        .budget-icon {
            background-color: #e8f5e9;
            color: #4CAF50;
        }
        
        .clue-icon {
            background-color: #fff3e0;
            color: #FF9800;
        }
        
        .order-icon {
            background-color: #f3e5f5;
            color: #9C27B0;
        }
        
        .cost-icon {
            background-color: #ffebee;
            color: #f44336;
        }
        
        .highlight {
            color: #e91e63;
            font-weight: 700;
        }
        
        .warning {
            color: #ff9800;
            font-weight: 700;
        }
        
        .success {
            color: #4CAF50;
            font-weight: 700;
        }
        
        .danger {
            color: #f44336;
            font-weight: 700;
        }
        
        .status-message {
            padding: 12px 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            text-align: center;
            display: none;
        }
        
        .status-message.success {
            background-color: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
            display: block;
        }
        
        .status-message.error {
            background-color: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
            display: block;
        }
        
        .remarks-section {
            background-color: #f0f9ff;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            border-left: 4px solid #3b82f6;
        }
        
        .remarks-section h3 {
            margin-bottom: 15px;
            color: #3b82f6;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        #remarksContent {
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            line-height: 1.5;
            background-color: #fff;
            min-height: 40px;
        }
        
        input[type="text"],
        input[type="number"],
        input[type="date"],
        input[type="password"] {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        input[type="text"]:focus,
        input[type="number"]:focus,
        input[type="date"]:focus,
        input[type="password"]:focus {
            outline: none;
            border-color: #4a6cf7;
            box-shadow: 0 0 0 2px rgba(74, 108, 247, 0.2);
        }
        
        .no-border {
            border: none;
            background: transparent;
            width: 100%;
            text-align: center;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            justify-content: flex-end;
        }
        
        .button-group {
            display: flex;
            gap: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <div class="header-top">
                <h1>中国星<?= $config['year'] ?>年<?= $config['month'] ?>月新媒体数据进度追踪表</h1>
                <div class="controls">
                    <form id="monthForm" method="get" style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                        <label for="yearSelect">选择月份：</label>
                        <select id="yearSelect" name="year">
                            <?php
                            // 生成年份选项，最近5年
                            for ($y = $current_year; $y >= $current_year - 4; $y--) {
                                $selected = ($y == $selected_year) ? 'selected' : '';
                                echo "<option value='$y' $selected>$y 年</option>";
                            }
                            ?>
                        </select>
                        <select id="monthSelect" name="month">
                            <?php
                            // 生成月份选项
                            for ($m = 1; $m <= 12; $m++) {
                                $selected = ($m == $selected_month) ? 'selected' : '';
                                echo "<option value='$m' $selected>$m 月</option>";
                            }
                            ?>
                        </select>
                        <button type="submit" class="btn-query">查询</button>
                    </form>
                </div>
            </div>
            <p class="description">本表格用于追踪抖音本地通账户的每日消耗进度、预算使用情况、线索获取数据及核销节点管理。</p>
        </header>
        
        <div class="action-buttons">
            <div class="button-group">
                <button class="btn-action btn-danger" type="button" onclick="window.location.href='./temp/xiaohui.php'">
                    <i class="fas fa-edit"></i> 数据填报
                </button>
            </div>
        </div>
        
        <div id="statusMessage" class="status-message"></div>
        
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-icon budget-icon">
                    <i class="fas fa-wallet fa-lg"></i>
                </div>
                <div class="metric-title">
                    <i class="fas fa-chart-line"></i>
                    预算情况
                </div>
                <div class="metric-value">¥<?= number_format($config['budget'], 2) ?></div>
                <div class="progress-container">
                    <div class="progress-label">
                        <span>已消耗: <span id="budget-used">¥<?= number_format($summary['total_consumption'], 2) ?></span></span>
                        <span>使用率: <span class="<?= $summary['budget_usage_rate'] > 100 ? 'danger' : ($summary['budget_usage_rate'] > 80 ? 'warning' : 'success') ?>">
                            <?= number_format($summary['budget_usage_rate'], 2) ?>%
                        </span></span>
                    </div>
                    <div class="progress-bar">
                        <?php
                        $budget_progress = min($summary['budget_usage_rate'], 100);
                        ?>
                        <div class="progress-fill" id="budget-progress" style="width: <?= $budget_progress ?>%"></div>
                    </div>
                </div>
                <div class="metric-details">
                    <div class="detail-item">
                        <div class="detail-label">剩余预算</div>
                        <div class="detail-value <?= $summary['remaining_budget'] > 0 ? 'success' : 'danger' ?>">
                            ¥<?= number_format($summary['remaining_budget'], 2) ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="metric-card">
                <div class="metric-icon clue-icon">
                    <i class="fas fa-bullseye fa-lg"></i>
                </div>
                <div class="metric-title">
                    <i class="fas fa-tasks"></i>
                    本月线索情况
                </div>
                <div class="metric-value"><?= number_format($summary['total_leads']) ?>条</div>
                <div class="progress-container">
                    <div class="progress-label">
                        <span>线索任务: <span id="clue-task"><?= number_format($config['task_quantity']) ?>条</span></span>
                        <span>完成率: <span class="<?= $summary['leads_completion_rate'] >= 100 ? 'success' : 'danger' ?>">
                            <?= number_format($summary['leads_completion_rate'], 2) ?>%
                        </span></span>
                    </div>
                    <div class="progress-bar">
                        <?php
                        $clue_progress = min($summary['leads_completion_rate'], 100);
                        ?>
                        <div class="progress-fill" id="clue-progress" style="width: <?= $clue_progress ?>%"></div>
                    </div>
                </div>
                <div class="metric-details">
                    <div class="detail-item">
                        <div class="detail-label">线索差额</div>
                        <div class="detail-value <?= $summary['leads_diff'] <= 0 ? 'success' : 'danger' ?>">
                            <?php if ($summary['leads_diff'] > 0): ?>
                                差<?= number_format($summary['leads_diff']) ?>条
                            <?php elseif ($summary['leads_diff'] < 0): ?>
                                超<?= number_format(abs($summary['leads_diff'])) ?>条
                            <?php else: ?>
                                刚好完成
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="metric-card">
                <div class="metric-icon order-icon">
                    <i class="fas fa-shopping-cart fa-lg"></i>
                </div>
                <div class="metric-title">
                    <i class="fas fa-chart-bar"></i>
                    本月订单情况
                </div>
                <div class="metric-value"><?= number_format($summary['total_orders']) ?>台</div>
                <div class="progress-container">
                    <div class="progress-label">
                        <span>订单任务: <span id="order-task"><?= number_format($config['target_volume']) ?>台</span></span>
                        <span>完成率: <span class="<?= $summary['order_completion_rate'] >= 100 ? 'success' : 'danger' ?>">
                            <?= number_format($summary['order_completion_rate'], 2) ?>%
                        </span></span>
                    </div>
                    <div class="progress-bar">
                        <?php
                        $order_progress = min($summary['order_completion_rate'], 100);
                        ?>
                        <div class="progress-fill" id="order-progress" style="width: <?= $order_progress ?>%"></div>
                    </div>
                </div>
                <div class="metric-details">
                    <div class="detail-item">
                        <div class="detail-label">订单成本</div>
                        <div class="detail-value">
                            ¥<?= number_format($summary['cost_per_order'], 2) ?>/单
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="metric-card">
                <div class="metric-icon cost-icon">
                    <i class="fas fa-calculator fa-lg"></i>
                </div>
                <div class="metric-title">
                    <i class="fas fa-money-bill-wave"></i>
                    线索成本情况
                </div>
                <div class="metric-value <?= $summary['cost_per_lead'] <= $comprehensive_cost_threshold ? 'success' : 'danger' ?>">
                    ¥<?= number_format($summary['cost_per_lead'], 2) ?>/条
                </div>
                <div class="metric-details">
                    <div class="detail-item">
                        <div class="detail-label">广告线索成本</div>
                        <div class="detail-value <?= $summary['ad_leads_cost'] <= $ad_cost_threshold ? 'success' : 'danger' ?>">
                            ¥<?= number_format($summary['ad_leads_cost'], 2) ?>
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">广告线索</div>
                        <div class="detail-value">
                            <?= number_format($summary['total_ad_leads']) ?>条
                        </div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">自然线索</div>
                        <div class="detail-value">
                            <?= number_format($summary['total_natural_leads']) ?>条
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="table-container">
            <h2><i class="fas fa-file-invoice-dollar"></i> 核销节点追踪</h2>
            <table class="verification-table">
                <thead>
                    <tr>
                        <th>核销节点</th>
                        <th>核销日期</th>
                        <th>核销金额 (元)</th>
                        <th>统计日期范围</th>
                        <th>已消耗金额 (元)</th>
                        <th>消耗差额 (元)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($nodes) > 0): ?>
                        <?php foreach ($nodes as $index => $node): ?>
                            <tr>
                                <td>节点 <?= $index + 1 ?></td>
                                <td><?= date('Y-m-d', strtotime($node['write_off_date'])) ?></td>
                                <td class="numeric">¥<?= number_format($node['amount'], 2) ?></td>
                                <td><?= $node['start_date'] ?>日 - <?= $node['end_date'] ?>日</td>
                                <td class="numeric">¥<?= number_format($node['consumed_amount'], 2) ?></td>
                                <td class="numeric <?= $node['consumption_diff'] >= 0 ? 'success' : 'danger' ?>">
                                    ¥<?= number_format($node['consumption_diff'], 2) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" style="text-align: center; color: #999;">暂无核销节点数据</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="table-container">
            <h2><i class="fas fa-calendar-day"></i> 每日消耗与线索明细</h2>
            <form id="dailyForm" method="post" action="./temp/save_daily.php">
                <table id="dailyTable">
                    <thead>
                        <tr>
                            <th>日期</th>
                            <th>自然线索</th>
                            <th>广告线索</th>
                            <th>当日消耗 (元)</th>
                            <th>订单数</th>
                            <th>当日总线索</th>
                            <th>线索成本 (元)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($details as $detail):
                            $day_total_leads = intval($detail['natural_leads']) + intval($detail['ad_leads']);
                            $day_cost = $day_total_leads > 0 ? floatval($detail['daily_consumption']) / $day_total_leads : 0;
                            ?>
                            <tr>
                                <td><strong><?= $config['month'] ?>月<?= $detail['day_of_month'] ?>日</strong></td>
                                <td>
                                    <input type="hidden" name="details[<?= $detail['id'] ?>][id]"
                                        value="<?= $detail['id'] ?>">
                                    <input type="number" name="details[<?= $detail['id'] ?>][natural_leads]"
                                        value="<?= $detail['natural_leads'] ?>" readonly class="no-border"
                                        onchange="calculateRow(this)">
                                </td>
                                <td>
                                    <input type="number" name="details[<?= $detail['id'] ?>][ad_leads]"
                                        value="<?= $detail['ad_leads'] ?>" readonly class="no-border"
                                        onchange="calculateRow(this)">
                                </td>
                                <td>
                                    <input type="number" name="details[<?= $detail['id'] ?>][daily_consumption]"
                                        value="<?= $detail['daily_consumption'] ?>" step="0.01" readonly class="no-border"
                                        onchange="calculateRow(this)">
                                </td>
                                <td>
                                    <input type="number" name="details[<?= $detail['id'] ?>][order_quantity]"
                                        value="<?= $detail['order_quantity'] ?>" readonly class="no-border">
                                </td>
                                <td class="numeric"><?= number_format($day_total_leads) ?></td>
                                <td class="numeric">¥<?= number_format($day_cost, 2) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </form>
        </div>

        <div class="table-container">
            <div class="remarks-section">
                <h3><i class="fas fa-sticky-note"></i> 备注内容</h3>
                <div id="remarksContent">
                    <?= !empty($config['remarks']) ? nl2br(htmlspecialchars($config['remarks'])) : '暂无备注内容' ?>
                </div>
            </div>
        </div>

        <footer>
            <p>抖音本地通消耗进度追踪系统 &copy; 2025 | 版本：1.0</p>
            <p>注：所有数据均为实时数据，数据更新时间: <span id="update-time"><?= date('Y-m-d H:i') ?></span></p>
        </footer>
    </div>

    <script>
        // 添加简单的表单提交提示
        document.getElementById('monthForm').addEventListener('submit', function(e) {
            // 显示加载提示
            document.getElementById('statusMessage').innerHTML = '正在加载' + 
                document.getElementById('yearSelect').value + '年' + 
                document.getElementById('monthSelect').value + '月数据...';
            document.getElementById('statusMessage').className = 'status-message success';
            document.getElementById('statusMessage').style.display = 'block';
        });

        // 下载Excel
        function downloadExcel() {
            // 修改下载链接，带上当前选择的月份参数
            var year = document.getElementById('yearSelect').value;
            var month = document.getElementById('monthSelect').value;
            window.location.href = './temp/excel.php?year=' + year + '&month=' + month;
        }
        
        // 设置页面更新时间
        document.addEventListener('DOMContentLoaded', function() {
            const now = new Date();
            const formattedDate = now.getFullYear() + '-' + 
                String(now.getMonth() + 1).padStart(2, '0') + '-' + 
                String(now.getDate()).padStart(2, '0') + ' ' +
                String(now.getHours()).padStart(2, '0') + ':' +
                String(now.getMinutes()).padStart(2, '0');
            document.getElementById('update-time').textContent = formattedDate;
            
            // 添加一些交互效果
            const metricCards = document.querySelectorAll('.metric-card');
            metricCards.forEach(card => {
                card.addEventListener('click', function() {
                    this.style.transform = 'scale(1.02)';
                    setTimeout(() => {
                        this.style.transform = '';
                    }, 200);
                });
            });
        });
    </script>
</body>
</html>