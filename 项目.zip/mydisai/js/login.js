document.querySelector('#Register form').addEventListener('submit', function(event) {  
    // 获取表单中的元素  
    var username = document.querySelector('#Register input[name="username"]');  
    var email = document.querySelector('#Register input[name="email"]');  
    var password = document.querySelector('#Register input[name="password"]');  
    var confirmPassword = document.querySelector('#Register input[name="passwords"]');  
  
    // 用户名验证：两位数到8位  
    if (username.value.length < 2 || username.value.length > 8) {  
        alert('用户名必须为2到8位');  
        event.preventDefault(); // 阻止表单提交  
        return;  
    }  
  
    // 邮箱验证（这里只是一个简单的示例，通常使用正则表达式或邮箱验证库）  
    if (!email.checkValidity()) {  
        alert('请输入有效的邮箱地址');  
        event.preventDefault(); // 阻止表单提交  
        return;  
    }  
  
    // 密码验证：包含数字、大写字母、小写字母，8到12位  
    var passwordRegex = /^(?:(?=.*\d)(?=.*[a-zA-Z])|(?=.*[a-z])(?=.*[A-Z])).{6,20}$/;

    if (!passwordRegex.test(password.value)) {  
        alert('密码必须包含数字、字母其中两种，可以包含特殊字符，长度为6到20位');

        event.preventDefault(); // 阻止表单提交  
        return;  
    }  
  
    // 确认密码验证：与密码一致  
    if (password.value !== confirmPassword.value) {  
        alert('两次输入的密码不一致');  
        event.preventDefault(); // 阻止表单提交  
        return;  
    }  
});


function openForm(evt, formName) {
    var i, tabcontent, tablinks;

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // 清除所有按钮的激活状态
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].classList.remove('active', 'active-animate', 'actives');
    }

    // Show the current tab
    document.getElementById(formName).style.display = "block";
    
    // 获取被点击的按钮
    var btn = evt.currentTarget;

    // 添加激活状态，并启动动画
    btn.classList.add('active'); // 激活按钮样式
    btn.classList.add('actives'); // 激活按钮文字颜色
    setTimeout(function() {
        btn.classList.add('active-animate'); // 添加动画类，等待边框颜色过渡完成后再开始动画
    }, 10); // 稍微延迟启动动画

}

// Ensure the login tab is opened by default when the page loads
document.addEventListener("DOMContentLoaded", function() {
    document.getElementById('r').click();
});


