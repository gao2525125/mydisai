<?php
// PHP代码必须放在最前面，不能有任何输出
require_once "./api/fn.php";
session();

// 获取用户列表
$users = get_user_list();

// 获取搜索关键词
$searchKeyword = isset($_GET['search']) ? trim($_GET['search']) : '';

// 如果有搜索关键词，进行过滤
if (!empty($searchKeyword)) {
    $users = array_filter($users, function($user) use ($searchKeyword) {
        return stripos($user['name'], $searchKeyword) !== false;
    });
}

// 分页
$totalItems = count($users);
$perPage = 15;
$totalPages = ceil($totalItems / $perPage);
$currentPage = isset($_GET['page']) && is_numeric($_GET['page']) ? (int) $_GET['page'] : 1;
$currentPage = max(1, min($currentPage, max($totalPages, 1)));
$startIndex = ($currentPage - 1) * $perPage;
$currentPageItems = array_slice($users, $startIndex, $perPage);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>用户管理 · 抖音本地通消耗追踪</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <style>
    /* ====== DeepSeek风格CSS变量与重置 ====== */
    :root {
      /* DeepSeek主色调 */
      --primary-color: #10a37f;
      --primary-dark: #0d8c6d;
      --primary-light: #e6f7f2;
      
      /* 中性色调 */
      --gray-900: #1a1a1a;
      --gray-800: #2d2d2d;
      --gray-700: #404040;
      --gray-600: #666666;
      --gray-500: #8c8c8c;
      --gray-400: #b3b3b3;
      --gray-300: #d9d9d9;
      --gray-200: #e6e6e6;
      --gray-100: #f5f5f5;
      --gray-50: #fafafa;
      
      /* 功能色 */
      --success-color: #10a37f;
      --warning-color: #ff9800;
      --error-color: #f44336;
      --info-color: #2196f3;
      
      /* 排版 */
      --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      --font-family-mono: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Courier, monospace;
      
      /* 间距 */
      --spacing-xs: 4px;
      --spacing-sm: 8px;
      --spacing-md: 16px;
      --spacing-lg: 24px;
      --spacing-xl: 32px;
      --spacing-xxl: 48px;
      
      /* 圆角 */
      --radius-sm: 4px;
      --radius-md: 8px;
      --radius-lg: 12px;
      --radius-xl: 16px;
      --radius-full: 9999px;
      
      /* 阴影 */
      --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.05);
      --shadow-md: 0 4px 16px rgba(0, 0, 0, 0.1);
      --shadow-lg: 0 8px 32px rgba(0, 0, 0, 0.12);
      
      /* 过渡 */
      --transition-fast: 150ms ease;
      --transition-normal: 250ms ease;
      --transition-slow: 350ms ease;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: var(--font-family);
      color: var(--gray-900);
      background-color: var(--gray-50);
      line-height: 1.6;
      font-size: 16px;
      padding: var(--spacing-md);
    }
    
    /* ====== 卡片样式 ====== */
    .card {
      background-color: white;
      border-radius: var(--radius-lg);
      border: 1px solid var(--gray-200);
      box-shadow: var(--shadow-sm);
      overflow: hidden;
      transition: box-shadow var(--transition-normal), transform var(--transition-normal);
      margin-bottom: var(--spacing-lg);
    }
    
    .card:hover {
      box-shadow: var(--shadow-md);
    }
    
    .card-header {
      padding: var(--spacing-lg);
      border-bottom: 1px solid var(--gray-200);
      background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      color: white;
    }
    
    .card-body {
      padding: var(--spacing-lg);
    }
    
    .card-footer {
      padding: var(--spacing-lg);
      border-top: 1px solid var(--gray-200);
      background-color: var(--gray-50);
    }
    
    /* ====== 标题和文本 ====== */
    .page-title {
      font-size: 1.75rem;
      font-weight: 600;
      margin-bottom: var(--spacing-xs);
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
    }
    
    .page-subtitle {
      font-size: 0.875rem;
      color: rgba(255, 255, 255, 0.9);
      font-weight: 400;
    }
    
    .text-muted {
      color: var(--gray-600);
    }
    
    .text-center {
      text-align: center;
    }
    
    /* ====== 按钮样式 ====== */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      font-weight: 500;
      line-height: 1.5;
      border-radius: var(--radius-md);
      border: 1px solid transparent;
      cursor: pointer;
      transition: all var(--transition-fast);
      text-decoration: none;
      gap: var(--spacing-sm);
    }
    
    .btn-primary {
      background-color: var(--primary-color);
      color: white;
    }
    
    .btn-primary:hover {
      background-color: var(--primary-dark);
      color: white;
      text-decoration: none;
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .btn-success {
      background-color: var(--success-color);
      color: white;
    }
    
    .btn-success:hover {
      background-color: #0d8c6d;
      color: white;
      text-decoration: none;
      transform: translateY(-2px);
      box-shadow: var(--shadow-md);
    }
    
    .btn-outline {
      background-color: transparent;
      color: var(--primary-color);
      border-color: var(--gray-300);
    }
    
    .btn-outline:hover {
      background-color: var(--primary-light);
      color: var(--primary-dark);
      text-decoration: none;
      border-color: var(--primary-color);
      transform: translateY(-2px);
    }
    
    .btn-sm {
      padding: var(--spacing-xs) var(--spacing-md);
      font-size: 0.8125rem;
    }
    
    /* ====== 表单样式 ====== */
    .form-control {
      display: block;
      width: 100%;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      line-height: 1.5;
      color: var(--gray-900);
      background-color: white;
      border: 1px solid var(--gray-300);
      border-radius: var(--radius-md);
      transition: border-color var(--transition-fast), box-shadow var(--transition-fast);
    }
    
    .form-control:focus {
      outline: none;
      border-color: var(--primary-color);
      box-shadow: 0 0 0 3px rgba(16, 163, 127, 0.1);
    }
    
    .form-control::placeholder {
      color: var(--gray-500);
    }
    
    /* ====== 表格样式 ====== */
    .table-wrapper {
      overflow-x: auto;
      border-radius: var(--radius-md);
      border: 1px solid var(--gray-200);
    }
    
    .data-table {
      width: 100%;
      border-collapse: collapse;
      background: white;
      font-size: 0.875rem;
    }
    
    .data-table thead {
      background-color: var(--gray-50);
    }
    
    .data-table th {
      padding: var(--spacing-md);
      text-align: left;
      font-weight: 600;
      color: var(--gray-700);
      border-bottom: 2px solid var(--gray-200);
      white-space: nowrap;
    }
    
    .data-table td {
      padding: var(--spacing-md);
      border-bottom: 1px solid var(--gray-200);
      color: var(--gray-800);
    }
    
    .data-table tbody tr {
      transition: background-color var(--transition-fast);
    }
    
    .data-table tbody tr:hover {
      background-color: var(--gray-50);
    }
    
    /* 表格特殊样式 */
    .text-left {
      text-align: left;
    }
    
    .text-center {
      text-align: center;
    }
    
    .username-cell {
      font-weight: 600;
      color: var(--primary-dark);
    }
    
    .password-cell {
      font-family: var(--font-family-mono);
    }
    
    /* ====== 操作按钮 ====== */
    .action-buttons {
      display: flex;
      gap: var(--spacing-sm);
      justify-content: center;
    }
    
    .action-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-xs) var(--spacing-sm);
      font-size: 0.75rem;
      font-weight: 500;
      border-radius: var(--radius-sm);
      border: none;
      cursor: pointer;
      transition: all var(--transition-fast);
      text-decoration: none;
      gap: var(--spacing-xs);
    }
    
    .action-btn-edit {
      background-color: var(--info-color);
      color: white;
    }
    
    .action-btn-edit:hover {
      background-color: #1976d2;
      color: white;
      text-decoration: none;
      transform: translateY(-1px);
      box-shadow: var(--shadow-sm);
    }
    
    .action-btn-delete {
      background-color: var(--error-color);
      color: white;
    }
    
    .action-btn-delete:hover {
      background-color: #d32f2f;
      color: white;
      text-decoration: none;
      transform: translateY(-1px);
      box-shadow: var(--shadow-sm);
    }
    
    /* ====== 分页样式 ====== */
    .pagination {
      display: flex;
      justify-content: center;
      align-items: center;
      gap: var(--spacing-xs);
      list-style: none;
      padding: 0;
      margin: 0;
    }
    
    .pagination-item {
      display: inline-block;
    }
    
    .pagination-link {
      display: flex;
      align-items: center;
      justify-content: center;
      min-width: 36px;
      height: 36px;
      padding: 0 var(--spacing-sm);
      background: white;
      border: 1px solid var(--gray-300);
      border-radius: var(--radius-md);
      color: var(--gray-700);
      text-decoration: none;
      font-weight: 500;
      font-size: 0.875rem;
      transition: all var(--transition-fast);
    }
    
    .pagination-link:hover {
      border-color: var(--primary-color);
      color: var(--primary-color);
      background-color: var(--primary-light);
    }
    
    .pagination-link.active {
      background-color: var(--primary-color);
      border-color: var(--primary-color);
      color: white;
    }
    
    .pagination-link.active:hover {
      background-color: var(--primary-dark);
      color: white;
    }
    
    /* ====== 搜索栏样式 ====== */
    .search-form {
      position: relative;
      flex: 1;
      min-width: 300px;
    }
    
    .search-icon {
      position: absolute;
      left: var(--spacing-md);
      top: 50%;
      transform: translateY(-50%);
      color: var(--gray-500);
      font-size: 1.2rem;
      pointer-events: none;
    }
    
    .search-input {
      padding-left: calc(var(--spacing-md) * 2 + 20px) !important;
    }
    
    /* ====== 密码显示样式 ====== */
    .password-display {
      background-color: var(--gray-100);
      padding: var(--spacing-xs) var(--spacing-sm);
      border-radius: var(--radius-sm);
      font-family: var(--font-family-mono);
      font-size: 0.875rem;
      color: var(--gray-700);
      border: 1px solid var(--gray-200);
      display: inline-block;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    /* ====== 空状态样式 ====== */
    .empty-state {
      padding: var(--spacing-xxl) var(--spacing-lg);
      text-align: center;
      color: var(--gray-500);
    }
    
    .empty-state-icon {
      font-size: 4rem;
      color: var(--gray-300);
      margin-bottom: var(--spacing-lg);
      opacity: 0.5;
    }
    
    .empty-state-text {
      font-size: 1.1rem;
      color: var(--gray-600);
    }
    
    /* ====== 工具类 ====== */
    .d-flex {
      display: flex;
    }
    
    .align-center {
      align-items: center;
    }
    
    .justify-between {
      justify-content: space-between;
    }
    
    .gap-sm {
      gap: var(--spacing-sm);
    }
    
    .gap-md {
      gap: var(--spacing-md);
    }
    
    .gap-lg {
      gap: var(--spacing-lg);
    }
    
    .flex-wrap {
      flex-wrap: wrap;
    }
    
    .mb-sm {
      margin-bottom: var(--spacing-sm);
    }
    
    .mb-md {
      margin-bottom: var(--spacing-md);
    }
    
    .mb-lg {
      margin-bottom: var(--spacing-lg);
    }
    
    /* ====== 动画效果 ====== */
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    .fade-in {
      animation: fadeIn 0.5s ease forwards;
    }
    
    /* ====== 响应式设计 ====== */
    @media (max-width: 768px) {
      body {
        padding: var(--spacing-sm);
      }
      
      .card-header,
      .card-body,
      .card-footer {
        padding: var(--spacing-md);
      }
      
      .data-table th,
      .data-table td {
        padding: var(--spacing-sm);
        font-size: 0.8125rem;
      }
      
      .search-form {
        min-width: 100%;
      }
      
      .btn span:last-child:not(.material-icons) {
        display: none;
      }
      
      .btn .material-icons {
        margin-right: 0;
      }
      
      .action-btn span:last-child:not(.material-icons) {
        display: none;
      }
      
      .action-btn .material-icons {
        margin-right: 0;
      }
    }
    
    @media (max-width: 576px) {
      .data-table {
        font-size: 0.75rem;
      }
      
      .data-table th,
      .data-table td {
        padding: var(--spacing-xs) var(--spacing-sm);
      }
      
      .pagination-link {
        min-width: 32px;
        height: 32px;
        font-size: 0.8125rem;
      }
    }
    
    /* ====== 深色模式支持 ====== */
    @media (prefers-color-scheme: dark) {
      :root {
        --gray-900: #f5f5f5;
        --gray-800: #e6e6e6;
        --gray-700: #d9d9d9;
        --gray-600: #b3b3b3;
        --gray-500: #8c8c8c;
        --gray-400: #666666;
        --gray-300: #404040;
        --gray-200: #2d2d2d;
        --gray-100: #1a1a1a;
        --gray-50: #111111;
        
        --primary-light: rgba(16, 163, 127, 0.2);
      }
      
      body {
        background-color: var(--gray-50);
        color: var(--gray-900);
      }
      
      .card {
        background-color: var(--gray-100);
        border-color: var(--gray-300);
      }
      
      .card-header {
        background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
      }
      
      .card-footer {
        background-color: var(--gray-200);
      }
      
      .form-control {
        background-color: var(--gray-200);
        border-color: var(--gray-400);
        color: var(--gray-900);
      }
      
      .table-wrapper {
        border-color: var(--gray-300);
      }
      
      .data-table {
        background: var(--gray-100);
      }
      
      .data-table thead {
        background-color: var(--gray-200);
      }
      
      .data-table th {
        border-color: var(--gray-300);
      }
      
      .data-table td {
        border-color: var(--gray-300);
      }
      
      .data-table tbody tr:hover {
        background-color: var(--gray-200);
      }
      
      .password-display {
        background-color: var(--gray-200);
        border-color: var(--gray-400);
        color: var(--gray-700);
      }
      
      .pagination-link {
        background: var(--gray-200);
        border-color: var(--gray-400);
        color: var(--gray-700);
      }
      
      .pagination-link:hover {
        background-color: var(--gray-300);
      }
      
      .empty-state-icon {
        color: var(--gray-400);
      }
    }
  </style>
</head>
<body>
  <!-- 页面标题卡片 -->
  <div class="card fade-in">
    <div class="card-header">
      <div class="d-flex justify-between align-center flex-wrap gap-md">
        <div>
          <h1 class="page-title">
            <span class="material-icons">people</span>
            用户管理
          </h1>
          <p class="page-subtitle">
            <?php if (!empty($searchKeyword)): ?>
              搜索 "<?= htmlspecialchars($searchKeyword) ?>" 找到 <?= $totalItems ?> 个用户
            <?php else: ?>
              共 <?= $totalItems ?> 个用户
            <?php endif; ?>
          </p>
        </div>
      </div>
    </div>
  </div>

  <!-- 搜索和操作栏 -->
  <div class="card fade-in" style="animation-delay: 0.1s;">
    <div class="card-body">
      <div class="d-flex align-center flex-wrap gap-lg">
        <!-- 搜索框 -->
        <form method="GET" class="d-flex align-center flex-wrap gap-md" style="flex: 1; min-width: 300px;">
          <div class="search-form">
            <span class="material-icons search-icon">search</span>
            <input 
              type="text" 
              name="search" 
              class="form-control search-input" 
              placeholder="搜索用户名..." 
              value="<?= htmlspecialchars($searchKeyword) ?>">
          </div>
          <button type="submit" class="btn btn-primary">
            <span class="material-icons" style="font-size: 1rem;">search</span>
            搜索
          </button>
          <?php if (!empty($searchKeyword)): ?>
            <a href="user_list.php" class="btn btn-outline">
              <span class="material-icons" style="font-size: 1rem;">clear</span>
              清除
            </a>
          <?php endif; ?>
        </form>
        
        <!-- 添加按钮 -->
        <a href="add_user.php" class="btn btn-success">
          <span class="material-icons" style="font-size: 1rem;">person_add</span>
          添加用户
        </a>
      </div>
    </div>
  </div>

  <!-- 用户列表表格卡片 -->
  <div class="card fade-in" style="animation-delay: 0.2s;">
    <div class="card-body" style="padding: 0;">
      <div class="table-wrapper">
        <table class="data-table">
          <thead>
            <tr>
              <th class="text-left">用户名</th>
              <th class="text-left">密码</th>
              <th class="text-center">操作</th>
            </tr>
          </thead>
          <tbody>
            <?php if (count($currentPageItems) > 0): ?>
              <?php foreach ($currentPageItems as $key => $user): ?>
                <tr class="fade-in" style="animation-delay: <?= ($key * 0.03) ?>s;">
                  <td class="username-cell">
                    <?= htmlspecialchars($user['name']) ?>
                  </td>
                  <td>
                    <span class="password-display">
                      <?= htmlspecialchars($user['password']) ?>
                    </span>
                  </td>
                  <td>
                    <div class="action-buttons">
                      <a href="edit_user.php?id=<?= $user['id'] ?>" class="action-btn action-btn-edit" title="编辑">
                        <span class="material-icons" style="font-size: 0.9rem;">edit</span>
                        <span>编辑</span>
                      </a>
                      <a href="javascript:void(0);" onclick="deleteUser(<?= $user['id'] ?>, '<?= htmlspecialchars(addslashes($user['name'])) ?>')" class="action-btn action-btn-delete" title="删除">
                        <span class="material-icons" style="font-size: 0.9rem;">delete</span>
                        <span>删除</span>
                      </a>
                    </div>
                  </td>
                </tr>
              <?php endforeach; ?>
            <?php else: ?>
              <tr>
                <td colspan="3">
                  <div class="empty-state">
                    <div class="material-icons empty-state-icon">people_outline</div>
                    <p class="empty-state-text">
                      <?php if (!empty($searchKeyword)): ?>
                        未找到匹配 "<?= htmlspecialchars($searchKeyword) ?>" 的用户
                      <?php else: ?>
                        暂无用户数据，点击上方"添加用户"按钮开始添加
                      <?php endif; ?>
                    </p>
                  </div>
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- 分页 -->
    <?php if ($totalPages > 1): ?>
      <div class="card-footer">
        <ul class="pagination">
          <?php 
          $searchParam = !empty($searchKeyword) ? '&search=' . urlencode($searchKeyword) : '';
          ?>
          
          <?php if ($currentPage > 1): ?>
            <li class="pagination-item">
              <a href="?page=<?= $currentPage - 1 ?><?= $searchParam ?>" class="pagination-link" title="上一页">
                <span class="material-icons" style="font-size: 1.2rem;">chevron_left</span>
              </a>
            </li>
          <?php endif; ?>

          <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <?php if ($i == 1 || $i == $totalPages || abs($i - $currentPage) <= 2): ?>
              <li class="pagination-item">
                <a href="?page=<?= $i ?><?= $searchParam ?>" class="pagination-link <?= $i == $currentPage ? 'active' : '' ?>">
                  <?= $i ?>
                </a>
              </li>
            <?php elseif (abs($i - $currentPage) == 3): ?>
              <li class="pagination-item">
                <span class="pagination-link" style="border: none; cursor: default; background: transparent;">...</span>
              </li>
            <?php endif; ?>
          <?php endfor; ?>

          <?php if ($currentPage < $totalPages): ?>
            <li class="pagination-item">
              <a href="?page=<?= $currentPage + 1 ?><?= $searchParam ?>" class="pagination-link" title="下一页">
                <span class="material-icons" style="font-size: 1.2rem;">chevron_right</span>
              </a>
            </li>
          <?php endif; ?>
        </ul>
      </div>
    <?php endif; ?>
  </div>

  <script>
    function deleteUser(id, name) {
      if (confirm('确定要删除用户 "' + name + '" 吗？\n此操作不可恢复！')) {
        window.location.href = './temp/delete_user.php?id=' + id;
      }
    }
  </script>
</body>
</html>