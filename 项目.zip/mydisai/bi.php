<?php
// dashboard.php - 数据仪表盘
require_once "./api/fn.php";
session();

// 获取消费数据
$consumptions = get_consumption_list();

// 按年月排序数据
usort($consumptions, function($a, $b) {
    if ($a['year'] == $b['year']) {
        return $b['month'] - $a['month'];
    }
    return $b['year'] - $a['year'];
});

// 获取所有可用的年月
$availableMonths = [];
foreach ($consumptions as $item) {
    $key = $item['year'] . '-' . str_pad($item['month'], 2, '0', STR_PAD_LEFT);
    $label = $item['year'] . '年' . $item['month'] . '月';
    $availableMonths[$key] = $label;
}

// 获取请求的月份范围
$startMonth = isset($_GET['start_month']) ? $_GET['start_month'] : '';
$endMonth = isset($_GET['end_month']) ? $_GET['end_month'] : '';

// 如果没有指定范围，默认显示最近6个月
if (empty($startMonth) || empty($endMonth)) {
    $months = array_keys($availableMonths);
    rsort($months);
    $recentMonths = array_slice($months, 0, 6);
    if (count($recentMonths) > 0) {
        sort($recentMonths);
        $startMonth = $recentMonths[0];
        $endMonth = end($recentMonths);
    }
}

// 计算总计
$totalConsumption = 0;
$totalLeads = 0;
$totalOrders = 0;

foreach ($consumptions as $item) {
    $totalConsumption += floatval($item['actual_consumption']);
    $totalLeads += intval($item['actual_leads']);
    $totalOrders += intval($item['actual_orders']);
}

// 计算平均成本
$avgCostPerLead = $totalLeads > 0 ? $totalConsumption / $totalLeads : 0;
$avgCostPerOrder = $totalOrders > 0 ? $totalConsumption / $totalOrders : 0;

// 按月组织数据
$monthlyData = [];
foreach ($consumptions as $item) {
    $key = $item['year'] . '-' . str_pad($item['month'], 2, '0', STR_PAD_LEFT);
    $consumption = floatval($item['actual_consumption']);
    $leads = intval($item['actual_leads']);
    $orders = intval($item['actual_orders']);
    
    // 计算单月成本
    $costPerLead = $leads > 0 ? $consumption / $leads : 0;
    $costPerOrder = $orders > 0 ? $consumption / $orders : 0;
    
    $monthlyData[$key] = [
        'consumption' => $consumption,
        'leads' => $leads,
        'orders' => $orders,
        'cost_per_lead' => $costPerLead,
        'cost_per_order' => $costPerOrder
    ];
}

// 获取选择范围内的月份
$allMonths = array_keys($monthlyData);
sort($allMonths);

// 过滤出选择范围内的月份
$selectedMonths = [];
foreach ($allMonths as $month) {
    if ($month >= $startMonth && $month <= $endMonth) {
        $selectedMonths[] = $month;
    }
}

// 如果选择范围为空，使用最近6个月
if (empty($selectedMonths) && !empty($monthlyData)) {
    $months = array_keys($monthlyData);
    rsort($months);
    $selectedMonths = array_slice($months, 0, 6);
    sort($selectedMonths);
}

// 准备图表数据
$chartLabels = array_map(function($month) {
    $parts = explode('-', $month);
    return $parts[0] . '年' . intval($parts[1]) . '月';
}, $selectedMonths);

$chartConsumption = [];
$chartLeads = [];
$chartOrders = [];
$chartCostPerLead = [];
$chartCostPerOrder = [];

foreach ($selectedMonths as $month) {
    if (isset($monthlyData[$month])) {
        $chartConsumption[] = $monthlyData[$month]['consumption'];
        $chartLeads[] = $monthlyData[$month]['leads'];
        $chartOrders[] = $monthlyData[$month]['orders'];
        $chartCostPerLead[] = $monthlyData[$month]['cost_per_lead'];
        $chartCostPerOrder[] = $monthlyData[$month]['cost_per_order'];
    }
}

// 计算环比增长率
$growthRates = [];
$prevMonthData = null;

foreach ($selectedMonths as $month) {
    if (!isset($monthlyData[$month])) continue;
    
    $currentData = $monthlyData[$month];
    
    if ($prevMonthData) {
        // 消耗环比
        $consumptionGrowth = $prevMonthData['consumption'] > 0 
            ? (($currentData['consumption'] - $prevMonthData['consumption']) / $prevMonthData['consumption'] * 100)
            : ($currentData['consumption'] > 0 ? 100 : 0);
        
        // 线索环比
        $leadsGrowth = $prevMonthData['leads'] > 0 
            ? (($currentData['leads'] - $prevMonthData['leads']) / $prevMonthData['leads'] * 100)
            : ($currentData['leads'] > 0 ? 100 : 0);
        
        // 订单环比
        $ordersGrowth = $prevMonthData['orders'] > 0 
            ? (($currentData['orders'] - $prevMonthData['orders']) / $prevMonthData['orders'] * 100)
            : ($currentData['orders'] > 0 ? 100 : 0);
        
        // 线索成本环比
        $costPerLeadGrowth = $prevMonthData['cost_per_lead'] > 0 
            ? (($currentData['cost_per_lead'] - $prevMonthData['cost_per_lead']) / $prevMonthData['cost_per_lead'] * 100)
            : ($currentData['cost_per_lead'] > 0 ? 100 : 0);
        
        // 订单成本环比
        $costPerOrderGrowth = $prevMonthData['cost_per_order'] > 0 
            ? (($currentData['cost_per_order'] - $prevMonthData['cost_per_order']) / $prevMonthData['cost_per_order'] * 100)
            : ($currentData['cost_per_order'] > 0 ? 100 : 0);
        
        $growthRates[$month] = [
            'consumption' => round($consumptionGrowth, 1),
            'leads' => round($leadsGrowth, 1),
            'orders' => round($ordersGrowth, 1),
            'cost_per_lead' => round($costPerLeadGrowth, 1),
            'cost_per_order' => round($costPerOrderGrowth, 1)
        ];
    } else {
        $growthRates[$month] = [
            'consumption' => 0,
            'leads' => 0,
            'orders' => 0,
            'cost_per_lead' => 0,
            'cost_per_order' => 0
        ];
    }
    
    $prevMonthData = $currentData;
}

// 计算时间范围内的数据总计（用于页面显示）
$rangeTotalConsumption = 0;
$rangeTotalLeads = 0;
$rangeTotalOrders = 0;

foreach ($selectedMonths as $month) {
    if (isset($monthlyData[$month])) {
        $rangeTotalConsumption += $monthlyData[$month]['consumption'];
        $rangeTotalLeads += $monthlyData[$month]['leads'];
        $rangeTotalOrders += $monthlyData[$month]['orders'];
    }
}

$rangeAvgCostPerLead = $rangeTotalLeads > 0 ? $rangeTotalConsumption / $rangeTotalLeads : 0;
$rangeAvgCostPerOrder = $rangeTotalOrders > 0 ? $rangeTotalConsumption / $rangeTotalOrders : 0;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>数据仪表盘 · 抖音本地通消耗追踪</title>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Microsoft YaHei', Arial, sans-serif;
    }
    
    body {
      background-color: #f5f5f5;
      color: #333;
      line-height: 1.5;
      padding: 15px;
    }
    
    .container {
      max-width: 1400px;
      margin: 0 auto;
    }
    
    /* 标题样式 */
    .header {
      background: #fff;
      padding: 15px 20px;
      border-radius: 5px;
      margin-bottom: 20px;
      border-left: 4px solid #10a37f;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    .header h1 {
      font-size: 18px;
      color: #333;
      margin: 0;
    }
    
    /* 导航样式 */
    .nav {
      display: flex;
      gap: 10px;
      margin-bottom: 20px;
    }
    
    .nav a {
      display: inline-block;
      padding: 8px 16px;
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 4px;
      text-decoration: none;
      color: #666;
      font-size: 14px;
      transition: all 0.2s;
    }
    
    .nav a:hover {
      background: #f0f0f0;
      color: #333;
    }
    
    .nav a.active {
      background: #10a37f;
      color: #fff;
      border-color: #10a37f;
    }
    
    /* 时间选择器 */
    .time-selector {
      background: #fff;
      border-radius: 5px;
      padding: 20px;
      margin-bottom: 20px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    .time-selector h2 {
      font-size: 16px;
      margin-bottom: 15px;
      color: #333;
    }
    
    .time-form {
      display: flex;
      align-items: center;
      gap: 15px;
      flex-wrap: wrap;
    }
    
    .form-group {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    
    .form-label {
      font-size: 14px;
      color: #666;
    }
    
    .form-select {
      padding: 8px 12px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
      min-width: 150px;
      background: #fff;
    }
    
    .form-select:focus {
      outline: none;
      border-color: #10a37f;
    }
    
    .btn {
      padding: 8px 20px;
      background: #10a37f;
      color: #fff;
      border: none;
      border-radius: 4px;
      font-size: 14px;
      cursor: pointer;
      transition: background 0.2s;
    }
    
    .btn:hover {
      background: #0d8c6d;
    }
    
    .btn-reset {
      background: #666;
    }
    
    .btn-reset:hover {
      background: #555;
    }
    
    /* 统计卡片 */
    .stats {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 15px;
      margin-bottom: 20px;
    }
    
    .stat-card {
      background: #fff;
      border-radius: 5px;
      padding: 20px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
      border-top: 3px solid;
    }
    
    .stat-card.consumption {
      border-top-color: #f44336;
    }
    
    .stat-card.leads {
      border-top-color: #9c27b0;
    }
    
    .stat-card.orders {
      border-top-color: #4caf50;
    }
    
    .stat-card.cost-per-lead {
      border-top-color: #2196f3;
    }
    
    .stat-card.cost-per-order {
      border-top-color: #ff9800;
    }
    
    .stat-title {
      font-size: 14px;
      color: #666;
      margin-bottom: 10px;
    }
    
    .stat-value {
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 5px;
    }
    
    .stat-range {
      font-size: 12px;
      color: #999;
      margin-top: 5px;
    }
    
    /* 图表容器 */
    .chart-box {
      background: #fff;
      border-radius: 5px;
      padding: 20px;
      margin-bottom: 20px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    .chart-box h2 {
      font-size: 16px;
      margin-bottom: 15px;
      color: #333;
    }
    
    .chart-container {
      height: 300px;
      position: relative;
    }
    
    /* 表格样式 */
    .table-box {
      background: #fff;
      border-radius: 5px;
      overflow: hidden;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    
    .table-box h2 {
      font-size: 16px;
      padding: 15px 20px;
      margin: 0;
      background: #f8f9fa;
      border-bottom: 1px solid #eee;
      color: #333;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }
    
    th {
      background: #f8f9fa;
      padding: 12px 8px;
      text-align: right;
      font-weight: 600;
      color: #555;
      font-size: 13px;
      border-bottom: 1px solid #eee;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    th:first-child {
      text-align: left;
      padding-left: 15px;
      width: 120px;
    }
    
    td {
      padding: 12px 8px;
      border-bottom: 1px solid #eee;
      font-size: 13px;
      text-align: right;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    td:first-child {
      text-align: left;
      padding-left: 15px;
      font-weight: 500;
      width: 120px;
    }
    
    tr:hover {
      background: #f9f9f9;
    }
    
    .cost-indicator {
      color: #2196f3;
      font-weight: 500;
    }
    
    /* 响应式 */
    @media (max-width: 768px) {
      body {
        padding: 10px;
      }
      
      .stats {
        grid-template-columns: 1fr;
      }
      
      .chart-container {
        height: 250px;
      }
      
      .nav {
        flex-wrap: wrap;
      }
      
      .time-form {
        flex-direction: column;
        align-items: flex-start;
      }
      
      .form-group {
        width: 100%;
      }
      
      .form-select {
        flex: 1;
      }
      
      table {
        display: block;
        overflow-x: auto;
      }
      
      th, td {
        min-width: 100px;
      }
      
      th:first-child, td:first-child {
        position: sticky;
        left: 0;
        background: #fff;
        z-index: 1;
      }
      
      tr:hover td:first-child {
        background: #f9f9f9;
      }
    }
  </style>
</head>
<body>
  <div class="container">
    <!-- 页面标题 -->
    <div class="header">
      <h1>数据仪表盘</h1>
    </div>

    <!-- 导航链接 -->
    <div class="nav">
      <a href="dashboard.php" class="active">数据仪表盘</a>
      <a href="home.php">消耗明细列表</a>
      <a href="add.php">添加记录</a>
    </div>

    <!-- 时间选择器 -->
    <div class="time-selector">
      <h2>选择时间范围</h2>
      <form method="GET" class="time-form">
        <div class="form-group">
          <span class="form-label">开始月份：</span>
          <select name="start_month" class="form-select">
            <option value="">请选择开始月份</option>
            <?php foreach ($availableMonths as $key => $label): ?>
              <option value="<?= $key ?>" <?= $key == $startMonth ? 'selected' : '' ?>>
                <?= $label ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        
        <div class="form-group">
          <span class="form-label">结束月份：</span>
          <select name="end_month" class="form-select">
            <option value="">请选择结束月份</option>
            <?php foreach ($availableMonths as $key => $label): ?>
              <option value="<?= $key ?>" <?= $key == $endMonth ? 'selected' : '' ?>>
                <?= $label ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        
        <div class="form-group" style="gap: 10px;">
          <button type="submit" class="btn">查询</button>
          <a href="dashboard.php" class="btn btn-reset" style="text-decoration: none; display: inline-block;">重置</a>
        </div>
        
        <?php if (!empty($selectedMonths)): ?>
        <div style="font-size: 13px; color: #666; margin-left: auto;">
          显示范围：<?= date('Y年m月', strtotime($selectedMonths[0] . '-01')) ?> - <?= date('Y年m月', strtotime(end($selectedMonths) . '-01')) ?>
          (共 <?= count($selectedMonths) ?> 个月)
        </div>
        <?php endif; ?>
      </form>
    </div>

    <!-- 总体数据统计 -->
    <div class="stats">
      <div class="stat-card consumption">
        <div class="stat-title">消耗金额</div>
        <div class="stat-value">¥<?= number_format($rangeTotalConsumption, 2) ?></div>
        <div class="stat-range">选择范围内总计</div>
      </div>

      <div class="stat-card leads">
        <div class="stat-title">实际线索</div>
        <div class="stat-value"><?= number_format($rangeTotalLeads) ?></div>
        <div class="stat-range">选择范围内总计</div>
      </div>

      <div class="stat-card orders">
        <div class="stat-title">实际订单</div>
        <div class="stat-value"><?= number_format($rangeTotalOrders) ?></div>
        <div class="stat-range">选择范围内总计</div>
      </div>
      
      <div class="stat-card cost-per-lead">
        <div class="stat-title">平均线索成本</div>
        <div class="stat-value">¥<?= number_format($rangeAvgCostPerLead, 2) ?></div>
        <div class="stat-range">选择范围内平均</div>
      </div>
      
      <div class="stat-card cost-per-order">
        <div class="stat-title">平均订单成本</div>
        <div class="stat-value">¥<?= number_format($rangeAvgCostPerOrder, 2) ?></div>
        <div class="stat-range">选择范围内平均</div>
      </div>
    </div>

    <!-- 月度趋势图 -->
    <div class="chart-box">
      <h2>月度趋势分析 (<?= count($selectedMonths) ?>个月)</h2>
      <div class="chart-container">
        <canvas id="trendChart"></canvas>
      </div>
    </div>

    <!-- 月度环比数据表 -->
    <div class="table-box">
      <h2>月度环比数据</h2>
      <div style="overflow-x: auto;">
        <table>
          <thead>
            <tr>
              <th>月份</th>
              <th>实际消耗</th>
              <th>消耗环比</th>
              <th>实际线索</th>
              <th>线索环比</th>
              <th>实际订单</th>
              <th>订单环比</th>
              <th>线索成本</th>
              <th>线索成本环比</th>
              <th>订单成本</th>
              <th>订单成本环比</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($selectedMonths as $month): ?>
              <?php 
              if (!isset($monthlyData[$month])) continue;
              $data = $monthlyData[$month];
              $growth = $growthRates[$month] ?? ['consumption' => 0, 'leads' => 0, 'orders' => 0, 'cost_per_lead' => 0, 'cost_per_order' => 0];
              $monthLabel = explode('-', $month);
              $monthLabel = $monthLabel[0] . '年' . intval($monthLabel[1]) . '月';
              ?>
              <tr>
                <td><?= $monthLabel ?></td>
                <td>¥<?= number_format($data['consumption'], 2) ?></td>
                <td>
                  <?php if ($growth['consumption'] > 0): ?>
                    <span style="color: #f44336;">+<?= $growth['consumption'] ?>%</span>
                  <?php elseif ($growth['consumption'] < 0): ?>
                    <span style="color: #4caf50;"><?= $growth['consumption'] ?>%</span>
                  <?php else: ?>
                    -
                  <?php endif; ?>
                </td>
                <td><?= number_format($data['leads']) ?></td>
                <td>
                  <?php if ($growth['leads'] > 0): ?>
                    <span style="color: #4caf50;">+<?= $growth['leads'] ?>%</span>
                  <?php elseif ($growth['leads'] < 0): ?>
                    <span style="color: #f44336;"><?= $growth['leads'] ?>%</span>
                  <?php else: ?>
                    -
                  <?php endif; ?>
                </td>
                <td><?= number_format($data['orders']) ?></td>
                <td>
                  <?php if ($growth['orders'] > 0): ?>
                    <span style="color: #4caf50;">+<?= $growth['orders'] ?>%</span>
                  <?php elseif ($growth['orders'] < 0): ?>
                    <span style="color: #f44336;"><?= $growth['orders'] ?>%</span>
                  <?php else: ?>
                    -
                  <?php endif; ?>
                </td>
                <td class="cost-indicator">¥<?= number_format($data['cost_per_lead'], 2) ?>/条</td>
                <td>
                  <?php if ($growth['cost_per_lead'] > 0): ?>
                    <span style="color: #f44336;">+<?= $growth['cost_per_lead'] ?>%</span>
                  <?php elseif ($growth['cost_per_lead'] < 0): ?>
                    <span style="color: #4caf50;"><?= $growth['cost_per_lead'] ?>%</span>
                  <?php else: ?>
                    -
                  <?php endif; ?>
                </td>
                <td class="cost-indicator">¥<?= number_format($data['cost_per_order'], 2) ?>/单</td>
                <td>
                  <?php if ($growth['cost_per_order'] > 0): ?>
                    <span style="color: #f44336;">+<?= $growth['cost_per_order'] ?>%</span>
                  <?php elseif ($growth['cost_per_order'] < 0): ?>
                    <span style="color: #4caf50;"><?= $growth['cost_per_order'] ?>%</span>
                  <?php else: ?>
                    -
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <script>
    // 初始化图表
    const ctx = document.getElementById('trendChart').getContext('2d');
    
    // 准备数据
    const chartData = {
      labels: <?= json_encode($chartLabels) ?>,
      datasets: [
        {
          label: '实际消耗',
          data: <?= json_encode($chartConsumption) ?>,
          borderColor: '#f44336',
          backgroundColor: 'rgba(244, 67, 54, 0.1)',
          tension: 0.4,
          fill: true,
          yAxisID: 'y'
        },
        {
          label: '实际线索',
          data: <?= json_encode($chartLeads) ?>,
          borderColor: '#9c27b0',
          backgroundColor: 'rgba(156, 39, 176, 0.1)',
          tension: 0.4,
          fill: true,
          yAxisID: 'y1'
        },
        {
          label: '实际订单',
          data: <?= json_encode($chartOrders) ?>,
          borderColor: '#4caf50',
          backgroundColor: 'rgba(76, 175, 80, 0.1)',
          tension: 0.4,
          fill: true,
          yAxisID: 'y'
        },
        {
          label: '线索成本',
          data: <?= json_encode($chartCostPerLead) ?>,
          borderColor: '#2196f3',
          backgroundColor: 'rgba(33, 150, 243, 0.1)',
          tension: 0.4,
          fill: true,
          yAxisID: 'y2',
          hidden: true
        },
        {
          label: '订单成本',
          data: <?= json_encode($chartCostPerOrder) ?>,
          borderColor: '#ff9800',
          backgroundColor: 'rgba(255, 152, 0, 0.1)',
          tension: 0.4,
          fill: true,
          yAxisID: 'y2',
          hidden: true
        }
      ]
    };

    // 创建图表
    const trendChart = new Chart(ctx, {
      type: 'line',
      data: chartData,
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'top',
            labels: {
              padding: 10,
              font: {
                size: 11
              },
              usePointStyle: true,
              boxWidth: 8
            }
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                let label = context.dataset.label || '';
                if (label) {
                  label += ': ';
                }
                if (context.datasetIndex === 0 || context.datasetIndex === 2 || context.datasetIndex === 3 || context.datasetIndex === 4) {
                  label += '¥' + context.parsed.y.toLocaleString('zh-CN', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                  });
                  if (context.datasetIndex === 3) label += '/条';
                  if (context.datasetIndex === 4) label += '/单';
                } else {
                  label += context.parsed.y.toLocaleString('zh-CN');
                }
                return label;
              }
            }
          }
        },
        scales: {
          x: {
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            ticks: {
              font: {
                size: 11
              }
            }
          },
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            grid: {
              color: 'rgba(0, 0, 0, 0.05)'
            },
            ticks: {
              callback: function(value) {
                return '¥' + value.toLocaleString('zh-CN');
              },
              font: {
                size: 11
              }
            }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            grid: {
              drawOnChartArea: false,
            },
            ticks: {
              font: {
                size: 11
              }
            }
          },
          y2: {
            type: 'linear',
            display: false,
            position: 'right',
            grid: {
              drawOnChartArea: false,
            }
          }
        }
      }
    });
    
    // 监听月份选择变化，自动设置结束月份不小于开始月份
    document.querySelector('select[name="start_month"]').addEventListener('change', function() {
      const startSelect = this;
      const endSelect = document.querySelector('select[name="end_month"]');
      const startValue = startSelect.value;
      
      if (startValue) {
        // 禁用结束月份中早于开始月份的选项
        const endOptions = endSelect.querySelectorAll('option');
        endOptions.forEach(option => {
          if (option.value && option.value < startValue) {
            option.disabled = true;
          } else {
            option.disabled = false;
          }
        });
        
        // 如果当前选中的结束月份早于开始月份，清空结束月份选择
        if (endSelect.value && endSelect.value < startValue) {
          endSelect.value = '';
        }
      } else {
        // 如果开始月份被清空，启用所有结束月份选项
        const endOptions = endSelect.querySelectorAll('option');
        endOptions.forEach(option => {
          option.disabled = false;
        });
      }
    });
  </script>
</body>
</html>