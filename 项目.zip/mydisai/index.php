<?php
// PHP代码必须放在最前面，不能有任何输出
require_once "./api/fn.php";
session();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>中国星</title>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <style>
    /* ====== DeepSeek风格CSS变量与重置 ====== */
    :root {
      /* DeepSeek主色调 */
      --primary-color: #10a37f;
      --primary-dark: #0d8c6d;
      --primary-light: #e6f7f2;
      
      /* 中性色调 */
      --gray-900: #1a1a1a;
      --gray-800: #2d2d2d;
      --gray-700: #404040;
      --gray-600: #666666;
      --gray-500: #8c8c8c;
      --gray-400: #b3b3b3;
      --gray-300: #d9d9d9;
      --gray-200: #e6e6e6;
      --gray-100: #f5f5f5;
      --gray-50: #fafafa;
      
      /* 功能色 */
      --success-color: #10a37f;
      --warning-color: #ff9800;
      --error-color: #f44336;
      --info-color: #2196f3;
      
      /* 排版 */
      --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      --font-family-mono: "SFMono-Regular", Consolas, "Liberation Mono", Menlo, Courier, monospace;
      
      /* 间距 */
      --spacing-xs: 4px;
      --spacing-sm: 8px;
      --spacing-md: 16px;
      --spacing-lg: 24px;
      --spacing-xl: 32px;
      --spacing-xxl: 48px;
      
      /* 圆角 */
      --radius-sm: 4px;
      --radius-md: 8px;
      --radius-lg: 12px;
      --radius-xl: 16px;
      --radius-full: 9999px;
      
      /* 阴影 */
      --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.05);
      --shadow-md: 0 4px 16px rgba(0, 0, 0, 0.1);
      --shadow-lg: 0 8px 32px rgba(0, 0, 0, 0.12);
      
      /* 过渡 */
      --transition-fast: 150ms ease;
      --transition-normal: 250ms ease;
      --transition-slow: 350ms ease;
      
      /* 侧边栏宽度 */
      --sidebar-width: 260px;
      --sidebar-collapsed-width: 70px;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }
    
    body {
      font-family: var(--font-family);
      color: var(--gray-900);
      background-color: white;
      line-height: 1.6;
      font-size: 16px;
      overflow: hidden;
      margin: 0;
      height: 100vh;
    }
    
    /* ====== 布局样式 ====== */
    .admin-wrapper {
      display: flex;
      height: 100vh;
      width: 100%;
    }
    
    /* 侧边栏样式 */
    .sidebar {
      width: var(--sidebar-width);
      background-color: var(--gray-50);
      border-right: 1px solid var(--gray-200);
      display: flex;
      flex-direction: column;
      transition: width var(--transition-normal);
      overflow: hidden;
      flex-shrink: 0;
    }
    
    .sidebar-header {
      padding: var(--spacing-xl) var(--spacing-lg) var(--spacing-lg);
      border-bottom: 1px solid var(--gray-200);
    }
    
    .sidebar-title {
      font-size: 1.25rem;
      font-weight: 600;
      color: var(--gray-900);
      margin-bottom: var(--spacing-xs);
      line-height: 1.3;
    }
    
    .sidebar-subtitle {
      font-size: 0.875rem;
      color: var(--gray-600);
      font-weight: 500;
      letter-spacing: 1px;
    }
    
    .sidebar-nav {
      flex: 1;
      padding: var(--spacing-lg) 0;
      overflow-y: auto;
    }
    
    .nav-section {
      margin-bottom: var(--spacing-xl);
    }
    
    .nav-section-title {
      font-size: 0.75rem;
      font-weight: 600;
      color: var(--gray-500);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      padding: 0 var(--spacing-lg) var(--spacing-sm);
      margin-bottom: var(--spacing-sm);
    }
    
    .nav-section ul {
      list-style: none;
    }
    
    .nav-item {
      margin-bottom: var(--spacing-xs);
    }
    
    .nav-link {
      display: flex;
      align-items: center;
      padding: var(--spacing-sm) var(--spacing-lg);
      color: var(--gray-700);
      text-decoration: none;
      transition: all var(--transition-fast);
      border-left: 3px solid transparent;
      gap: var(--spacing-md);
    }
    
    .nav-link:hover {
      background-color: var(--gray-100);
      color: var(--primary-color);
    }
    
    .nav-link.active {
      background-color: var(--primary-light);
      color: var(--primary-color);
      border-left-color: var(--primary-color);
      font-weight: 500;
    }
    
    .nav-link .material-icons {
      font-size: 1.25rem;
      width: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .nav-link-text {
      font-size: 0.9375rem;
    }
    
    .sidebar-footer {
      padding: var(--spacing-lg);
      border-top: 1px solid var(--gray-200);
      margin-top: auto;
    }
    
    /* 主内容区域 */
    .main-content {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      background-color: white;
    }
    
    /* 顶部栏 */
    .top-bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: var(--spacing-md) var(--spacing-lg);
      background-color: white;
      border-bottom: 1px solid var(--gray-200);
      height: 64px;
      flex-shrink: 0;
    }
    
    .breadcrumb {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
      font-size: 0.875rem;
      color: var(--gray-600);
    }
    
    .breadcrumb-item {
      display: flex;
      align-items: center;
      gap: var(--spacing-xs);
    }
    
    .breadcrumb-separator {
      color: var(--gray-400);
    }
    
    .top-bar-right {
      display: flex;
      align-items: center;
      gap: var(--spacing-lg);
    }
    
    .user-info {
      display: flex;
      align-items: center;
      gap: var(--spacing-sm);
      color: var(--gray-700);
      font-weight: 500;
    }
    
    .user-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      background-color: var(--primary-color);
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 0.875rem;
    }
    
    /* 按钮样式 */
    .btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: var(--spacing-sm) var(--spacing-md);
      font-size: 0.875rem;
      font-weight: 500;
      line-height: 1.5;
      border-radius: var(--radius-md);
      border: 1px solid transparent;
      cursor: pointer;
      transition: all var(--transition-fast);
      text-decoration: none;
      gap: var(--spacing-sm);
    }
    
    .btn-accent {
      background-color: var(--primary-color);
      color: white;
    }
    
    .btn-accent:hover {
      background-color: var(--primary-dark);
      color: white;
      text-decoration: none;
    }
    
    .btn-sm {
      padding: var(--spacing-xs) var(--spacing-md);
      font-size: 0.8125rem;
    }
    
    /* 内容区域 */
    .content-area {
      flex: 1;
      padding: var(--spacing-lg);
      overflow: hidden;
      background-color: var(--gray-50);
    }
    
    #main-iframe {
      width: 100%;
      height: 100%;
      border: none;
      border-radius: var(--radius-lg);
      box-shadow: var(--shadow-md);
      background-color: white;
    }
    
    /* 页脚 */
    .page-footer {
      padding: var(--spacing-md) var(--spacing-lg);
      text-align: center;
      color: var(--gray-600);
      font-size: 0.875rem;
      border-top: 1px solid var(--gray-200);
      flex-shrink: 0;
      background-color: white;
    }
    
    /* ====== 响应式设计 ====== */
    @media (max-width: 992px) {
      .sidebar {
        width: var(--sidebar-collapsed-width);
      }
      
      .sidebar-title,
      .sidebar-subtitle,
      .nav-link-text,
      .nav-section-title {
        display: none;
      }
      
      .sidebar-header {
        padding: var(--spacing-lg) var(--spacing-sm);
        text-align: center;
      }
      
      .nav-link {
        padding: var(--spacing-md) var(--spacing-sm);
        justify-content: center;
        border-left: none;
        border-right: 3px solid transparent;
      }
      
      .nav-link.active {
        border-right-color: var(--primary-color);
        border-left-color: transparent;
      }
      
      .sidebar-footer p {
        font-size: 0;
      }
      
      .sidebar-footer p:before {
        content: "© 2025";
        font-size: 0.625rem;
      }
    }
    
    @media (max-width: 768px) {
      .admin-wrapper {
        flex-direction: column;
      }
      
      .sidebar {
        width: 100%;
        height: auto;
        flex-direction: row;
        align-items: center;
        padding: 0 var(--spacing-md);
      }
      
      .sidebar-header {
        padding: var(--spacing-md);
        border-bottom: none;
        border-right: 1px solid var(--gray-200);
        width: auto;
      }
      
      .sidebar-title {
        font-size: 1rem;
        margin-bottom: 0;
      }
      
      .sidebar-subtitle {
        display: none;
      }
      
      .sidebar-nav {
        flex: 1;
        padding: 0;
        display: flex;
        overflow-x: auto;
        overflow-y: hidden;
      }
      
      .nav-section {
        margin-bottom: 0;
        margin-right: var(--spacing-lg);
      }
      
      .nav-section-title {
        display: none;
      }
      
      .nav-section ul {
        display: flex;
        gap: var(--spacing-md);
      }
      
      .nav-item {
        margin-bottom: 0;
      }
      
      .nav-link {
        padding: var(--spacing-sm) var(--spacing-md);
        border-left: none;
        border-bottom: 3px solid transparent;
      }
      
      .nav-link.active {
        border-left-color: transparent;
        border-bottom-color: var(--primary-color);
      }
      
      .sidebar-footer {
        display: none;
      }
      
      .top-bar {
        padding: var(--spacing-sm) var(--spacing-md);
      }
      
      .user-info span {
        display: none;
      }
      
      .breadcrumb {
        font-size: 0.75rem;
      }
      
      .content-area {
        padding: var(--spacing-md);
      }
    }
    
    @media (max-width: 576px) {
      .top-bar-right {
        gap: var(--spacing-sm);
      }
      
      .btn-accent span:last-child {
        display: none;
      }
      
      .btn-accent .material-icons {
        margin-right: 0;
      }
    }
    
    /* ====== 深色模式支持 ====== */
    @media (prefers-color-scheme: dark) {
      :root {
        --gray-900: #f5f5f5;
        --gray-800: #e6e6e6;
        --gray-700: #d9d9d9;
        --gray-600: #b3b3b3;
        --gray-500: #8c8c8c;
        --gray-400: #666666;
        --gray-300: #404040;
        --gray-200: #2d2d2d;
        --gray-100: #1a1a1a;
        --gray-50: #111111;
        
        --primary-light: rgba(16, 163, 127, 0.2);
      }
      
      body {
        background-color: var(--gray-50);
        color: var(--gray-900);
      }
      
      .sidebar {
        background-color: var(--gray-100);
        border-right-color: var(--gray-300);
      }
      
      .main-content {
        background-color: var(--gray-50);
      }
      
      .top-bar {
        background-color: var(--gray-100);
        border-bottom-color: var(--gray-300);
      }
      
      .content-area {
        background-color: var(--gray-50);
      }
      
      #main-iframe {
        background-color: var(--gray-100);
      }
      
      .page-footer {
        background-color: var(--gray-100);
        border-top-color: var(--gray-300);
      }
    }
  </style>

</head>
<body>
  <div class="admin-wrapper">
    <!-- 侧边栏 -->
    <aside class="sidebar">
      <div class="sidebar-header">
        <h1 class="sidebar-title">中国星</h1>
        <p class="sidebar-subtitle">ADMIN</p>
      </div>

      <nav class="sidebar-nav">
          
        <div class="nav-section">
          <h3 class="nav-section-title">数据分析</h3>
          <ul>
              <li class="nav-item">
                <a href="#" class="nav-link active" data-page="bi.php">
                  <span class="material-icons">trending_up</span>
                  <span class="nav-link-text">数据分析</span>
                </a>
              </li>
          </ul>
        </div>  
          
        <div class="nav-section">
          <h3 class="nav-section-title">月度统计</h3>
          <ul>
              <li class="nav-item">
                <a href="#" class="nav-link active" data-page="home.php">
                  <span class="material-icons">home</span>
                  <span class="nav-link-text">月度统计</span>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link" data-page="user_list.php">
                  <span class="material-icons">people</span>
                  <span class="nav-link-text">用户管理</span>
                </a>
              </li>
          </ul>
        </div>

        <div class="nav-section">
          <h3 class="nav-section-title">系统设置</h3>
          <ul>
            <li class="nav-item">
              <a href="#" class="nav-link" data-page="edit_password.php">
                <span class="material-icons">settings</span>
                <span class="nav-link-text">个人中心</span>
              </a>
            </li>
          </ul>
        </div>
      </nav>

      <div class="sidebar-footer">
        <div class="text-center text-muted" style="font-size: 0.75rem;">
          <p>© 2025 抖音本地通消耗追踪管理系统</p>
        </div>
      </div>
    </aside>

    <!-- 主内容区域 -->
    <main class="main-content">
      <!-- 顶部栏 -->
      <header class="top-bar">
        <div class="top-bar-left">
          <div class="breadcrumb">
            <span class="breadcrumb-item">
              <span class="material-icons" style="font-size: 1rem;">home</span>
            </span>
            <span class="breadcrumb-separator">/</span>
            <span class="breadcrumb-item" id="breadcrumb-item-title">月度统计</span>
          </div>
        </div>

        <div class="top-bar-right">
          <div class="user-info">
            <div class="user-avatar">管</div>
            <span>管理员</span>
          </div>
          <a href="./temp/xiaohui.php" class="btn btn-accent btn-sm">
            <span class="material-icons" style="font-size: 1rem;">logout</span>
            退出
          </a>
        </div>
      </header>

      <!-- 内容区域 -->
      <div class="content-area">
        <iframe 
          id="main-iframe" 
          src="./home.php" 
          style="width: 100%; height: 100%; border: none;">
        </iframe>
      </div>

      <!-- 页脚 -->
      <footer class="page-footer">
        <p>抖音本地通消耗追踪后台管理系统 · 数字化管理</p>
      </footer>
    </main>
  </div>

  <script>
    // 导航切换功能
    document.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();

        // 获取文字
        const text = this.querySelector('.nav-link-text').textContent;
        
        // 移除所有active类
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        
        // 添加active类到当前项
        this.classList.add('active');
        
        // 加载对应页面
        const page = this.getAttribute('data-page');
        if (page) {
          document.getElementById('main-iframe').src = './' + page;
          document.getElementById('breadcrumb-item-title').innerHTML = text;
        }
      });
    });

    // iframe加载完成后的处理
    document.getElementById('main-iframe').addEventListener('load', function() {
      // 可以在这里添加iframe加载完成后的回调处理
      console.log('iframe加载完成:', this.src);
    });
    
    // 响应式侧边栏切换（可选功能）
    document.addEventListener('DOMContentLoaded', function() {
      // 添加窗口大小变化监听
      window.addEventListener('resize', handleResponsiveLayout);
      handleResponsiveLayout();
      
      function handleResponsiveLayout() {
        const sidebar = document.querySelector('.sidebar');
        const windowWidth = window.innerWidth;
        
        // 在小屏幕上自动折叠侧边栏
        if (windowWidth <= 992 && !sidebar.classList.contains('collapsed')) {
          // 可以在这里添加自动折叠逻辑
        }
      }
    });
  </script>
</body>
</html>