<?php
require_once "../api/fn.php";
session();

// 处理表单提交
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // 获取基础配置数据
    $year = isset($_POST['year']) ? intval($_POST['year']) : 0;
    $month = isset($_POST['month']) ? intval($_POST['month']) : 0;
    $budget = isset($_POST['budget']) ? floatval($_POST['budget']) : 0;
    $task_quantity = isset($_POST['task_quantity']) ? intval($_POST['task_quantity']) : 0;
    $target_volume = isset($_POST['target_volume']) ? intval($_POST['target_volume']) : 0;
    $remarks = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';
    $nodes = isset($_POST['nodes']) ? $_POST['nodes'] : array();

    // 验证必填字段
    if (empty($year) || empty($month) || empty($budget) || empty($task_quantity) || empty($target_volume)) {
        echo "<script>alert('请填写所有必填项！'); history.back();</script>";
        exit;
    }

    // 验证数据有效性
    if ($budget <= 0) {
        echo "<script>alert('预算金额必须大于0！'); history.back();</script>";
        exit;
    }

    if ($task_quantity <= 0) {
        echo "<script>alert('线索任务数必须大于0！'); history.back();</script>";
        exit;
    }

    if ($target_volume <= 0) {
        echo "<script>alert('订单目标数必须大于0！'); history.back();</script>";
        exit;
    }

    // 检查年月是否已存在
    if (check_year_month_exists($year, $month)) {
        echo "<script>alert('该年月的配置已存在，请选择其他年月！'); history.back();</script>";
        exit;
    }

    // 处理核销节点数据，将日期转换为完整日期格式
    $processed_nodes = array();
    if (!empty($nodes) && is_array($nodes)) {
        foreach ($nodes as $node) {
            if (isset($node['write_off_date']) && isset($node['amount']) && 
                isset($node['start_day']) && isset($node['end_day'])) {
                
                $start_day = intval($node['start_day']);
                $end_day = intval($node['end_day']);
                
                // 验证日期范围
                if ($start_day < 1 || $start_day > 31 || $end_day < 1 || $end_day > 31) {
                    echo "<script>alert('日期必须在1-31之间！'); history.back();</script>";
                    exit;
                }
                
                if ($start_day > $end_day) {
                    echo "<script>alert('起始日不能大于结束日！'); history.back();</script>";
                    exit;
                }
                
                
                $processed_nodes[] = array(
                    'write_off_date' => $node['write_off_date'],
                    'amount' => $node['amount'],
                    'start_date' => $start_day,
                    'end_date' => $end_day
                );
            }
        }
    }

    // 插入基础配置并获取核销节点
    $result = add_base_config_with_nodes($year, $month, $budget, $task_quantity, $target_volume, $remarks, $processed_nodes);

    if ($result['success']) {
        echo "<script>alert('添加成功！'); window.location.href='../home.php';</script>";
    } else {
        echo "<script>alert('添加失败：" . addslashes($result['message']) . "'); history.back();</script>";
    }
} else {
    header('Location: ../add.php');
    exit;
}
