<?php


// 登入验证
function login($name)
{

    require "db.php";
    $list = array();
    // 查询是否存在改名
    $stmt1 = $mysqli->prepare("SELECT * FROM user WHERE name=?");
    // "sss" 表示三个参数都是字符串  
    $stmt1->bind_param("s", $name);
    $stmt1->execute();
    // 获取结合集
    $res1 = $stmt1->get_result();
    if ($res1->num_rows > 0) {
        $list = $res1->fetch_assoc();
        return $list;
    } else {
        return false;
    }

}

// 获取当月的数据（基础配置、业务明细、核销节点）
function get_current_month_data($year, $month)
{
    require "db.php";
    
    // 获取基础配置
    $stmt = $mysqli->prepare("SELECT * FROM base_config WHERE year = ? AND month = ?");
    $stmt->bind_param("ii", $year, $month);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 0) {
        return null;
    }
    
    $config = $result->fetch_assoc();
    
    // 获取业务明细（按日期排序）
    $stmt_detail = $mysqli->prepare("SELECT * FROM business_detail WHERE year = ? AND month = ? ORDER BY day_of_month");
    $stmt_detail->bind_param("ii", $year, $month);
    $stmt_detail->execute();
    $detail_result = $stmt_detail->get_result();
    $details = array();
    while ($row = $detail_result->fetch_assoc()) {
        $details[] = $row;
    }
    
    // 获取核销节点
    $stmt_node = $mysqli->prepare("SELECT * FROM write_off_node WHERE base_config_id = ? ORDER BY write_off_date");
    $stmt_node->bind_param("i", $config['id']);
    $stmt_node->execute();
    $node_result = $stmt_node->get_result();
    $nodes = array();
    while ($row = $node_result->fetch_assoc()) {
        // 计算该节点的已消耗金额（根据日期范围）
        $start_day = intval($row['start_date']);
        $end_day = intval($row['end_date']);
        
        $stmt_consumed = $mysqli->prepare("
            SELECT COALESCE(SUM(daily_consumption), 0) AS consumed 
            FROM business_detail 
            WHERE year = ? AND month = ? AND day_of_month >= ? AND day_of_month <= ?
        ");
        $stmt_consumed->bind_param("iiii", $year, $month, $start_day, $end_day);
        $stmt_consumed->execute();
        $consumed_result = $stmt_consumed->get_result();
        $consumed_data = $consumed_result->fetch_assoc();
        
        $row['consumed_amount'] = floatval($consumed_data['consumed']);
        $row['consumption_diff'] = floatval($row['amount']) - floatval($consumed_data['consumed']);
        
        $nodes[] = $row;
    }
    
    // 计算汇总数据
    $total_consumption = 0;
    $total_natural_leads = 0;
    $total_ad_leads = 0;
    $total_orders = 0;
    
    foreach ($details as $detail) {
        $total_consumption += floatval($detail['daily_consumption']);
        $total_natural_leads += intval($detail['natural_leads']);
        $total_ad_leads += intval($detail['ad_leads']);
        $total_orders += intval($detail['order_quantity']);
    }
    
    return array(
        'config' => $config,
        'details' => $details,
        'nodes' => $nodes,
        'summary' => array(
            'total_consumption' => $total_consumption,
            'total_natural_leads' => $total_natural_leads,
            'total_ad_leads' => $total_ad_leads,
            'total_orders' => $total_orders,
            'total_leads' => $total_natural_leads + $total_ad_leads,
            'remaining_budget' => floatval($config['budget']) - $total_consumption,
            'budget_usage_rate' => floatval($config['budget']) > 0 ? ($total_consumption / floatval($config['budget']) * 100) : 0,
            'leads_diff' => intval($config['task_quantity']) - ($total_natural_leads + $total_ad_leads),
            'leads_completion_rate' => intval($config['task_quantity']) > 0 ? (($total_natural_leads + $total_ad_leads) / intval($config['task_quantity']) * 100) : 0,
            'order_completion_rate' => intval($config['target_volume']) > 0 ? ($total_orders / intval($config['target_volume']) * 100) : 0,
            'cost_per_lead' => ($total_natural_leads + $total_ad_leads) > 0 ? ($total_consumption / ($total_natural_leads + $total_ad_leads)) : 0,
            'cost_per_order' => $total_orders > 0 ? ($total_consumption / $total_orders) : 0,
            'ad_leads_cost' => $total_ad_leads > 0 ? ($total_consumption / $total_ad_leads) : 0
        )
    );
}

// 更新每日业务明细
function update_daily_details($details)
{
    require "db.php";
    
    // 开启事务
    $mysqli->begin_transaction();
    
    try {
        $stmt = $mysqli->prepare("UPDATE business_detail SET natural_leads = ?, ad_leads = ?, daily_consumption = ?, order_quantity = ? WHERE id = ?");
        
        foreach ($details as $detail) {
            if (isset($detail['id'])) {
                $natural_leads = intval($detail['natural_leads']);
                $ad_leads = intval($detail['ad_leads']);
                $daily_consumption = floatval($detail['daily_consumption']);
                $order_quantity = intval($detail['order_quantity']);
                $detail_id = intval($detail['id']);
                
                $stmt->bind_param("iidii", $natural_leads, $ad_leads, $daily_consumption, $order_quantity, $detail_id);
                
                if (!$stmt->execute()) {
                    throw new Exception("更新业务明细失败");
                }
            }
        }
        
        $mysqli->commit();
        return array('success' => true, 'message' => '保存成功');
        
    } catch (Exception $e) {
        $mysqli->rollback();
        return array('success' => false, 'message' => $e->getMessage());
    }
}

