<?php
require_once "../api/fn.php";
session();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    echo "<script>alert('参数错误！'); window.location.href='../user_list.php';</script>";
    exit;
}

// 调用删除函数
$result = delete_user($id);

if ($result) {
    echo "<script>alert('用户删除成功！'); window.location.href='../user_list.php';</script>";
} else {
    echo "<script>alert('用户删除失败！'); window.location.href='../user_list.php';</script>";
}

